---
name: djay-library
description: READ the djay Pro media library — playlists, cue points, loops, ratings, manual BPM/key, play history — directly in its local SQLite store. Use when the user says "прочитай библиотеку djay", "cue-точки/куи в djay", "history/что я играл в djay", "какие плейлисты в djay". ⛔️ WRITING playlists to the DB does NOT stick (djay 5.6.6 reconciles & reverts on launch — verified 2026-07-15); to CREATE a djay playlist use the hardlink-folder drag-n-drop in the `quick-playlist` skill. Living skill.
---

# djay-library — работа с библиотекой djay Pro

App: **djay Pro 5.6.6**, Mac App Store sandbox, bundle `com.algoriddim.djay-iphone-free`.
Нет API/AppleScript/MCP. Но библиотека — **обычный локальный SQLite**, читаемый и (в теории) правимый.

## Где что лежит (ВЕРНО, проверено)

- **Главный стор библиотеки:** `~/Music/djay/djay Media Library.djayMediaLibrary/MediaLibrary.db`
  (пакет-папка; рядом `-wal`/`-shm`). ~19 МБ. Тут ВСЁ пользовательское: треки, **плейлисты,
  cue-точки, лупы, рейтинги, manual BPM, история сессий**. Движок — **YapDatabase**
  (key-value стор `database2` + производные `view_*`, `secondaryIndex_*`, `fts_*`, `yap2`,
  плюс CloudKit-таблицы `cloudKit_*`).
- **djay сам бэкапит** библиотеку: `~/Music/djay/Backups/<дата>/…` — есть готовые снимки.
- **Кэш анализа (ОТДЕЛЬНО, не трогать для cue):** `~/Library/Group Containers/
  VJXTL73S8G.com.algoriddim.userdata/Library/Application Support/Algoriddim/Metadata/
  <bucket>/<uuid>.djayMetadata` — по-трековые **binary plist** с BPM/бит-гридом
  (`deepBeatTrackerInfo` + zlib `compressedBeats`)/тональностью (`keyInfo`)/waveform/gain.
  **Cue-точек тут НЕТ** (перепроверено по всем 1312 файлам). Это только аналитика.
- **CloudKit-кэш демона** `~/Library/Containers/com.algoriddim.djay-iphone-free/Data/CloudKit/
  cloudd_db/db` — эфемерный RecordCache (1 запись), НЕ хранилище. Библиотека синкается в
  iCloud из MediaLibrary.db через таблицы `cloudKit_*` внутри неё.

## Коллекции в `database2` (collection, key, data BLOB, metadata BLOB)

| collection | что | ~кол-во |
|---|---|---|
| `mediaItems` | идентити трека (uuid, title, artist, titleID) | 595 |
| `localMediaItemLocations` | путь к файлу / bookmark | 1360 |
| `mediaItemAnalyzedData` | ссылка на аналитику (зеркало .djayMetadata) | 1388 |
| `mediaItemUserData` | **cue-точки, loops, colorIndex, rating, playCount, manualBPM** | 1420 |
| `mediaItemPlaylists` | плейлисты (uuid, name, parentUUID, type) | 12 |
| `mediaItemPlaylistItems` | членство: playlistUUID → mediaItemUUID | 259 |
| `mediaItemTitleIDs` | нормализованные title-id | 1482 |
| `historySessions` / `historySessionItems` | история игры (что и когда играл) | 14 / 2357 |
| `mediaArtists`/`mediaAlbums`/`mediaGenres`/`mediaLabels` | справочники | — |
| `contentPacks`/`contentPackMediaItems` | встроенные луперы/сэмплы | 99 / 976 |

Реальные плейлисты пользователя (на 2026-07-15): Techno 56, Русское 46, Milinial 33,
Milinial Electro 28, Relax 23, **Prodigy Mix 22**, Online Techno 17, Bashkort 16, Sets 7,
Online Pop 7, Turk 4. Корень — `mediaItemPlaylist-root`.

## Формат блоба — «TSAF» (ВЕРНО, декодирован)

Магия `54 53 41 46` = `"TSAF"` + версия/заголовок, дальше самоописывающий поток тегов.
- `0x08` = **string** (далее C-string до `0x00`).
- Порядок: сначала **имя класса** (`ADCMediaItemPlaylist`, `ADCCuePoint`, `ADCMediaItem`…),
  затем пары **[value][key]** — ЗНАЧЕНИЕ идёт ПЕРЕД именем поля.
- Числа/enum — другие type-маркеры: замечены `0x13` перед double-значением (напр. cue `time`),
  `0x2E` у поля `type`. **Полная карта числовых маркеров ещё не составлена** (см. UNVERIFIED).

Рабочий парсер строк (достаточно для чтения плейлистов/членства/имён):

```python
def tsaf_strings(b):
    out=[]; i=0
    while i<len(b):
        if b[i]==0x08:
            j=b.find(b'\x00',i+1)
            if j<0: break
            try: out.append(b[i+1:j].decode('utf-8'))
            except: pass
            i=j+1
        else: i+=1
    return out
def tsaf_dict(b):                 # value-перед-key
    s=tsaf_strings(b)
    if not s: return {}
    d={'_class':s[0]}; body=s[1:]
    for k in range(0,len(body)-1,2): d[body[k+1]]=body[k]
    return d
```

### Числовые/контейнерные маркеры TSAF (ВЕРНО — декодировано 2026-07-15)
- `0x08` — cstring (до `0x00`).
- `0x0b` — **int32** (4 байта LE). Напр. `colorIndex`.
- `0x13` — **float32** (4 байта LE, НЕ double как думали раньше). Напр. `duration`=`13 f2aa5e43`=222.67.
- `0x0c 00 00 <int32 count>` — **массив строк** (напр. `itemUUIDs`), дальше `count` штук `08…00`.
- `0x2e` — nil (напр. `type` у плейлиста пустой).
- `0x2d` — nil-вариант (напр. `number` у cue).
- `0x2b` — начало объекта (перед именем класса).
- `0x05 <sub>` — типизированное под-поле (внутри cue: `05 0f/10/11/12/04` — цвет/тип/флаги).
- `0x15 00 00 00 <int32 len> <bytes>` — length-prefixed blob (zlib `audioAlignmentFingerprint`).
- **Порядок везде value-ПЕРЕД-key** (значение идёт до имени поля).

Ключевые поля классов:
- `ADCMediaItemPlaylist`: `uuid`, `name`, `parentUUID`, `type`(nil), **`itemUUIDs`** (массив `0x0c` —
  УПОРЯДОЧЕННЫЙ список UUID-ов playlist-item'ов = порядок треков, ЛЕЖИТ В БЛОБЕ ПЛЕЙЛИСТА).
- `ADCMediaItemPlaylistItem`: `uuid`, `playlistUUID`, `mediaItemUUID`.
- `ADCMediaItemUserData`: `uuid`, `cuePoints`[`ADCCuePoint`], `loopRegions`, `colorIndex`,
  `rating`, `playCount`, `edited`, `audioAlignmentFingerprint`, `userChangedCloudKeys`.
- `ADCCuePoint`: `time`/`endTime` = маркер `13 00` + float32 (секунды; endTime=`-1.0` = «нет»),
  `number`(nil), + под-поля `05 0f/10/11/12`. ⚠️ **НЕ полностью декодирован** — `duration` у
  userData пишется `13`+f32 БЕЗ флаг-байта, а cue-времена `13 00`+f32 С флагом; эта
  несогласованность + под-поля цвета не разгаданы → **запись cue небезопасна** (см. ниже).
- `ADCMediaItem`: `uuid`, `title`, `artist`, `ADCMediaItemTitleID`.

## КАК ЧИТАТЬ (ВЕРНО, безопасно — только на снапшоте)

1. Снять снапшот (не читать живой файл при открытом djay):
   ```bash
   SNAP=/tmp/ml; mkdir -p $SNAP
   L=~/Music/djay/"djay Media Library.djayMediaLibrary"
   cp "$L/MediaLibrary.db" "$L/MediaLibrary.db-wal" "$L/MediaLibrary.db-shm" $SNAP/ 2>/dev/null
   ```
2. `sqlite3 $SNAP/MediaLibrary.db "SELECT collection,count(*) FROM database2 GROUP BY collection;"`
3. Плейлисты: читать `mediaItemPlaylists`, членство — `mediaItemPlaylistItems`
   (фильтр по `playlistUUID` парсером, НЕ `LIKE` по BLOB — формат uuid ломает LIKE).
4. Cue: читать `mediaItemUserData`, считать `ADCCuePoint`, доставать `time`/`colorIndex`.
5. История игры: `historySessions` + `historySessionItems` (реконструкция прошлых сетов).

## ⛔️ ФИНАЛЬНЫЙ ВЕРДИКТ (2026-07-15): ВНЕШНЯЯ ЗАПИСЬ ПЛЕЙЛИСТОВ В djay 5.6.6 НЕВОЗМОЖНА

**НЕ пиши плейлисты прямо в MediaLibrary.db. djay при КАЖДОМ запуске реконсилит дерево плейлистов и
откатывает наши правки — проверены и провалены ОБА подхода:**

1. **Создание с нуля** (все 6+ структур вручную, 100% паритет с рабочим плейлистом по всем таблицам):
   после запуска djay ВЫЧИСТИЛ наш плейлист (rowid 11729) из `mediaView`, `mediaItemPlaylistsView`,
   `secondaryIndex`, root.`childUUIDs` и ребра `mediaItemPlaylistChild` → невидим.
2. **Наполнение UI-созданного пустого плейлиста** (казалось надёжным — плейлист в каноне djay): залили
   «Playlist 1» (11816) 20 треками. После запуска djay **убрал сам Playlist 1 из `mediaView`** (сайдбар)
   и создал юзеру НОВЫЙ пустой «Playlist 2». Тонкость: СОДЕРЖИМОЕ Playlist 1 НЕ откатилось (blob
   itemUUIDs=20, items view=20, item-рёбра=20, 20 item-строк — всё осталось в БД как orphan), но
   плейлист выпал из сайдбара → всё равно невидим/бесполезен. Т.е. реконсилится именно членство в
   `mediaView`, и внешне-тронутый плейлист (даже свой, djay-созданный) из него исключается.

**Открытый вопрос (механизм):** плейлисты НЕ в CloudKit (там только `mediaItemUserData`+`products`).
`metadata`-колонка у плейлистов NULL. Подозрение: djay метит объекты, изменённые вне его, через
per-row snapshot/версию YapDatabase (столбец не в database2) ИЛИ держит канонический реестр плейлистов
в памяти/внешне и на старте перестраивает `mediaView` только по нему. Мы этот маркер не обновляли →
djay считает объект «чужим» и выкидывает из сайдбара. НЕ разгадано до конца — но вывод практический:
**писать бесполезно, откатывается.**

**Скрипты записи — RESEARCH-ONLY, НЕ использовать для реальных плейлистов:**
`scripts/create_playlist.py`, `scripts/fill_playlist.py`, `scripts/fix_mediaView_playlist.py`,
`scripts/fix_root_childUUIDs.py`, `scripts/delete_playlist.py`. Они структурно КОРРЕКТНЫ и полезны для
реверса/чтения, но их правки djay откатит. (m3u8 тоже НЕ работает — djay его не импортирует.)

## ✅ РАБОЧИЙ ПУТЬ СОБРАТЬ ПЛЕЙЛИСТ — папка нумерованных хардлинков + drag-n-drop (skill `quick-playlist`)
Единственный проверенный способ: папка `~/Music/DJ/Sets/<Название>/` с хардлинками `NN - <файл>`
(`ln`, порядок в именах = порядок сета), **юзер перетаскивает ПАПКУ в сайдбар djay** — плейлист
появляется сразу, без рестарта, и djay его НЕ откатывает (это его штатный импорт). Работает даже при
запущенном djay. Полный рецепт — в скилле `quick-playlist`.

## КАК СОЗДАТЬ ПЛЕЙЛИСТ С НУЛЯ — ⚠️ RESEARCH-ONLY, структурно верно, но djay ОТКАТИТ (см. вердикт выше)

**Протокол безопасности (обязателен перед ЛЮБОЙ записью):**
1. **Полностью закрыть djay** (`pgrep -fi djay` пуст) — иначе гонка с WAL.
2. Бэкап пакета целиком: `cp -R "…djayMediaLibrary" ~/Music/djay/Backups/pre-…-$(date +%s)/`.
3. Прогнать райтер на КОПИИ, проверить `PRAGMA integrity_check`+reparse, только потом на боевой.
4. Перед правкой боевой: `sqlite3 MediaLibrary.db "PRAGMA wal_checkpoint(TRUNCATE);"`, после — снова.

**Ключевой факт:** view/relationship/secondaryIndex/fts **НЕ перестраиваются** при старте djay
(versionTag в `yap2` не меняется) → ВСЕ производные структуры надо поддержать вручную. Порядок
треков хранится ДВАЖДЫ и согласованно: (а) массив `itemUUIDs` в блобе плейлиста, (б) `view_…View_page.data`.

**🚨🚨 ГЛАВНАЯ ГРАБЛЯ №1 (набита 2026-07-15, СТОИЛА ДВУХ НЕВИДИМЫХ ПОПЫТОК): сайдбар рисуется из
view `mediaView`, group=`'playlist'` — НЕ из mediaItemPlaylistsView и НЕ из childUUIDs.**
Есть отдельный YapDatabaseAutoView `mediaView` (`view_mediaView_page`/`_map`) — унифицированный
браузер библиотеки. У него есть страница с `group='playlist'` (одна page), где 8-байтными LE-rowid'ами
перечислены ВСЕ плейлисты, **отсортированные по имени** (casefold, латиница раньше кириллицы).
**ИМЕННО из этой страницы djay рендерит список плейлистов в сайдбаре.** Плейлист, заведённый в
database2 + mediaItemPlaylistsView + relationship + secondaryIndex + fts + childUUIDs, но ОТСУТСТВУЮЩИЙ
в `mediaView.group='playlist'`, **живёт в БД, но НЕВИДИМ**. Фикс — `scripts/fix_mediaView_playlist.py
<db> <rowid> <name>`: вставить rowid в page на алфавитную позицию (count+1) + строка в
`view_mediaView_map(rowid,pageKey)` + bump snapshot. **ЭТО РЕШАЮЩИЙ ШАГ.** Способ найти его для любой
БД: полный diff нового плейлиста vs рабочего по ВСЕМ `view_*_map`/`secondaryIndex_*`/`fts_*` — искать
единственную таблицу, где рабочий есть, а новый отсутствует.

**Грабля №2 (тоже обязательна, но одна её не хватает): `mediaItemPlaylist-root`.`childUUIDs`.**
Root-объект (rowid 6) — ADCMediaItemPlaylist с массивом `childUUIDs` (0x0c) = UUID дочерних плейлистов.
Держать консистентно (`scripts/fix_root_childUUIDs.py`), НО сам по себе он сайдбар НЕ показывает —
нужен ещё mediaView (грабля №1). (Плейлисты/items/root — **device-local, НЕ в CloudKit**; в
`cloudKit_mapping` только `mediaItemUserData`+`products` → локальная правка не слетает при синке.
Проверено: наш плейлист пережил 2 запуска djay целым, снапшот дошёл до 20158 — djay ничего не удалял,
просто не показывал, т.к. mediaView был неполным.)

**Рецепт (готовый код: `scratchpad/writer.py` + `tsaf.py` этой сессии; энкодер round-trip'нут
байт-в-байт против живых блобов).** Для плейлиста с N треков вставить/обновить:
1. `database2` collection=`mediaItemPlaylists`: 1 строка (key=plUUID, data=TSAF-блоб, metadata=NULL).
   Блоб: `TSAF`+`03000300`+`int64(2)`+`int32(9+N)` + `2b` + str("ADCMediaItemPlaylist") +
   str(uuid)+str("uuid") + str(name)+str("name") + str("mediaItemPlaylist-root")+str("parentUUID") +
   `2e`+str("type") + `0c 0000`+`int32(N)`+[str(itemUUID)×N] + str("itemUUIDs") + `00`.
   (`str(x)` = `08`+utf8(x)+`00`.) Взять `cur.lastrowid` → `PL`.
2. `database2` collection=`mediaItemPlaylistItems`: N строк (key=itemUUID, blob=`TSAF`+`03000300`+
   `int64(1)`+`int32(7)`+`2b`+str("ADCMediaItemPlaylistItem")+str(uuid)+str("uuid")+str(plUUID)+
   str("playlistUUID")+str(mediaItemUUID)+str("mediaItemUUID")+`00`). Собрать rowid'ы `I[]`.
3. **root.childUUIDs (ОБЯЗАТЕЛЬНО — иначе плейлист невидим!):** в блобе `mediaItemPlaylist-root`
   дописать `08<plUUID>00` в массив `childUUIDs` + инкремент header string-count (`int32` @[16:20]) и
   array-count. Готово в `scripts/fix_root_childUUIDs.py`.
3b. **`mediaView`, group=`'playlist'` (РЕШАЮЩИЙ — из него рендерится сайдбар!):** в `view_mediaView_page`
   странице с `group='playlist'` дописать rowid PL на алфавитную позицию (по имени, casefold), `count+1`;
   `view_mediaView_map`: INSERT `(rowid=PL, pageKey=<та page>)`. Скрипт `scripts/fix_mediaView_playlist.py`.
3c. `view_mediaItemPlaylistsView_page` (folder-hierarchy view, для целостности): к строке
   `group='mediaItemPlaylist-root'` (pageKey `3A488EBA-…` на этой машине) **дописать** `struct.pack('<q',PL)`
   в `data`, `count+1`. `view_mediaItemPlaylistsView_map`: INSERT `(rowid=PL, pageKey=<та же>)`.
   (Само по себе НЕ показывает плейлист — сайдбар из mediaView, шаг 3b.)
4. `view_mediaItemPlaylistView_page` (треки): INSERT новую страницу `(pageKey=новый UUID,
   group=plUUID, prevPageKey=NULL, count=N, data=конкатенация I[] по 8 байт LE В ПОРЯДКЕ ПОКАЗА)`.
   `view_mediaItemPlaylistView_map`: N строк `(rowid=I[k], pageKey=новый)`.
5. `relationship_relationship` (dst хранится как INTEGER rowid): `mediaItemPlaylistChild`(src=6,dst=PL,
   rules=2), `mediaItemPlaylistParent`(src=PL,dst=6,rules=4); на каждый item: `mediaItemPlaylistItem`
   (src=PL,dst=I,rules=2), `mediaItemPlaylistItemMediaItem`(src=I,dst=mediaItemRowid,rules=4),
   `mediaItemPlaylistItemPlaylist`(src=I,dst=PL,rules=4). manual=0 везде. (root rowid=6.)
6. `secondaryIndex_mediaItemPlaylistIndex`: INSERT `(rowid=PL, name=<имя>)`.
7. FTS: `INSERT INTO fts_searchIndex(docid,playlist) VALUES(PL, <имя>)` (колонки FTS4:
   title,artist,genre,album,grouping,comments,composer,playlist). Не критично, но плейлисты там есть.
8. `yap2`: `UPDATE … SET data=data+1 WHERE extension='' AND key='snapshot'` (мимикрия коммита).
9. **CloudKit трогать НЕ надо** — djay сам поставит новые объекты в очередь при следующем старте.
   Проверено: `integrity_check`=ok, `foreign_key_check`=OK, плейлист виден, порядок верный.

**Добавить трек в существующий плейлист:** то же, что шаги 2/4/5, ПЛЮС в блобе плейлиста дописать
UUID в массив `itemUUIDs` (перекодировать блоб, `int32` string-count и count массива +1) и дописать
rowid в его `view_…View_page.data` (или пересобрать страницу). Не тестировалось отдельно, но механика та же.

## Cue-точки — ⚠️ ЧАСТИЧНО декодировано, ЗАПИСЬ НЕ ДЕЛАТЬ (2026-07-15)

Читать cue безопасно. **Писать — НЕТ.** Причины: (1) cue живут в `mediaItemUserData`, где рядом
rating/playCount/colorIndex и часто **большой zlib `audioAlignmentFingerprint`** (`0x15`+len, до 5 КБ) —
TSAF позиционный, любой сдвиг байта ломает весь блоб трека; (2) числовой формат cue не разгадан до
конца: cue `time`/`endTime` = `13 00`+float32 (endTime=`-1.0` сентинел, Firestarter time=20.38с ✓),
НО top-level `duration` = `13`+float32 БЕЗ флаг-байта `00` — эта несогласованность + под-поля цвета/типа
(`05 0f/10/11/12`) не сматчены к значениям → энкодер cue нельзя round-trip'нуть с гарантией. Риск порчи
велик, ценность для ЖИВОГО сета мала (диджей ставит cue на лету). **Фолбэк:** cue руками по сет-плану.

**Открытые вопросы (cue):**
- [ ] Почему `duration` `13`+f32, а cue-`time` `13 00`+f32 — что значит флаг `00`? (double vs float?)
- [ ] Под-поля `05 0f/10/11/12/04` в `ADCCuePoint` = colorIndex/type/isHotCue/loop? (сопоставить со значениями в UI).
- [ ] Формат массива cue `05 05 0a 00 00 <int32 count>` — контейнер cuePoints.

## Готовые скрипты — ⚠️ ВСЕ RESEARCH-ONLY (djay откатывает записи, см. финальный вердикт)
- `scripts/tsaf.py` — TSAF-энкодер плейлиста/item (round-trip-верифицирован байт-в-байт; полезен для чтения/реверса).
- `scripts/fill_playlist.py` — наполняет UI-плейлист контентом. НЕ работает: djay убрал плейлист из mediaView.
- `scripts/create_playlist.py` — райтер с нуля. НЕ работает: djay вычистил из всех display-структур.
- `scripts/fix_mediaView_playlist.py`, `scripts/fix_root_childUUIDs.py` — точечные фиксы сайдбара. Откатываются.
- `scripts/delete_playlist.py` — полное удаление плейлиста+items из всех структур (единственное, что «держится»,
  т.к. убирает, а не добавляет; пригодилось вычистить orphan). **Для сборки плейлистов — только `quick-playlist`.**
  Внутри `TRACKS` — пример (сет Prodigy Night); заменить на `(media_rowid, media_uuid)` своих треков.
  media_rowid = `database2.rowid` трека в `mediaItems`; media_uuid = его `key` (32-hex).
  Матчинг треков к строкам: `fts_searchIndex_content(docid=rowid, c0title, c1artist)` +
  `localMediaItemLocations` (file:// пути). Запуск: на КОПИИ → verify → на боевой (djay закрыт).

## Безопасный обходной путь (для cue / аварийный)
- **Создание плейлиста теперь проверено** (см. рецепт выше) — фолбэк не нужен для порядка треков.
- **Cue** — писать в БД НЕ безопасно (см. секцию cue). Расставить руками по сет-плану, ИЛИ
  отдать порядок как **M3U** (djay открывает перетаскиванием) — 0 риска. Пример готового m3u8:
  `~/Music/DJ/Sets/Prodigy Night.m3u8` (сгенерирован из `localMediaItemLocations`, 20 треков на диске).
- Стратегически: свой `livehub` (Rust DJ-хаб) хранит cue/плейлисты в открытом формате без
  YapDatabase/CloudKit-замка — туда и целиться для полной автоматизации.

## Правило живого скилла

После каждой сессии с библиотекой djay: подтверждённые факты переносить из UNVERIFIED в ВЕРНО,
новые type-маркеры TSAF и грабли дописывать сюда же.

## Hardlink-воскрешение путей (проверено: 422 файла)
Файлы переехали → плейлисты мёртвые. НЕ править БД: извлечь file:// URL из блобов localMediaItemLocations (`re.findall(rb'file://[^\x00\x08\x10]+', data)`, unquote), для каждого MOVED (basename найден в новой структуре) `os.link(новый, старый)` — тот же inode, 0 байт, bookmark и путь оживают. Папки-призраки скрыть `chflags hidden`. GONE (файл удалён) — только руками. Кэш: после замены mp3 перетащить трек в djay заново.

## Импорт плейлистов без записи в БД (проверено 2026-07-15)
- **m3u8 djay НЕ поддерживает** (drag-n-drop игнорируется молча).
- **Music.app-мост не годится для нашей библиотеки**: Music не принимает FLAC (импортнулись только mp3).
- **Работает: папка с нумерованными хардлинками** — `ln <трек> "Sets/<Имя>/NN - <имя>.ext"` (порядок = префикс NN), папку перетащить в сайдбар djay → штатный плейлист, 0 байт диска. Скрипт-паттерн: читать m3u8/список, basename искать в ~/Music/DJ через find.
- Прямая запись в БД: обязателен root.childUUIDs (см. рецепт выше) — без него плейлист невидим в сайдбаре при целых остальных структурах.
