#!/usr/bin/env python3
"""Fill an EXISTING (djay-created) playlist with tracks. This is the ROBUST path:
djay reconciles the root->children set on launch and PURGES externally-injected
playlists — but it does NOT reconcile playlist CONTENTS. So: let the user create an
empty playlist in djay's UI, then fill it here (itemUUIDs blob + items + view + edges).
Does NOT touch childUUIDs/mediaView/secondaryIndex (djay owns those for its playlist).

Usage: python3 fill_playlist.py <MediaLibrary.db> <PLAYLIST_ROWID>
Preconditions: djay CLOSED, backup, wal_checkpoint before+after.
Edit TRACKS below (media_rowid, media_uuid) in display order.
"""
import sqlite3, struct, uuid, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tsaf import encode_playlist, encode_item

# (media_rowid, media_uuid) in DISPLAY order — Prodigy Night set-plan
TRACKS = [
 (2051,"96f39c706a502632f7ba96d564cdc501"),(5595,"ff135edb37fc0f62245272c0dcbaf34e"),
 (7556,"95c7f7d68861bd59289f4d3ad66cf417"),(8507,"8084bf546c055eea588c209d6d5761cb"),
 (8107,"500dc23cc806c7b44dfa1f811054481f"),(5543,"d48ae063603f6835cfbe6775fb312117"),
 (2065,"b86bc31ad9cd648b3725b1f03fdf3a38"),(2122,"aecc05da2cefcc06dde1533e6b89486c"),
 (8484,"45391f9c33128e63f5b647bcc65de3d8"),(8676,"72edcffffce0d7dfc0cd56f3c1139b1e"),
 (8456,"6184123e76d6e23ff42da89e67dfcd66"),(2111,"0f1e0ea90d88ca189bcbc84d971a76ef"),
 (2093,"1bfb567e11eff7c410850fa7b556004c"),(10369,"6d2445a944a90af27574da83f3df63a4"),
 (7528,"9b092a9896d05d433997ea8cc5aa3e99"),(2123,"789bfe6939106e394ce9b73d63dc77a8"),
 (2121,"3466bb56608a8910856bac2c4fb530c1"),(7618,"6249eaef4de554b928b4423b84a1c0ac"),
 (2052,"0cc6c8d9bc57486a8302a367c6606486"),(2071,"ebd83ca6cf51d2bc9092efd3e92602ab"),
]

def ss(b):
    o=[];i=0
    while i<len(b):
        if b[i]==0x08:
            j=b.find(b'\x00',i+1)
            if j<0:break
            o.append(b[i+1:j].decode('utf-8','replace'));i=j+1
        else:i+=1
    return o

def fill(db, pl_rowid):
    con=sqlite3.connect(db); cur=con.cursor()
    row=cur.execute("SELECT key,data FROM database2 WHERE rowid=? AND collection='mediaItemPlaylists'",(pl_rowid,)).fetchone()
    if not row: print("playlist rowid not found"); return
    pl_uuid, blob = row
    s=ss(blob[20:])   # skip 20-byte TSAF header (magic+ver+int64+int32 strcount); low byte 0x08 would
                      # otherwise fake an empty string and shift field positions
    pl_name = s[3] if len(s)>3 else 'Playlist'
    existing = s[s.index('type')+1:s.index('itemUUIDs')] if 'itemUUIDs' in s else []
    if existing:
        print(f"playlist already has {len(existing)} items — aborting to avoid dup"); return
    cur.execute("BEGIN")
    try:
        item_uuids=[str(uuid.uuid4()).upper() for _ in TRACKS]
        # rebuild playlist blob WITH itemUUIDs (round-trip-verified encoder)
        new_blob=encode_playlist(pl_uuid, pl_name, item_uuids)
        cur.execute("UPDATE database2 SET data=? WHERE rowid=?",(new_blob,pl_rowid))
        # item rows
        item_rowids=[]
        for (mrow,muuid),iu in zip(TRACKS,item_uuids):
            cur.execute("INSERT INTO database2(collection,key,data,metadata) VALUES('mediaItemPlaylistItems',?,?,NULL)",
                        (iu, encode_item(iu, pl_uuid, muuid)))
            item_rowids.append(cur.lastrowid)
        # items view page + map
        page_key=str(uuid.uuid4()).upper()
        page_data=b''.join(struct.pack('<q',r) for r in item_rowids)
        cur.execute("INSERT INTO view_mediaItemPlaylistView_page(pageKey,\"group\",prevPageKey,count,data) VALUES(?,?,NULL,?,?)",
                    (page_key, pl_uuid, len(item_rowids), page_data))
        for r in item_rowids:
            cur.execute("INSERT INTO view_mediaItemPlaylistView_map(rowid,pageKey) VALUES(?,?)",(r,page_key))
        # relationship item edges
        for (mrow,muuid),irow in zip(TRACKS,item_rowids):
            cur.execute("INSERT INTO relationship_relationship(name,src,dst,rules,manual) VALUES('mediaItemPlaylistItem',?,?,2,0)",(pl_rowid,irow))
            cur.execute("INSERT INTO relationship_relationship(name,src,dst,rules,manual) VALUES('mediaItemPlaylistItemMediaItem',?,?,4,0)",(irow,mrow))
            cur.execute("INSERT INTO relationship_relationship(name,src,dst,rules,manual) VALUES('mediaItemPlaylistItemPlaylist',?,?,4,0)",(irow,pl_rowid))
        snap=cur.execute("SELECT data FROM yap2 WHERE extension='' AND key='snapshot'").fetchone()[0]
        cur.execute("UPDATE yap2 SET data=? WHERE extension='' AND key='snapshot'",(snap+1,))
        con.commit()
        print(f"OK filled '{pl_name}' (rowid {pl_rowid}, uuid {pl_uuid}) with {len(TRACKS)} tracks")
        print(f"   item_rowids={item_rowids}  page_key={page_key}  snapshot {snap}->{snap+1}")
        print("   integrity:",cur.execute("PRAGMA integrity_check").fetchone()[0])
    except Exception:
        con.rollback(); raise
    finally:
        con.close()

if __name__=='__main__':
    fill(sys.argv[1], int(sys.argv[2]))
