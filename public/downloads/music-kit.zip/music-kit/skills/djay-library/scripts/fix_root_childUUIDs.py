#!/usr/bin/env python3
"""Add a playlist UUID to the ROOT object's childUUIDs array so djay shows it in the
sidebar. djay renders the sidebar from mediaItemPlaylist-root.childUUIDs (an 0x0c string
array in the root blob) — NOT from the YapDatabaseView. A playlist wired into view/
relationship/secondaryIndex but missing from childUUIDs exists in the DB yet is INVISIBLE.

Usage: python3 fix_root_childUUIDs.py <MediaLibrary.db> <PLAYLIST_UUID>
Preconditions: djay CLOSED. Backup taken. Run wal_checkpoint(TRUNCATE) before+after.
"""
import sqlite3, struct, sys

def patch_root_childUUIDs(blob, new_uuid):
    assert blob[:4]==b'TSAF', "not a TSAF blob"
    strcount=struct.unpack('<I',blob[16:20])[0]           # header string-count int32
    ai=blob.find(b'\x0c\x00\x00'); assert ai>=0, "no 0x0c array marker"
    arr_count=struct.unpack('<I',blob[ai+3:ai+7])[0]      # array element count
    key=b'\x08childUUIDs\x00'; ki=blob.find(key); assert ki>=0, "no childUUIDs key"
    if ('\x08'+new_uuid) .encode() in blob:               # already present -> no-op
        pass
    ins=b'\x08'+new_uuid.encode()+b'\x00'
    return (blob[:16] + struct.pack('<I',strcount+1) + blob[20:ai+3]
            + struct.pack('<I',arr_count+1) + blob[ai+7:ki] + ins + blob[ki:])

def tsaf_strings(b):
    out=[];i=0
    while i<len(b):
        if b[i]==0x08:
            j=b.find(b'\x00',i+1)
            if j<0:break
            out.append(b[i+1:j].decode('utf-8','replace'));i=j+1
        else:i+=1
    return out

if __name__=='__main__':
    db, pl_uuid = sys.argv[1], sys.argv[2]
    con=sqlite3.connect(db); cur=con.cursor()
    blob=cur.execute("SELECT data FROM database2 WHERE key='mediaItemPlaylist-root'").fetchone()[0]
    s=tsaf_strings(blob); ci=s.index('childUUIDs')
    if pl_uuid in s[6:ci]:
        print(f"already in childUUIDs ({len(s[6:ci])} children) — nothing to do"); sys.exit(0)
    new=patch_root_childUUIDs(blob, pl_uuid)
    cur.execute("BEGIN")
    cur.execute("UPDATE database2 SET data=? WHERE key='mediaItemPlaylist-root'",(new,))
    snap=cur.execute("SELECT data FROM yap2 WHERE extension='' AND key='snapshot'").fetchone()[0]
    cur.execute("UPDATE yap2 SET data=? WHERE extension='' AND key='snapshot'",(snap+1,))
    con.commit()
    s2=tsaf_strings(cur.execute("SELECT data FROM database2 WHERE key='mediaItemPlaylist-root'").fetchone()[0])
    ci2=s2.index('childUUIDs')
    print(f"OK childUUIDs {len(s[6:ci])} -> {len(s2[6:ci2])}, uuid present={pl_uuid in s2[6:ci2]}")
    print("integrity:", cur.execute("PRAGMA integrity_check").fetchone()[0])
    con.close()
