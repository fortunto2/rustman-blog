#!/usr/bin/env python3
"""TSAF encoder for djay ADCMediaItemPlaylist / ADCMediaItemPlaylistItem blobs.
Round-trip verified against live library blobs before any write."""
import struct, binascii, sqlite3

def s(x):  # string token
    return b'\x08' + x.encode('utf-8') + b'\x00'

def encode_playlist(uuid, name, item_uuids, parent='mediaItemPlaylist-root'):
    body = b''
    body += b'\x2b'                      # object begin
    body += s('ADCMediaItemPlaylist')    # class
    body += s(uuid) + s('uuid')
    body += s(name) + s('name')
    body += s(parent) + s('parentUUID')
    body += b'\x2e' + s('type')          # type = nil (0x2e marker)
    # itemUUIDs array: 0x0c 00 00 <int32 count> <strings...> then key
    body += b'\x0c\x00\x00' + struct.pack('<I', len(item_uuids))
    for iu in item_uuids:
        body += s(iu)
    body += s('itemUUIDs')
    body += b'\x00'                      # trailer
    nstr = 9 + len(item_uuids)           # total 0x08 string tokens
    hdr = b'TSAF' + b'\x03\x00\x03\x00' + struct.pack('<q', 2) + struct.pack('<I', nstr)
    return hdr + body

def encode_item(uuid, playlist_uuid, media_item_uuid):
    body = b''
    body += b'\x2b'
    body += s('ADCMediaItemPlaylistItem')
    body += s(uuid) + s('uuid')
    body += s(playlist_uuid) + s('playlistUUID')
    body += s(media_item_uuid) + s('mediaItemUUID')
    body += b'\x00'
    nstr = 7
    hdr = b'TSAF' + b'\x03\x00\x03\x00' + struct.pack('<q', 1) + struct.pack('<I', nstr)
    return hdr + body

if __name__ == '__main__':
    DB="/private/tmp/claude-501/-Users-rustam-Music-1music/393ad8d2-47d0-4106-9e37-cd08541e3195/scratchpad/ml/MediaLibrary.db"
    con=sqlite3.connect(DB); cur=con.cursor()

    def tsaf_strings(b):
        out=[];i=0
        while i<len(b):
            if b[i]==0x08:
                j=b.find(b'\x00',i+1)
                if j<0: break
                out.append(b[i+1:j].decode('utf-8','replace')); i=j+1
            else:i+=1
        return out

    # --- round trip the Prodigy Mix playlist ---
    TKEY='1412B754-0ECE-4241-8FE0-AE96238BF765'
    cur.execute("SELECT data FROM database2 WHERE collection='mediaItemPlaylists' AND key=?",(TKEY,))
    orig=cur.fetchone()[0]
    strs=tsaf_strings(orig)
    # extract item uuids: between 'type' and 'itemUUIDs'
    # order in blob = class,uuid,'uuid',name,'name',parent,'parentUUID','type', <N uuids>, 'itemUUIDs'
    ti=strs.index('type'); ii=strs.index('itemUUIDs')
    item_uuids=strs[ti+1:ii]
    name=strs[strs.index('uuid')+1-0]  # name is right after 'uuid'? no. get by position
    # positions: [0]class [1]uuid_val [2]'uuid' [3]name_val [4]'name' [5]parent_val [6]'parentUUID' [7]'type'
    uuid_val=strs[1]; name_val=strs[3]; parent_val=strs[5]
    rebuilt=encode_playlist(uuid_val,name_val,item_uuids,parent_val)
    print("PLAYLIST round-trip match:", rebuilt==orig, f"(orig {len(orig)}b, rebuilt {len(rebuilt)}b)")
    if rebuilt!=orig:
        # show first diff
        for k in range(min(len(orig),len(rebuilt))):
            if orig[k]!=rebuilt[k]:
                print("  first diff at byte",k)
                print("  orig :",binascii.hexlify(orig[max(0,k-6):k+10]).decode())
                print("  reblt:",binascii.hexlify(rebuilt[max(0,k-6):k+10]).decode())
                break
        print("  orig hex :",binascii.hexlify(orig).decode()[:120])
        print("  reblt hex:",binascii.hexlify(rebuilt).decode()[:120])

    # --- round trip an item ---
    cur.execute("SELECT key,data FROM database2 WHERE collection='mediaItemPlaylistItems' LIMIT 1")
    ikey,idata=cur.fetchone()
    istrs=tsaf_strings(idata)
    # [0]class [1]uuid_val [2]'uuid' [3]playlist_val [4]'playlistUUID' [5]media_val [6]'mediaItemUUID'
    ir=encode_item(istrs[1],istrs[3],istrs[5])
    print("ITEM round-trip match:", ir==idata, f"(orig {len(idata)}b)")
    if ir!=idata:
        print("  orig :",binascii.hexlify(idata).decode())
        print("  reblt:",binascii.hexlify(ir).decode())
    con.close()
