#!/usr/bin/env python3
"""Create the 'Prodigy Night AI' playlist inside a djay MediaLibrary.db (YapDatabase).
Maintains ALL derived structures: database2 rows, both views (page+map),
relationship edges, secondaryIndex, FTS, and bumps yap2 snapshot.
Run on a COPY first, verify, then on the real db."""
import sqlite3, struct, uuid, sys, os, binascii

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tsaf import encode_playlist, encode_item

PLAYLIST_NAME = "Prodigy Night AI"
ROOT_ROWID = 6
ROOT_UUID = "mediaItemPlaylist-root"
PLAYLISTS_ROOT_PAGEKEY = "3A488EBA-75E7-4323-8E36-051EFD661182"  # group=mediaItemPlaylist-root

# (media_rowid, media_uuid) in DISPLAY order (set-plan игровой порядок, stingers inline)
TRACKS = [
 (2051,"96f39c706a502632f7ba96d564cdc501"),  # Prodigy - Breathe
 (5595,"ff135edb37fc0f62245272c0dcbaf34e"),  # Chemical Brothers - Hey Boy Hey Girl
 (7556,"95c7f7d68861bd59289f4d3ad66cf417"),  # Benny Benassi - Satisfaction
 (8507,"8084bf546c055eea588c209d6d5761cb"),  # Michael Jackson - Billie Jean
 (8107,"500dc23cc806c7b44dfa1f811054481f"),  # The Police - Every Breath You Take
 (5543,"d48ae063603f6835cfbe6775fb312117"),  # Snap! - The Power
 (2065,"b86bc31ad9cd648b3725b1f03fdf3a38"),  # Кино - Звезда по имени Солнце
 (2122,"aecc05da2cefcc06dde1533e6b89486c"),  # Кино - Хочу перемен
 (8484,"45391f9c33128e63f5b647bcc65de3d8"),  # Betsy - Сигма Бой
 (8676,"72edcffffce0d7dfc0cd56f3c1139b1e"),  # Oxxxymiron - Агент (audio)
 (8456,"6184123e76d6e23ff42da89e67dfcd66"),  # Detsl - Кто там у руля
 (2111,"0f1e0ea90d88ca189bcbc84d971a76ef"),  # Demo - Солнышко
 (2093,"1bfb567e11eff7c410850fa7b556004c"),  # Eric Prydz vs Floyd - Proper Education
 (10369,"6d2445a944a90af27574da83f3df63a4"), # [STINGER] Чип и Дейл - Дисней-заставка
 (7528,"9b092a9896d05d433997ea8cc5aa3e99"),  # New Order - Blade (Pump Panel)
 (2123,"789bfe6939106e394ce9b73d63dc77a8"),  # Prodigy - Smack My Bitch Up
 (2121,"3466bb56608a8910856bac2c4fb530c1"),  # Prodigy - Baby's Got A Temper
 (7618,"6249eaef4de554b928b4423b84a1c0ac"),  # [STINGER] Mortal Kombat II
 (2052,"0cc6c8d9bc57486a8302a367c6606486"),  # Prodigy - Firestarter
 (2071,"ebd83ca6cf51d2bc9092efd3e92602ab"),  # Prodigy - Voodoo People
]

def newuuid():
    return str(uuid.uuid4()).upper()

def create_playlist(db_path, pl_uuid=None, verbose=True):
    pl_uuid = pl_uuid or newuuid()
    con=sqlite3.connect(db_path); cur=con.cursor()
    cur.execute("BEGIN")
    try:
        # 1) item UUIDs (one per track), build item blobs
        item_uuids=[newuuid() for _ in TRACKS]
        # 2) playlist blob (with itemUUIDs array in display order)
        pl_blob=encode_playlist(pl_uuid, PLAYLIST_NAME, item_uuids)
        cur.execute("INSERT INTO database2(collection,key,data,metadata) VALUES('mediaItemPlaylists',?,?,NULL)",
                    (pl_uuid, pl_blob))
        pl_rowid=cur.lastrowid
        # 3) item rows
        item_rowids=[]
        for (mrow,muuid),iu in zip(TRACKS,item_uuids):
            blob=encode_item(iu, pl_uuid, muuid)
            cur.execute("INSERT INTO database2(collection,key,data,metadata) VALUES('mediaItemPlaylistItems',?,?,NULL)",
                        (iu, blob))
            item_rowids.append(cur.lastrowid)
        # 4) view_mediaItemPlaylistsView (sidebar): append pl_rowid to root page, +1 count; map
        cur.execute("SELECT count,data FROM view_mediaItemPlaylistsView_page WHERE pageKey=?",(PLAYLISTS_ROOT_PAGEKEY,))
        cnt,data=cur.fetchone()
        newdata=data+struct.pack('<q',pl_rowid)
        cur.execute("UPDATE view_mediaItemPlaylistsView_page SET count=?,data=? WHERE pageKey=?",
                    (cnt+1,newdata,PLAYLISTS_ROOT_PAGEKEY))
        cur.execute("INSERT INTO view_mediaItemPlaylistsView_map(rowid,pageKey) VALUES(?,?)",(pl_rowid,PLAYLISTS_ROOT_PAGEKEY))
        # 4a) mediaView group='playlist' — THE view djay renders the sidebar from (CRITICAL).
        mvrow=cur.execute("SELECT pageKey,count,data FROM view_mediaView_page WHERE \"group\"='playlist'").fetchone()
        if mvrow:
            mpk,mcnt,mdata=mvrow
            mrows=[struct.unpack('<q',mdata[i:i+8])[0] for i in range(0,len(mdata),8)]
            def _pname(r):
                d=cur.execute("SELECT data FROM database2 WHERE rowid=?",(r,)).fetchone()[0]
                o=[];i=0
                while i<len(d):
                    if d[i]==0x08:
                        j=d.find(b'\x00',i+1);
                        if j<0:break
                        o.append(d[i+1:j].decode('utf-8','replace'));i=j+1
                    else:i+=1
                return o[3] if len(o)>3 else ''
            key=PLAYLIST_NAME.casefold(); midx=len(mrows)
            for i,r in enumerate(mrows):
                if key < _pname(r).casefold(): midx=i; break
            mrows.insert(midx, pl_rowid)
            cur.execute("UPDATE view_mediaView_page SET count=?,data=? WHERE pageKey=?",
                        (len(mrows), b''.join(struct.pack('<q',r) for r in mrows), mpk))
            cur.execute("INSERT INTO view_mediaView_map(rowid,pageKey) VALUES(?,?)",(pl_rowid,mpk))
        # 4b) root.childUUIDs — append pl_uuid to the ROOT blob's child array (sidebar consistency).
        rb=cur.execute("SELECT data FROM database2 WHERE key='mediaItemPlaylist-root'").fetchone()[0]
        strc=struct.unpack('<I',rb[16:20])[0]; ai=rb.find(b'\x0c\x00\x00'); ac=struct.unpack('<I',rb[ai+3:ai+7])[0]
        ki=rb.find(b'\x08childUUIDs\x00')
        rb2=(rb[:16]+struct.pack('<I',strc+1)+rb[20:ai+3]+struct.pack('<I',ac+1)+rb[ai+7:ki]
             +b'\x08'+pl_uuid.encode()+b'\x00'+rb[ki:])
        cur.execute("UPDATE database2 SET data=? WHERE key='mediaItemPlaylist-root'",(rb2,))
        # 5) view_mediaItemPlaylistView (items): new page group=pl_uuid, data=item rowids in order; map
        page_key=newuuid()
        page_data=b''.join(struct.pack('<q',r) for r in item_rowids)
        cur.execute("INSERT INTO view_mediaItemPlaylistView_page(pageKey,\"group\",prevPageKey,count,data) VALUES(?,?,NULL,?,?)",
                    (page_key, pl_uuid, len(item_rowids), page_data))
        for r in item_rowids:
            cur.execute("INSERT INTO view_mediaItemPlaylistView_map(rowid,pageKey) VALUES(?,?)",(r,page_key))
        # 6) relationship edges
        cur.execute("INSERT INTO relationship_relationship(name,src,dst,rules,manual) VALUES('mediaItemPlaylistChild',?,?,2,0)",(ROOT_ROWID,pl_rowid))
        cur.execute("INSERT INTO relationship_relationship(name,src,dst,rules,manual) VALUES('mediaItemPlaylistParent',?,?,4,0)",(pl_rowid,ROOT_ROWID))
        for (mrow,muuid),irow in zip(TRACKS,item_rowids):
            cur.execute("INSERT INTO relationship_relationship(name,src,dst,rules,manual) VALUES('mediaItemPlaylistItem',?,?,2,0)",(pl_rowid,irow))
            cur.execute("INSERT INTO relationship_relationship(name,src,dst,rules,manual) VALUES('mediaItemPlaylistItemMediaItem',?,?,4,0)",(irow,mrow))
            cur.execute("INSERT INTO relationship_relationship(name,src,dst,rules,manual) VALUES('mediaItemPlaylistItemPlaylist',?,?,4,0)",(irow,pl_rowid))
        # 7) secondaryIndex
        cur.execute("INSERT INTO secondaryIndex_mediaItemPlaylistIndex(rowid,name) VALUES(?,?)",(pl_rowid,PLAYLIST_NAME))
        # 8) FTS (playlist name searchable)
        try:
            cur.execute("INSERT INTO fts_searchIndex(docid,playlist) VALUES(?,?)",(pl_rowid,PLAYLIST_NAME))
            fts_ok=True
        except Exception as e:
            fts_ok=False; fts_err=str(e)
        # 9) bump yap2 snapshot
        cur.execute("SELECT data FROM yap2 WHERE extension='' AND key='snapshot'")
        snap=cur.fetchone()[0]
        cur.execute("UPDATE yap2 SET data=? WHERE extension='' AND key='snapshot'",(snap+1,))
        con.commit()
        if verbose:
            print(f"OK playlist_uuid={pl_uuid}")
            print(f"   pl_rowid={pl_rowid} page_key={page_key}")
            print(f"   item_rowids={item_rowids}")
            print(f"   FTS inserted={fts_ok}"+("" if fts_ok else f" ({fts_err})"))
            print(f"   snapshot {snap} -> {snap+1}")
        return pl_uuid, pl_rowid, page_key, item_rowids
    except Exception:
        con.rollback(); raise
    finally:
        con.close()

if __name__=='__main__':
    create_playlist(sys.argv[1])
