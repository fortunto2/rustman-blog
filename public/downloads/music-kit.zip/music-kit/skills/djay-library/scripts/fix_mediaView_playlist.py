#!/usr/bin/env python3
"""Add a playlist rowid to the `mediaView` view's group='playlist' page — the view djay
ACTUALLY renders the sidebar playlist list from. Missing here = playlist invisible even
if present in database2 + mediaItemPlaylistsView + relationship + childUUIDs.
Inserts at the alphabetically-correct position (djay sorts the playlist group by name).

Usage: python3 fix_mediaView_playlist.py <MediaLibrary.db> <PLAYLIST_ROWID> <PLAYLIST_NAME>
Preconditions: djay CLOSED, backup, wal_checkpoint before+after.
"""
import sqlite3, struct, sys

def ss(b):
    o=[];i=0
    while i<len(b):
        if b[i]==0x08:
            j=b.find(b'\x00',i+1)
            if j<0:break
            o.append(b[i+1:j].decode('utf-8','replace'));i=j+1
        else:i+=1
    return o

def fix(db, pl_rowid, pl_name):
    con=sqlite3.connect(db); cur=con.cursor()
    row=cur.execute("SELECT pageKey,count,data FROM view_mediaView_page WHERE \"group\"='playlist'").fetchone()
    if not row:
        print("no group='playlist' page in mediaView"); return
    pk,cnt,data=row
    rowids=[struct.unpack('<q',data[i:i+8])[0] for i in range(0,len(data),8)]
    if pl_rowid in rowids:
        print(f"already in mediaView playlist page ({len(rowids)})"); con.close(); return
    # resolve current names to find alphabetical insert index (case-insensitive, matches djay order)
    names={}
    for r in rowids:
        d=cur.execute("SELECT data FROM database2 WHERE rowid=?",(r,)).fetchone()
        s=ss(d[0]); names[r]=s[3] if len(s)>3 else ''
    # djay order observed = case-insensitive, Latin before Cyrillic; emulate by keeping existing
    # order and inserting new name where it sorts among neighbours by casefold.
    order=rowids[:]
    key=pl_name.casefold()
    idx=len(order)
    for i,r in enumerate(order):
        if key < names[r].casefold():
            idx=i; break
    order.insert(idx, pl_rowid)
    newdata=b''.join(struct.pack('<q',r) for r in order)
    cur.execute("BEGIN")
    cur.execute("UPDATE view_mediaView_page SET count=?,data=? WHERE pageKey=?",(len(order),newdata,pk))
    cur.execute("INSERT INTO view_mediaView_map(rowid,pageKey) VALUES(?,?)",(pl_rowid,pk))
    snap=cur.execute("SELECT data FROM yap2 WHERE extension='' AND key='snapshot'").fetchone()[0]
    cur.execute("UPDATE yap2 SET data=? WHERE extension='' AND key='snapshot'",(snap+1,))
    con.commit()
    print(f"OK inserted rowid={pl_rowid} at idx={idx}/{len(order)-1}; page count {cnt}->{len(order)}")
    print("integrity:",cur.execute("PRAGMA integrity_check").fetchone()[0])
    con.close()

if __name__=='__main__':
    fix(sys.argv[1], int(sys.argv[2]), sys.argv[3])
