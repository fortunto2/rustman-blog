#!/usr/bin/env python3
"""Fully remove a playlist and its items from the djay library (all structures).
Use to clean up an orphaned externally-injected playlist. Reverses every table:
database2 (playlist + item rows), relationship edges, both playlist views (page+map),
mediaView (page+map), secondaryIndex, FTS, and root.childUUIDs.

Usage: python3 delete_playlist.py <MediaLibrary.db> <PLAYLIST_ROWID>
Preconditions: djay CLOSED, backup, wal_checkpoint before+after.
"""
import sqlite3, struct, sys

def ss(b):  # parse TSAF body (skip 20-byte header)
    b=b[20:] if len(b)>20 and b[:4]==b'TSAF' else b
    o=[];i=0
    while i<len(b):
        if b[i]==0x08:
            j=b.find(b'\x00',i+1)
            if j<0:break
            o.append(b[i+1:j].decode('utf-8','replace'));i=j+1
        else:i+=1
    return o

def delete(db, pl_rowid):
    con=sqlite3.connect(db); cur=con.cursor()
    row=cur.execute("SELECT key,data FROM database2 WHERE rowid=? AND collection='mediaItemPlaylists'",(pl_rowid,)).fetchone()
    if not row: print("playlist rowid not found"); return
    pl_uuid, blob = row
    name = (ss(blob)+['?'])[3]
    # item rowids: everything in mediaItemPlaylistItems whose blob references this playlistUUID
    item_rowids=[]
    for rr,dd in cur.execute("SELECT rowid,data FROM database2 WHERE collection='mediaItemPlaylistItems'"):
        s=ss(dd)
        if len(s)>=4 and s[3]==pl_uuid: item_rowids.append(rr)
    allrows=[pl_rowid]+item_rowids
    ph=",".join("?"*len(allrows))
    cur.execute("BEGIN")
    try:
        # relationship: any edge touching playlist or its items
        cur.execute(f"DELETE FROM relationship_relationship WHERE src IN ({ph}) OR dst IN ({ph})", allrows+allrows)
        rel=cur.rowcount
        # items view (view_mediaItemPlaylistView): page(group=uuid) + map(item rowids)
        cur.execute("DELETE FROM view_mediaItemPlaylistView_page WHERE \"group\"=?",(pl_uuid,))
        cur.execute(f"DELETE FROM view_mediaItemPlaylistView_map WHERE rowid IN ({ph})", allrows)
        # sidebar hierarchy view + mediaView + secondaryIndex (playlist rowid only)
        for t in ("view_mediaItemPlaylistsView_map","view_mediaView_map","secondaryIndex_mediaItemPlaylistIndex"):
            cur.execute(f"DELETE FROM {t} WHERE rowid=?",(pl_rowid,))
        # remove playlist rowid from any view page-data blobs that still list it (8-byte LE)
        for tbl in ("view_mediaItemPlaylistsView_page","view_mediaView_page"):
            for pk,cnt,data in cur.execute(f"SELECT pageKey,count,data FROM {tbl}").fetchall():
                if not data: continue
                ids=[struct.unpack('<q',data[i:i+8])[0] for i in range(0,len(data),8)]
                if pl_rowid in ids:
                    ids=[x for x in ids if x!=pl_rowid]
                    cur.execute(f"UPDATE {tbl} SET count=?,data=? WHERE pageKey=?",(len(ids),b''.join(struct.pack('<q',x) for x in ids),pk))
        # FTS (playlist name index)
        try: cur.execute("DELETE FROM fts_searchIndex WHERE docid=?",(pl_rowid,))
        except Exception: pass
        # root.childUUIDs: drop pl_uuid if present (rebuild array)
        rb=cur.execute("SELECT data FROM database2 WHERE key='mediaItemPlaylist-root'").fetchone()[0]
        rs=ss(rb)
        if 'childUUIDs' in rs and pl_uuid in rs[6:rs.index('childUUIDs')]:
            strc=struct.unpack('<I',rb[16:20])[0]; ai=rb.find(b'\x0c\x00\x00'); ac=struct.unpack('<I',rb[ai+3:ai+7])[0]
            tok=b'\x08'+pl_uuid.encode()+b'\x00'; ti=rb.find(tok)
            rb2=(rb[:16]+struct.pack('<I',strc-1)+rb[20:ai+3]+struct.pack('<I',ac-1)+rb[ai+7:ti]+rb[ti+len(tok):])
            cur.execute("UPDATE database2 SET data=? WHERE key='mediaItemPlaylist-root'",(rb2,))
        # database2 rows (playlist + items)
        cur.execute(f"DELETE FROM database2 WHERE rowid IN ({ph})", allrows)
        # bump snapshot
        snap=cur.execute("SELECT data FROM yap2 WHERE extension='' AND key='snapshot'").fetchone()[0]
        cur.execute("UPDATE yap2 SET data=? WHERE extension='' AND key='snapshot'",(snap+1,))
        con.commit()
        print(f"OK deleted playlist '{name}' rowid={pl_rowid} + {len(item_rowids)} items; relationship rows removed={rel}")
        print("integrity:",cur.execute("PRAGMA integrity_check").fetchone()[0])
    except Exception:
        con.rollback(); raise
    finally:
        con.close()

if __name__=='__main__':
    delete(sys.argv[1], int(sys.argv[2]))
