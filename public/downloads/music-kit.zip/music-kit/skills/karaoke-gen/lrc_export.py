#!/usr/bin/env python3
"""whisperx word-json -> enhanced LRC (word-level) + copy json next to track.
Usage: lrc_export.py vocals.json /path/to/track.mp3"""
import json, sys, shutil
from pathlib import Path
j, track = sys.argv[1], Path(sys.argv[2])
d = json.load(open(j, encoding="utf-8"))
lines = []
for seg in d.get("segments", []):
    ws = [w for w in seg.get("words", []) if "start" in w]
    if not ws: continue
    t0 = ws[0]["start"]
    stamp = f"[{int(t0//60):02d}:{t0%60:05.2f}]"
    body = " ".join(f"<{int(w['start']//60):02d}:{w['start']%60:05.2f}>{w['word'].strip()}" for w in ws)
    lines.append(stamp + body)
lrc = track.with_suffix(".lrc")
lrc.write_text("\n".join(lines) + "\n", encoding="utf-8")
shutil.copy(j, track.with_suffix(".words.json"))
print(f"{lrc.name}: {len(lines)} строк")
