#!/usr/bin/env python3
"""WhisperX word-level JSON -> ASS karaoke (\\kf per word).
Current line bottom-center with sweep fill; next line dim above."""
import json
import sys

src, dst = sys.argv[1], sys.argv[2]
data = json.load(open(src, encoding="utf-8"))

# collect words
words = []
for seg in data.get("segments", []):
    for w in seg.get("words", []):
        if "start" in w and "end" in w and w.get("word", "").strip():
            words.append((w["start"], w["end"], w["word"].strip()))

# group into lines: break on pause > 0.9s or > 7 words
lines = []
cur = []
for i, (s, e, t) in enumerate(words):
    if cur and (s - cur[-1][1] > 0.9 or len(cur) >= 7):
        lines.append(cur)
        cur = []
    cur.append((s, e, t))
if cur:
    lines.append(cur)


def ts(t):
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


HEAD = """[Script Info]
PlayResX: 1280
PlayResY: 720
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: K,Arial,64,&H0000D7FF,&H00FFFFFF,&H00101018,&H00000000,-1,0,0,0,100,100,0,0,1,3,0,2,40,40,120,1
Style: Next,Arial,44,&H00707078,&H00707078,&H00101018,&H00000000,0,0,0,0,100,100,0,0,1,2,0,2,40,40,40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

ev = []
for i, line in enumerate(lines):
    start = max(0.0, line[0][0] - 0.8)
    end = line[-1][1] + 0.3
    # lead-in gap before first word becomes initial \k pause
    parts = []
    pre = int((line[0][0] - start) * 100)
    if pre > 0:
        parts.append(f"{{\\k{pre}}}")
    prev_end = line[0][0]
    for s, e, t in line:
        gap = int((s - prev_end) * 100)
        if gap > 2:
            parts.append(f"{{\\k{gap}}}")
        parts.append(f"{{\\kf{max(1, int((e - s) * 100))}}}{t} ")
        prev_end = e
    ev.append(f"Dialogue: 0,{ts(start)},{ts(end)},K,,0,0,0,,{''.join(parts).rstrip()}")
    # preview of next line
    if i + 1 < len(lines):
        nxt = " ".join(t for _, _, t in lines[i + 1])[:60]
        ev.append(f"Dialogue: 0,{ts(start)},{ts(end)},Next,,0,0,0,,{nxt}")

open(dst, "w", encoding="utf-8").write(HEAD + "\n".join(ev) + "\n")
print(f"lines={len(lines)} words={len(words)} -> {dst}")
