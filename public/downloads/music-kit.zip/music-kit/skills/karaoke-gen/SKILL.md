---
name: karaoke-gen
description: Generate word-synced karaoke videos from any song — original audio, canonical lyrics, teleprompter-style 5-line display with per-word fill sweep. Use when user says "сделай караоке", "авто-караоке", "сгенерируй караоке для <песня>", asks to sync lyrics to a track, or wants to fix/replace a bad karaoke minus. Also covers muxing existing karaoke video with original audio (audio cross-correlation sync).
---

# karaoke-gen — авто-караоке из любого трека

Result: `<Artist> - <Title> (авто-караоке).mp4` in `~/Music/Karaoke/<язык>/` —
original audio + teleprompter lyrics (5 lines centered, current line \kf word-sweep,
sung lines dim green above, upcoming gray below, smooth 320ms slide).
User removes vocals live via djay Pro Neural Mix stems — never bake a minus in.

## Pipeline (per track)

Working dir: session scratchpad. Venv `kx` (demucs+whisperx) — create once:
`/opt/homebrew/bin/python3.13 -m venv kx && kx/bin/pip install demucs whisperx`
(NOT ~/.local/bin/python — Pyodide trap).

1. **Canonical lyrics** (критично — ASR-текст полон опечаток, особенно рэп):
   - EN: `curl https://api.lyrics.ovh/v1/<Artist>/<Title>` (JSON .lyrics); fallback azlyrics/genius via curl+parse.
   - RU: litprichal.ru / mysongs.pro — curl + strip `<br>` tags (WebFetch отказывается отдавать полный текст — парсить самому).
   - Проверить полноту: все куплеты на месте, порядок секций = как реально поётся (сверить с ASR-сегментами). Убрать метки [Припев]/[Verse].
   - Файл: `lyrics_canon.txt`, одна строка = одна караоке-строка (родные переносы из источника).
2. **Vocals**: `kx/bin/demucs --two-stems=vocals -o separated -n htdemucs "<song>"` (~1 мин/трек на M1).
3. **Word timings**: `kx/bin/whisperx separated/htdemucs/<track>/vocals.wav --model medium --language <ru|en> --output_format json --output_dir wxout --compute_type int8`.
4. **Align + ASS**: `align_teleprompter.py` (в этой папке; поправить пути S/audio/lyrics/out внутри или обобщить):
   difflib matching канон-слов на ASR-слова (норм.: lower, ё→е, только буквы) → тайминги; несматченные интерполируются между якорями; monotonic-fix. Обычно матчится 70-85% — этого достаточно.
5. **Render** (ffmpeg БЕЗ libass — использовать ffmpeg-full!):
   `/opt/homebrew/opt/ffmpeg-full/bin/ffmpeg -f lavfi -i "color=c=0x0d0d14:s=1280x720:r=25" -i song.mp3 -filter_complex "[0:v]ass=karaoke.ass[v]" -map "[v]" -map 1:a -c:v h264_videotoolbox -b:v 2500k -c:a aac -b:a 192k -shortest -movflags +faststart out.mp4`
   ⚠️ ass= путь: только относительный без спецсимволов (cd в папку с .ass), иначе парсер фильтра падает.
6. **Verify по кадрам** (обязательно): извлечь 3-4 кадра (припев, быстрый куплет, переход), посмотреть глазами: опечатки, вылезание за экран, попадание подсветки. Править текст/строки → пересобрать ASS → перерендер (быстро, тяжёлые шаги кешируются).

## Мелочи и грабли

- ASR галлюцинирует на интро/выкриках («Ура!» → «Санта») — канон всё чинит, интро остаётся без строк, это норм.
- Повторяющиеся припевы difflib выравнивает по порядку корректно.
- Длинные строки >55 символов: разбить на две в lyrics_canon.txt.
- Цензурные звёздочки в тексте оставлять (норм для экрана), matching их игнорирует.
- Уже есть чужое караоке-видео с хорошим текстом, но кривым минусом → альтернатива: mux видео + оригинал-аудио с синком по кросс-корреляции (numpy FFT, скрипт sync_mux в истории; лаг обычно < 0.2s, проверять дрейф в конце).
- Русские буквы в имени выходного файла — ок; жанр тега не ставить (это видео).

## Хранение таймингов при треке (конвенция)
После любой разметки вокала сохранять РЯДОМ с треком (тот же basename):
- `<track>.lrc` — enhanced LRC с пословными тегами `<mm:ss.xx>` (универсальный формат синхро-текста для музыки, играется плеерами) — `lrc_export.py <vocals.json> <track>`;
- `<track>.words.json` — полный whisperx word-json (источник истины для караоке/EDL-мэшапов).
Канон-выровненный LRC (текст настоящий) предпочтительнее сырого ASR — если есть lyrics_canon, прогонять align и экспортировать из выровненных слов.
