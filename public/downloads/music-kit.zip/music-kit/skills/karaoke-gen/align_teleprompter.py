#!/usr/bin/env python3
"""Align canonical lyrics to whisperx word timings; render teleprompter ASS.
5-line centered window, current line karaoke-swept, smooth slide between lines."""
import difflib
import json
import re

import sys
JSON_IN, LYRICS_IN, ASS_OUT = sys.argv[1], sys.argv[2], sys.argv[3]


def norm(w):
    w = w.lower().replace("ё", "е")
    return re.sub(r"[^a-zа-я0-9]", "", w)


# canonical lines/words
canon_lines = [l.strip() for l in open(LYRICS_IN, encoding="utf-8") if l.strip()]
cwords = []  # (line_idx, word)
for li, line in enumerate(canon_lines):
    for w in line.split():
        if norm(w):
            cwords.append((li, w))

# asr words
d = json.load(open(JSON_IN, encoding="utf-8"))
awords = []
for seg in d["segments"]:
    for w in seg.get("words", []):
        if "start" in w and norm(w.get("word", "")):
            awords.append((w["start"], w["end"], w["word"]))

cn = [norm(w) for _, w in cwords]
an = [norm(w) for _, _, w in awords]
sm = difflib.SequenceMatcher(None, cn, an, autojunk=False)
starts = [None] * len(cwords)
ends = [None] * len(cwords)
matched = 0
for a, b, size in sm.get_matching_blocks():
    for k in range(size):
        starts[a + k] = awords[b + k][0]
        ends[a + k] = awords[b + k][1]
        matched += 1
print(f"matched {matched}/{len(cwords)} canonical words")

# interpolate gaps, enforce monotonic
anchor = [(i, starts[i], ends[i]) for i in range(len(cwords)) if starts[i] is not None]
for i in range(len(cwords)):
    if starts[i] is None:
        prev = next((a for a in reversed(anchor) if a[0] < i), None)
        nxt = next((a for a in anchor if a[0] > i), None)
        if prev and nxt:
            frac = (i - prev[0]) / (nxt[0] - prev[0])
            t0 = prev[2] + (nxt[1] - prev[2]) * frac
            t1 = prev[2] + (nxt[1] - prev[2]) * (frac + 0.8 / (nxt[0] - prev[0]))
        elif prev:
            t0 = prev[2] + 0.3 * (i - prev[0])
            t1 = t0 + 0.25
        elif nxt:
            t0 = max(0, nxt[1] - 0.3 * (nxt[0] - i))
            t1 = t0 + 0.25
        else:
            t0, t1 = 0.0, 0.25
        starts[i], ends[i] = t0, min(t1, t0 + 1.5)
# monotonic fix
for i in range(1, len(cwords)):
    if starts[i] < starts[i - 1]:
        starts[i] = starts[i - 1] + 0.05
    if ends[i] < starts[i]:
        ends[i] = starts[i] + 0.2

# line timings + words per line
lines = []
for li, line in enumerate(canon_lines):
    idx = [i for i, (l, _) in enumerate(cwords) if l == li]
    if not idx:
        continue
    ws = [(starts[i], ends[i], cwords[i][1]) for i in idx]
    lines.append({"text": line, "start": ws[0][0], "end": ws[-1][1], "words": ws})

# phases (gap-aware: long instrumental breaks clear the screen)
GAP = 6.0
for i, L in enumerate(lines):
    prev_end = lines[i - 1]["end"] if i > 0 else 0.0
    lead = 3.0 if (L["start"] - prev_end) > GAP else 0.25
    L["pstart"] = max(prev_end, L["start"] - lead)
for i, L in enumerate(lines):
    if i + 1 < len(lines):
        nxt = lines[i + 1]
        if (nxt["start"] - L["end"]) > GAP:
            L["pend"] = L["end"] + 2.0
        else:
            L["pend"] = nxt["pstart"]
    else:
        L["pend"] = L["end"] + 3


def ts(t):
    t = max(0, t)
    return f"{int(t//3600)}:{int(t%3600//60):02d}:{t%60:05.2f}"


HEAD = """[Script Info]
PlayResX: 1280
PlayResY: 720
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cur,Arial,52,&H0000D7FF,&H00FFFFFF,&H000A0A10,&H00000000,-1,0,0,0,100,100,0,0,1,3,0,5,30,30,0,1
Style: Off,Arial,52,&H00909098,&H00909098,&H000A0A10,&H00000000,0,0,0,0,100,100,0,0,1,2,0,5,30,30,0,1
Style: Done,Arial,52,&H00506850,&H00506850,&H000A0A10,&H00000000,0,0,0,0,100,100,0,0,1,2,0,5,30,30,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
DY = 82
CY = 360
ev = []
# Static-slot page mode: no motion at all. Active line always dead-center;
# slots update via short crossfade. (Static blocks read faster than
# scrolling text — subtitle/RSVP reading studies.)
for p, L in enumerate(lines):
    ps, pe = L["pstart"], L["pend"]
    if pe - ps < 0.1:
        pe = ps + 0.1
    for i in range(max(0, p - 1), min(len(lines), p + 3)):
        off = i - p
        y = CY + off * DY
        Li = lines[i]
        if off == 0:
            parts = [f"{{\\pos(640,{y})}}{{\\fad(90,0)}}"]
            pre = int((Li["words"][0][0] - ps) * 100)
            if pre > 2:
                parts.append(f"{{\\k{pre}}}")
            prev_end = Li["words"][0][0]
            for s0, e0, w in Li["words"]:
                gap = int((s0 - prev_end) * 100)
                if gap > 3:
                    parts.append(f"{{\\k{gap}}}")
                parts.append(f"{{\\kf{max(1, int((e0-s0)*100))}}}{w} ")
                prev_end = e0
            ev.append(f"Dialogue: 1,{ts(ps)},{ts(pe)},Cur,,0,0,0,,{''.join(parts).rstrip()}")
        else:
            style = "Done" if off < 0 else "Off"
            alpha = "{\\alpha&H60&}" if off == 2 else ""
            ev.append(f"Dialogue: 0,{ts(ps)},{ts(pe)},{style},,0,0,0,,{{\\pos(640,{y})}}{{\\fad(90,60)}}{alpha}{Li['text']}")

# instrumental break markers
for i in range(len(lines) - 1):
    if lines[i + 1]["pstart"] - lines[i]["pend"] > 0.5:
        ev.append(f"Dialogue: 0,{ts(lines[i]['pend'])},{ts(lines[i+1]['pstart'])},Off,,0,0,0,,{{\\pos(640,360)}}♪ ♪ ♪")
if lines and lines[0]["pstart"] > 1.5:
    ev.append(f"Dialogue: 0,{ts(0)},{ts(lines[0]['pstart'])},Off,,0,0,0,,{{\\pos(640,360)}}♪ ♪ ♪")

open(ASS_OUT, "w", encoding="utf-8").write(HEAD + "\n".join(ev) + "\n")
print(f"lines={len(lines)} events={len(ev)} -> {ASS_OUT}")
