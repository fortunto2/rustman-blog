---
name: stem-split
description: Separate a song into stems (vocals / drums / bass / other) with Demucs, run headlessly via uvx (no persistent install). Use whenever you need an isolated vocal/acapella, an instrumental, or drum/bass/melody stems — for mashups (sdsp-mash), sample chops (Daft Punk / Fred again.. flips), karaoke, remixing, or analysis. Works on mp3/flac/wav/m4a.
---

# stem-split — Demucs stem separation via uvx

Isolate **vocals / drums / bass / other** from any track. Runs Demucs
(Meta's `htdemucs`) on demand through **uvx** — nothing to install, uv caches
torch + the model after the first run.

## The command

Demucs is installed **persistently** as a uv tool — `demucs` is a plain
command on PATH (`~/.local/bin/demucs` → `~/.local/share/uv/tools/demucs`,
numpy + torch baked in). Just call it:

```bash
export PATH="$HOME/.local/bin:/opt/homebrew/bin:$PATH"
demucs -o <OUTDIR> "<input.mp3>"
```

Installed once with `uv tool install demucs --with numpy` (the `--with numpy`
is what avoids torch's `Failed to initialize NumPy` crash). To reinstall/upgrade:
`uv tool install --force demucs --with numpy`. To list: `uv tool list`.

**No-install fallback** (if the tool env is ever gone), ephemeral via uvx —
same `--with numpy` caveat, and `--from demucs` because `uvx demucs` alone
mis-resolves the entrypoint:
```bash
uvx --with numpy --from demucs demucs -o <OUTDIR> "<input.mp3>"
```

Output lands at:
```
<OUTDIR>/htdemucs/<track filename without ext>/{vocals,drums,bass,other}.wav
```
(44.1 kHz stereo WAV, float). `htdemucs` = the default 4-stem model.

## Common variants

```bash
# 4-stem (default: vocals + drums + bass + other)
uvx --with numpy --from demucs demucs -o out "song.mp3"

# 2-stem: just vocals vs the rest (fastest, clean acapella + instrumental)
uvx --with numpy --from demucs demucs --two-stems=vocals -o out "song.mp3"

# higher quality (slower): the 6-source fine-tuned model
uvx --with numpy --from demucs demucs -n htdemucs_ft -o out "song.mp3"

# write mp3 stems instead of wav
uvx --with numpy --from demucs demucs --mp3 --mp3-bitrate 320 -o out "song.mp3"

# more parallelism (uses more RAM)
uvx --with numpy --from demucs demucs -j 4 -o out "song.mp3"
```

`--two-stems=vocals` gives `vocals.wav` + `no_vocals.wav` — use it when you
only need an acapella or an instrumental (≈2× faster than the full 4-stem).

## Gotchas

- **CPU-only on this Mac (M1)** — no CUDA; a ~3-4 min song takes ~1-3 min on
  htdemucs, longer on `htdemucs_ft`. It's not instant; run it and wait, don't
  assume it hung.
- **Cyrillic / spaced filenames** work — always quote the path.
- **`timeout` isn't on macOS** — don't wrap the command in `timeout`; just let
  the Bash tool's own limit apply, or run in the background for long batches.
- **The `htdemucs/<name>/` folder can exist but be empty** if a prior run was
  killed — check the four `.wav`s are actually there before using them.
- Native Python venvs work too (`pip install demucs`), but uvx avoids a
  multi-GB persistent env; the venv path in older notes (`scratchpad/kx`) is
  per-session and won't survive — prefer uvx.

## Feeds straight into sdsp-mash / chops

The stems are exactly what `sdsp-mash` `[[track]]` wants (`role = "vocal"` for
`vocals.wav`, `beat-drums`/`beat-bass`/`beat-other` for the rest) and what a
**sample-chop flip** needs (chop the isolated `vocals.wav` = clean Fred-again..
vocal chops with no backing bleed; loop `no_vocals.wav` = a clean instrumental
bed / Daft-Punk filter loop). See the **`sdsp-mash`** skill for the mashup +
FX + master pipeline. Batch outputs already live under
`…/scratchpad/mash/htdemucs/` and `…/verify/htdemucs/` from past sessions.
