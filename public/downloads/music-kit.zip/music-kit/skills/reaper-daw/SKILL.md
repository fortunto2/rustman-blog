---
name: reaper-daw
description: Control REAPER DAW through total-reaper-mcp — create tracks, insert MIDI, manage FX chain, add markers/regions, render. Use when user asks to create/edit a REAPER project, build a track, add instruments, sketch a beat or arrangement, mix/master via REAPER. Requires the `reaper` MCP server connected (check with `claude mcp list`). Do NOT use for audio analysis of files outside REAPER, or for Logic/Ableton/FL Studio.
---

# REAPER DAW via MCP

Controls REAPER through `shiehn/total-reaper-mcp` (Lua bridge + Python MCP, file-based IPC). The bridge must be running inside REAPER for any tool to work.

## Preflight

Before any tool call, verify the bridge responds:

```
mcp__reaper__dsl_get_tempo_info
```

If it times out or errors → bridge is not running. Tell the user:
> "Bridge не отвечает. В REAPER: Actions → Show action list → Load → `mcp_bridge_file_v2.lua` → Run. В REAPER console должно появиться `REAPER MCP Bridge (File-based, Full API) started`."

The bridge script lives at `~/Library/Application Support/REAPER/Scripts/mcp_bridge_file_v2.lua` (macOS) and must be **Run** in REAPER's action list, not just loaded.

**Hardened 2026-07-24** (took effect after a server + REAPER restart):
- **Auto-start:** `~/Library/Application Support/REAPER/Scripts/__startup.lua` `dofile`s the bridge on every REAPER launch, so after a REAPER restart the bridge is already running — no manual "run the action" step. A `_G.__MCP_BRIDGE_RUNNING` guard in the bridge prevents a duplicate poll loop if it's run twice.
- **Desync-proof IPC** (`server/bridge.py`): purges stale `request_*`/`response_*` files on server init, clears the same-id pair before each request, and removes both on timeout — so a late/leftover `response_N` can never be mis-read as a new request's answer (the old sticky "Failed to get tracks info"). Timeout is now `REAPER_MCP_TIMEOUT` env (default 15 s) so bulk MIDI inserts don't spuriously time out.
- **Dialog-safe save:** `dsl_save` now writes a real `.rpp` via `Main_SaveProjectEx` (named → `~/Music/REAPER Projects/<name>.rpp`, unnamed → reuse current file or `Untitled.rpp`) — it NEVER opens a modal Save As, which used to block the whole bridge. Path dir overridable via `REAPER_MCP_PROJECT_DIR`.

## Tool profiles

The MCP server runs with a profile that limits tool count. Default profile is `dsl-production` (53 tools, natural-language DSL + essentials). To switch, edit `--profile` in `.mcp.json`:
- `dsl` (15) — minimal natural-language only
- `dsl-production` (53, default) — DSL + essential production
- `groq-essential` (146) — traditional ReaScript interface
- `full` (600+) — complete API, but may overwhelm LLM context

## Core workflow

Most operations use DSL tools (`mcp__reaper__dsl_*`) with natural-language args:

**Tempo / transport:**
- `dsl_set_tempo(bpm=70)`
- `dsl_get_tempo_info()`
- `dsl_play()`, `dsl_stop()`

**Tracks:**
- `dsl_track_create(name="Pad", role="keys")` — role hints help fuzzy match later
- `dsl_track_volume(track="Pad", volume="-8dB")` — accepts dB, linear, relative
- `dsl_track_pan(track="Lead", pan="R30")` — L50/R30/C or numeric -1..1
- `dsl_list_tracks()` — overview
- `dsl_track_delete_all()` — **destructive, confirm with user first**

**MIDI insert** — `start`/`length` in seconds (not beats):
```json
{
  "track": "Pad",
  "time": "16 bars",
  "midi_data": {
    "notes": [
      {"pitch": 60, "start": 0, "length": 4.0, "velocity": 80}
    ]
  }
}
```
Pitch is MIDI number (60 = C4, 36 = C2). At 70 BPM, 1 bar = 3.429 sec, 1 beat = 0.857 sec.

**FX management:**
- `dsl_add_effect(track, effect="reverb")` — fuzzy name match
- `track_fx_add_by_name(track_index, fx_name="Serum")` — precise add
- `track_fx_copy_to_track(source, fx_index, dest_track, move=false)` — clone with all params
- `track_fx_delete(track_index, fx_index)` — to reorder, delete and re-add

**Markers / regions:**
- `dsl_marker(action="add", name="Cm", position=0)` — seconds or "16 bars"
- `dsl_region(action="create", name="Verse", start=0, end=13.7)`

**Save / render:**
- `dsl_save(name="MyProject")` — **warning: blocks 5+ sec if REAPER opens Save As dialog**
- `render_project()` / `render_time_selection()` — full render to disk

## Known gotchas

| Issue | Cause | Workaround |
|---|---|---|
| `dsl_track_color` fails `MediaTrack expected` | bug in bridge | skip color, comment to user |
| FX chain order wrong (synth after reverb) | `dsl_add_effect` always appends | delete FX 0 via `track_fx_delete`, re-add — synth stays at 0 |
| `dsl_save` hangs | REAPER opened Save As dialog | tell user to click dialog manually |
| `track_fx_*` track index vs `dsl_*` | track_fx is 0-based, DSL messages 1-based | use track index from `dsl_track_volume` debug output as ground truth |
| Tools list shows 600+ but only 53 callable | profile=`dsl-production` | switch profile in `.mcp.json` if need more |
| **Track order REVERSED** after creating several tracks | `dsl_track_create` always `InsertTrackAtIndex(0)` = **prepend** | create tracks in **reverse** order, or `dsl_track_rename` by index afterwards. NOT a concurrency bug — parallel `dsl_midi_insert` by index lands correctly |
| `dsl_track_delete_all` says "No tracks to delete" (does nothing) | bug | delete per-track via `dsl_track_delete` by name. **No per-item delete in `dsl-production`** — only whole-track |
| `dsl_get_tempo_info` always shows `120.0 / 4/120.0` | buggy reader | `dsl_set_tempo` actually works (sets master). Verify via `Master_GetTempo` (direct IPC). Real tempo marker: `SetTempoTimeSigMarker(0,-1,0.0,-1,-1,bpm,4,4,false)`+`UpdateTimeline` |
| `track_fx_set_preset` reports success but preset NOT applied | CLAP/Serum use own preset engine (`get_preset`="No preset selected") | Serum: select preset/waveform in GUI. **Our SuperDuper synths have a dedicated stepped `Preset` param** that recalls the whole timbre — set it under playback (see `superduper-song`) |
| `track_fx_set_param` value ignored / wrong | value given normalized 0..1, but this bridge writes **RAW** units | Cutoff → Hz (1800, not 0.18), Preset → raw index (14, not 1.0), levels 0..1 as-is, dB in dB. `track_fx_get_param` prints value **and range** — use it as truth. `param_count` may be inflated but indices are correct |
| `dsl_midi_insert` note timing | `note.start`/`length` are **seconds relative to item start** (not PPQ/beats); `time={"start":s,"end":s}` places the item absolutely | compute seconds from BPM: `beat=60/bpm`, `bar=4*beat` |

## Common recipes

**Ambient sketch (16 bars, Cm):** 70 BPM, 4 tracks (Pad/Bass/Texture/Lead), chord progression `Cm → Ab → Fm → G7` every 4 bars, markers per chord change. See git history for full MIDI data example.

**Add synth to existing MIDI track:** `track_fx_add_by_name(track, "Serum")` first (must be FX 0), then `dsl_add_effect(track, "reverb")` for reverb after.

**Clone synth setup:** Configure one Serum (params + power buttons in UI), then `track_fx_copy_to_track(source=3, fx_index=0, dest_track=0)` to mirror exact settings on another track.

**Bulk ops / missing API via direct IPC (escape hatch):** the bridge runs ANY `reaper.*` function by name (generic passthrough near the end of `mcp_bridge_file_v2.lua`). File IPC dir: `~/Library/Application Support/REAPER/Scripts/mcp_bridge_data/`. Write `request_<N>.json` = `{"id":N,"func":"ReaperFunc","args":[...]}`, read `response_<N>.json` (`{"ok":true,"ret":...,"item_index":...}`); the bridge deletes the request after processing. The MCP server increments `request_id` from 0 — **use free high slots (700+)** to avoid collision. Always write to a `.tmp` then `os.rename` (atomic) so the bridge never reads a half-written request. Use for setting tempo (`SetTempoTimeSigMarker`+`UpdateTimeline`) or item ops absent from `dsl-production`.
  - ⚠️ **Pointers DON'T round-trip.** The bridge refuses a `{"__ptr":…}` from a previous call ("Cannot use … pointer from previous call - use track index instead"). So anything needing a `MediaItem`/`Take`/`Envelope` pointer chain (delete media item, `InsertMIDINote` loop, `SetParam` by track ptr) **can't be done via direct IPC** — use the MCP `dsl_*` / `track_fx_*` tools, which resolve pointers inside one Lua exec. Direct IPC is only for pointer-free single calls (`Master_GetTempo`, `CountTracks`, `Main_OnCommand`, tempo markers).
  - 🚨 **NEVER interleave direct IPC with MCP tool calls in the same burst.** Doing so **desyncs the Python MCP server** from the bridge: the bridge stays alive (direct pings still answer) but every MCP tool starts returning `Failed to get tracks info` / `Timeout waiting for REAPER response`. Recovery: **stop ALL direct IPC and wait ~10-30 s** (the server often drains and recovers on its own); if it stays stuck, have the user **re-run the bridge action in REAPER** (Actions → `mcp_bridge_file_v2.lua` → Run) to reset it, or reconnect the `reaper` MCP. The project itself is unaffected — verify with `CountTracks`/`CountMediaItems` via a single direct ping. Prefer MCP-only OR direct-IPC-only for a whole task, never both.

## Related

- **`superduper-song`** — making songs with OUR plugins (Wave/Kubyz/Drum/Pad/Sampler): full param maps by name, preset-recall indices, CC expression, audio→MIDI. Use this whenever the instruments are ours.
- For Serum-specific parameter tuning, see `serum-synth` skill.
- Project-level setup details: `CLAUDE.md` in the REAPER project root.
