---
name: ableton-live
description: Control Ableton Live through the producer-pal MCP (Max for Live device) — read/build tracks, write MIDI clips in bar|beat notation, build drum racks, arrange songs on the timeline (Arrangement View), load instruments/samples from Live's library, apply groove/swing/humanize transforms, and drive playback. Use when the user asks to create/edit an Ableton project, sketch a beat, build an arrangement, design a sound, or jam in Live. Requires the `producer-pal` MCP server connected AND the Producer_Pal.amxd device loaded on a track in Live. Do NOT use for REAPER (use reaper-daw), Logic/FL, or audio file analysis outside Live.
---

# Ableton Live via Producer Pal MCP

Controls Ableton Live through **producer-pal** (adamjmurray) — a Max for Live device (`Producer_Pal.amxd`) that hosts an MCP server inside Live. All tools are namespaced `mcp__producer-pal__ppal-*`.

## Preflight (every session)

1. **Always call `ppal-connect` first.** It initializes the bridge AND returns the full, authoritative bar|beat/notation/transforms reference in its `skills` field — read that, it is the source of truth for syntax. Nothing else works until connect succeeds.
2. If connect fails: the device isn't loaded. Tell the user:
   > "Открой Ableton, перетащи `~/Music/1music/tools/producer-pal/Producer_Pal.amxd` на MIDI-трек (должно показать «Producer Pal Running»), затем скажи «connect to ableton»."
3. **Trial caveat (this machine):** Max for Live runs only under `Ableton Live 12 Trial` (full Suite, time-limited) — `Live 12 Lite` has NO M4L. When the Trial expires, producer-pal stops. Fallback: `xiaolaa2/ableton-copilot-mcp` (no M4L, Live 12+).

Config: `producer-pal` is in project `.mcp.json` as stdio `npx producer-pal` (auto-reconnect; also serves `http://localhost:3350/mcp`).

**REST fallback (no MCP):** if the MCP server is down (headless/cron, or `claude mcp list` shows it failed) the device still exposes a REST API. Use the bundled zero-dep CLI: `node ~/Music/1music/tools/producer-pal/ppal.mjs --list-tools` and `node …/ppal.mjs ppal-connect`, `node …/ppal.mjs ppal-read-track '{"trackIndex":0}'` (args = JSON). This is producer-pal's own `examples/skills/producer-pal/ppal.mjs`, kept as a fallback — prefer the `mcp__producer-pal__*` tools when MCP is up.

## Tool map

| Job | Tool |
|---|---|
| Connect / init | `ppal-connect` |
| Read set overview (tracks/scenes/locators) | `ppal-read-live-set` (`include:["tracks","scenes","locators","mixer",...]`) |
| Read a track (clips/devices/**drum-map**/notes) | `ppal-read-track` (`include:["drum-map","devices","arrangement-clips","notes",...]`) |
| Read clip / scene / device | `ppal-read-clip`, `ppal-read-scene`, `ppal-read-device` (`include:["params","actions","options","sample"]`) |
| Global tempo / key / locators | `ppal-update-live-set` (`tempo`, `scale:"F Minor"`, `timeSignature`, locator ops) |
| Create track(s) | `ppal-create-track` (`type`, `count`, `name`/`color` comma-lists) |
| Create device/instrument | `ppal-create-device` (`deviceName`, `path:"t4"`, `params`) — omit `deviceName` to list devices |
| Create clip (MIDI/audio) | `ppal-create-clip` |
| Edit clip notes / move / split | `ppal-update-clip` (`notes` merges; `preTransforms`/`transforms`; `arrangementStart` moves) |
| Search Live library / plugins | `ppal-library` (`action:"search"|"searchBatch"|"listPlugins"|"findSimilar"...`) |
| Tracks: vol/pan/sends/route/arm | `ppal-update-track` (`sendReturn`,`sendGainDb`,`gainDb`,`pan`,...) |
| Scenes | `ppal-create-scene`, `ppal-update-scene` |
| Duplicate (track/clip, take lanes) | `ppal-duplicate` |
| Delete (track/clip/device/drum-pad) | `ppal-delete` (comma-separated paths) |
| Select / open plugin window | `ppal-select` (`openPluginWindow`) |
| Playback (arrangement/session) | `ppal-playback` |
| Project context / notes | `ppal-context` |

## bar|beat & MIDI notation (essentials — full spec in connect's `skills`)

Clip notes string: `v0-127 n<dur> [p0-1] note(s) bar|beat(s)`. v/n/p are **stateful prefixes** that persist until changed.

- **Positions** `bar|beat`, 1-indexed, meter-relative: `4|2` = bar 4 beat 2. Beat lists/repeats: `1|1,2,3,4`; `1|1x4@n/4` (4 notes a quarter apart). Sub-beat decimal `2|3.5`; exact offset `1|1+n/12` (triplet). Pickup before bar 1: `1|1-n/8`.
- **Durations** = absolute note values, denominator mandatory: `n/4` quarter, `n/8` eighth, `n/16`, `n/12` eighth-triplet, `n/1` whole note (= 1 bar in 4/4), `n3/8` dotted quarter. Bars: `Nbar` (meter-aware) for clip `length`/arrangement (`4bar`), bare form never `n`-prefixed.
- **Notes**: `C3` = middle C. So drum-rack `C1` = MIDI 36. Sharps/flats `C#3`/`Bb2`, case-insensitive.
- **Velocity**: `v100` default; range `v80-120` humanizes per note; `v0` deletes earlier same-pitch/time note.
- **Bar copy (MERGES)**: `@2=1` copy bar 1→2; `@2-3=1` copy to 2,3; `@5-7=1`. Use `v0` to clear unwanted copied notes.
- Chords = multiple pitches before one time: `F3 Ab3 C4 1|1`. Melodic bracket: `[C3 E3 G3] 1|1x3@n/4`.

## Workflows

**Drum track:** `ppal-create-device deviceName="Drum Rack" path="t4"` with `params` setting each pad's sample by path — one call builds a kit:
```
params: [{name:"pC1/d0/sample", value:"<abs path kick>"},
         {name:"pD1/d0/sample", value:"<abs path clap>"}, ...]
```
Find samples with `ppal-library` (`type:"oneshot"`, `tags`, or `searchBatch` for a whole kit). **Then `ppal-read-track include:["drum-map"]` to confirm pad→pitch** (don't assume GM). Set `n` per drum lane (a hat's `n/16` leaks onto the next kick otherwise); space repeats with `1|1xN`, not hand-listed beats.

**Arrangement (Arrangement View):** `ppal-create-clip` with `trackIndex` + `arrangementStart` (song meter). **Tile a loop by passing comma-separated positions** — same notes at each: `arrangementStart:"5|1,9|1,13|1"` makes 3 copies. `length` in `Nbar`. Build structure by placing different clips per section (intro/build/drop). Move clips with `update-clip arrangementStart`; split with `split`. **Take lanes** (variations) via `takeLane:"new"` on create/duplicate. Then `ppal-playback action:"play-arrangement"` with `loop`/`loopStart`/`loopEnd`.

**Session (jam):** clips into `slot:"trackIndex/sceneIndex"` (0-based); `auto:"play-scene"`; `ppal-playback action:"play-scene"`.

**Transforms (groove)** — add `transforms` (or `preTransforms` to edit existing notes first) to create/update-clip:
- Swing: `timing = swing(0.04, n/16)` (auto-quantizes to grid then swings; amount in beats: 0.02 subtle … 0.1 heavy).
- Humanize: `timing += 0.05 * rand()`, velocity `v80-120` ranges.
- Rolls/echoes: `C1: ratchet(4)`, `repeat(n/8, 3)`. Crescendo: `1|1-4|4.75: velocity = ramp(40,127)`.
- Filters: `where(note.velocity < 40): delete`. Use `=` (idempotent) vs `+=` (compounds on re-run).

**Sound design (native devices):** read a device's controllable surface at runtime — `ppal-read-device include:["params","actions","options"]` — rather than guessing. Drift/Wavetable/Operator for synths; mod matrix and engine/wavetable selection are pseudo-params/actions (see connect skills doc).

**Escape hatch — `ppal-live-api`:** direct read/write to the [Live Object Model](https://docs.cycling74.com/apiref/lom/) for anything the high-level tools don't cover. **Off by default** and absent from our `dsl`-style profile — if it's missing, ask the user to enable **Direct Live API** on the device's **Setup** tab. Use only when no `ppal-*` tool fits.

## Gotchas

- **Moving a clip changes its ID** → re-read the track to get new IDs before further edits.
- **`scale` set on the Live Set** applies to new clips' defaults and `snap()`; writing explicit out-of-scale notes (e.g. the dominant's leading tone) still works — Producer Pal won't force-snap unless you call `snap()`.
- **VST/AU plugin internals are NOT controllable** — only parameters the user maps in Live's Configure mode become readable/settable. `ppal-select openPluginWindow` opens the editor for manual work. Native Live devices are fully controllable.
- **Audio is opaque**: can place/warp/gain/pitch audio clips and load samples, but cannot analyze/transcribe audio → no audio→MIDI, no key/tempo detection from a waveform, no audio synthesis from scratch.
- **Producer Pal can't** comp take lanes, edit automation envelopes, or map macro/plugin params — explain the manual Live step and link the [Live manual](https://www.ableton.com/live-manual/12) when asked.
- **Device paths**: `t`=track, `rt`=return, `mt`=master, `d`=device, `c`=chain, `p`=drum pad. `t0/d0/pC1/d0` = device in Drum Rack's C1 pad.

## Sample sources (this machine)

Core library lives under both `…/Ableton Live 12 Trial.app/Contents/App-Resources/Core Library/Samples/One Shots/Drums/{Kick,Clap,Hihat,Snare}/`. User packs: `~/Music/SuperDuper Samples/`, `~/Music/Favorite 808s/`. Prefer `ppal-library searchBatch` to discover paths.

## Related

Project notes & Trial blocker: see auto-memory `project-producer-pal-ableton-mcp`. For our own CLAP plugins/DSP use REAPER (`reaper-daw` skill) — producer-pal drives Live's native devices only.
