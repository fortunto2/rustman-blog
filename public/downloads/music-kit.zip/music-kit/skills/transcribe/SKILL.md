---
name: transcribe
description: Transcribe any audio or video to text LOCALLY and privately (nothing leaves the machine). Use when the user says "transcribe this", "расшифруй запись/звонок/разговор", "достань запись из диктофона/зума", "make a transcript", references a Zoom/Meet recording, a Voice Memo, or gives a path to an audio/video file. Handles finding the recording (Voice Memos DB, Zoom folder), extracting audio, and producing a timestamped transcript (+ optional speaker labels).
---

# transcribe — local, private transcription of any audio/video

Everything runs **offline**. The audio is never uploaded — the only network step is a
one-time model-weights download. Use this for meeting recordings, calls, voice memos, etc.

## Environment (already set up)

Shared venv with faster-whisper + pyannote + ffmpeg:

```bash
source ~/.venvs/transcribe/bin/activate
```

Script lives next to this file: `~/.claude/skills/transcribe/transcribe.py`.

## 1. Find the recording

**A file path was given** → skip to step 2.

**Zoom recordings** (`~/Documents/Zoom/<YYYY-MM-DD hh.mm.ss ...>/`):
- `audioNNN.m4a` = audio only (transcribe this), `videoNNN.mp4` = video.
- Folder name timestamp = meeting **start**; file mtime ≈ meeting **end**.

```bash
ls -dt ~/Documents/Zoom/*/ | head          # newest meetings first
```

**Voice Memos** (Apple Dictaphone) — names + paths live in a SQLite DB:

```bash
DB="$HOME/Library/Group Containers/group.com.apple.VoiceMemos.shared/Recordings/CloudRecordings.db"
sqlite3 -separator ' | ' "$DB" \
  "SELECT ZCUSTOMLABEL, ZPATH,
          datetime(ZDATE+978307200,'unixepoch','localtime') AS when_local,
          ROUND(ZDURATION/60.0,1) AS min
   FROM ZCLOUDRECORDING ORDER BY ZDATE DESC LIMIT 12;"
# files are in the same Recordings/ dir; ZPATH is the filename.
# NOTE: ZDATE is the recording START; add ZDURATION to get the end time.
```

**Gotcha:** macOS *screen recordings* (`~/Desktop/Screen Recording *.mov`) usually have
**no audio track** — `ffprobe` them first; if video-only, they can't be transcribed.

## 2. Transcribe

```bash
source ~/.venvs/transcribe/bin/activate
python3 ~/.claude/skills/transcribe/transcribe.py "<path>"                  # auto language, model=medium
python3 ~/.claude/skills/transcribe/transcribe.py "<path>" --language en    # force language
python3 ~/.claude/skills/transcribe/transcribe.py "<path>" --model large-v3 # higher accuracy, slower
python3 ~/.claude/skills/transcribe/transcribe.py "<path>" --out-dir ./transcripts
```

- Accepts **any** ffmpeg-decodable input (m4a/mp3/wav/mp4/mov/...); audio is auto-extracted.
- Writes `<name>.txt` (clean, `[MM:SS]` prefixes) and `<name>.srt` (timecodes) next to the
  input, or into `--out-dir`.
- Language **auto-detects** by default; pass `--language` if it guesses wrong.
- **A call in two languages needs `--multilingual`.** Auto-detect picks ONE language from
  the first 30 seconds and applies it to the whole file, so a meeting that opens in
  English and switches to Russian gets the Russian half rendered as English — fluent,
  confident and wrong. `--multilingual` detects per segment (faster-whisper ≥ 1.0).
  Learned 2026-10-09 on a call that was English with George and Russian with Marta.
- **Run long files (10+ min) in the background** (`run_in_background: true`) — a 60-min
  file on `medium` takes a few minutes on CPU. The wrapper prints `✅ done` when finished.

### Speaker labels (optional)

```bash
export HUGGINGFACE_TOKEN=hf_...   # required for diarization
python3 ~/.claude/skills/transcribe/transcribe.py "<path>" --diarize --speakers Alice Bob
```

Needs pyannote + a HF token. Without either, it silently falls back to an unlabelled
transcript (still fully usable).

## 3. Privacy

Fully local. Put transcripts wherever the task belongs.

## Model / accuracy tips

- `medium` (default) — good balance, fast.
- `large-v3` — best accuracy (accents, cross-talk, noisy calls), noticeably slower.
- `small`/`base` — quick rough drafts.
