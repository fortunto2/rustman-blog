---
name: serum-synth
description: Tune Xfer Serum (VSTi: Serum (Xfer Records)) on REAPER tracks via MCP — set oscillator params, envelopes, filter, FX rack; explain what is NOT controllable via VST and needs UI clicks. Use when user wants to design a Serum sound (pad/lead/bass/pluck), adjust filter/envelope, modulate WTPos, or copy a Serum patch between tracks. Do NOT use for non-Serum synths (Massive, Vital, Phase Plant) — their parameter maps differ.
---

# Serum on REAPER via MCP

Tune Xfer Records' Serum (319 VST-parameters exposed) running inside REAPER. Loaded as VST instrument on a track. Requires the `reaper` MCP server connected.

## Parameter map (Serum 1, indices verified empirically)

| # | Name | Notes |
|---|---|---|
| 0 | MasterVol | 0..1 linear |
| 1 | A Vol | 0..1 |
| 2 | A Pan | |
| 3 | A Octave | |
| 4 | A Semi | |
| 5 | A Fine | |
| 6 | A Unison | 0..1 maps to 1..16 voices |
| 7 | A UniDet | detune amount |
| 8 | A UniBlend | |
| 9 | A Warp | warp modulator amount |
| 10 | A CoarsePit | |
| 11 | **A WTPos** | wavetable position, morphs within current wave |
| 12 | A RandPhase | |
| 13 | A Phase | |
| 14-26 | B oscillator | same layout: Vol, Pan, Octave, Semi, Fine, Unison, UniDet, UniBlend, Warp, CoarsePit, **WTPos** (24), RandPhase, Phase |
| 27-32 | Noise | Level, Pitch, Fine, Pan, RandPhase, Phase |
| 33-34 | Sub | Level, Pan |
| 35-39 | **Env1 AHDSR** | Atk, Hld, Dec, Sus, Rel — main amplitude envelope |
| 40 | OscA>Fil | route A through filter (0/1) |
| 45 | **Fil Cutoff** | the big one |
| 48 | Fil Var | |
| 50 | Fil Stereo | |
| 51-55 | Env2 AHDSR | |
| 56-60 | Env3 AHDSR | |
| 63 | LFO3 Rate | |
| 100+ | FX rack | Distortion, Flanger, Phaser, Chorus, Delay, Reverb, EQ, Compressor — explore with `track_fx_get_param_name` |
| 315 | Bypass | entire plugin bypass, not osc B |

VST params are normalized 0.0–1.0. Serum maps them nonlinearly (logarithmic for envelope times, linear for volumes).

## Time/cutoff cheatsheet (empirical, Serum 1)

| Param value | Env Atk/Rel | Filter Cutoff |
|---|---|---|
| 0.1 | ~10ms | ~100Hz |
| 0.3 | ~80ms | ~500Hz |
| 0.5 | ~300ms | ~1kHz |
| 0.6 | ~700ms | ~2kHz |
| 0.7 | ~1.5s | ~4kHz |
| 0.8 | ~3s | ~10kHz |
| 0.9 | ~7s | ~16kHz |

## Hard limits — what VST does NOT expose

Cannot be set via `track_fx_set_param`. Only UI clicks work:

- **Power on/off** for OSC B, Sub, Noise — the lamp icons next to each oscillator. Without power = silent regardless of Vol. **This is the #1 surprise.** Always tell the user to click power on B/Sub/Noise if you're tweaking those.
- **Wavetable file selection** — "Basic Shapes", "Lush Saws", "Analog_BD", "Vintage Strings" etc. are .wav files on disk, not params. UI: click waveform display → READ → pick file.
- **Filter type** (LP12/LP24/HP/BP/Comb/Phaser/Flanger/Reverb-as-filter) — type dropdown is not a clean VST param in Serum 1.
- **Factory/user presets** — `track_fx_set_preset` reports success but Serum stays on Init. Serum has its own preset engine, ignores VST `setProgram`.

When the user wants any of the above, open Serum UI via `track_fx_show(track, fx_index, 3)` (3 = focus) and ask them to click.

## Sound recipes (programmable, work on Init preset)

**Lush ambient pad** (`Pad` track):
```
6=0.6, 7=0.4, 8=0.7        # A Unison 9 voices, detuned, blended
14=0.55, 16=0.4, 19=0.4, 20=0.35  # B Vol+1 oct down, B Unison — REQUIRES B power ON via UI
35=0.78, 38=0.9, 39=0.82   # Env1 Atk ~1.5s, Sus 0.9, Rel ~2s
45=0.6                     # Cutoff mellow
```

**Bright lead** (`Lead`):
```
6=0.3, 7=0.2               # 3 voices, light detune
35=0.4, 38=0.8, 39=0.55    # ~200ms attack, sustain, ~400ms release
45=0.78                    # bright cutoff
```

**Pluck / bell texture** (`Texture`):
```
6=0.2, 7=0.1               # narrow
35=0.05, 37=0.55, 38=0, 39=0.5  # Atk near-zero, Dec 0.55, Sus=0 (key for pluck), Rel 0.5
45=0.88                    # sparkly high cutoff
```

**Sub bass drone** (`Bass`):
```
6=0, 7=0                   # mono
35=0.1, 38=1, 39=0.5       # fast attack, full sustain (drone), short release
45=0.42                    # warm, prevents mud
```

## Hybrid workflow (recommended)

1. `track_fx_add_by_name(track, "Serum")` — adds at end of FX chain
2. Reorder so Serum is FX 0: `track_fx_delete(track, 0)` for any audio FX preceding, then re-add them via `dsl_add_effect` after
3. `track_fx_show(track, 0, 3)` — focus Serum UI
4. **User clicks:** power on OSC B/Sub/Noise (if pad-style), picks wavetable (if not Init's basic saw)
5. **MCP sets:** Unison, envelope, filter, FX rack params per recipe above
6. To clone exact sound to another track: `track_fx_copy_to_track(source_track, fx_index=0, dest_track=X)` — copies all 319 params including UI-set state

## Diagnostics

- `track_fx_get_preset(track, 0)` returns current preset name. If always `" - Init - "` even after `set_preset` — confirmed Serum ignoring VST preset API.
- `track_fx_get_param_count(track, 0)` should return **319** for Serum 1. Serum 2 may differ — re-map if so.
- `track_fx_get_param_name(track, 0, N)` walks parameter labels. Use to locate FX rack params (Dist_*, Cho_*, Verb_*, EQ_*) when needed.

## Related

- For general REAPER MCP operations: `reaper-daw` skill.
- Project-level setup: REAPER project `CLAUDE.md`.
