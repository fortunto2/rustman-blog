---
name: music-reels-cut
description: "Cut a vertical reels/shorts/tiktok music video from a source video file + a new audio track. Real beat detection (no guessed BPM), section-aware effect density (verse=mirror/water 1s, chorus=kaleidoscope/RGB-shift 0.5s, peak=max-chaos 0.25s with FLASH on every downbeat), 14-effect ffmpeg palette. Use when user says 'сделай ролик на трек', 'cut a reel for this song', 'music video from this footage', 'beat-synced clip', 'клип на мою музыку', 'shorts from track', or drops a music file expecting visual output."
metadata:
  version: "1.0.0"
  template: "~/.claude/skills/music-reels-cut/render_template.py"
  reference_render: "~/startups/active/video-generator-agent/out/control_mini/render_v4.py"
  proven_on: "control2.mp3 + burelar-lirika-reels2.mov → control_clip_v4.mp4 (118 cuts, 40s, 76MB)"
---

# music-reels-cut

Beat-synced reels/shorts cut from source footage + new music track. Produces a vertical 1080×1920 mp4 with section-aware visual density driven by **real** beat & section analysis (not guessed BPM).

## When to invoke

User mentions:
- "сделай ролик на трек / клип на мою музыку"
- "make a reel from this song / cut a music video"
- "beat-synced clip from this footage"
- drops an audio file + video file in the same message expecting a montage

## Tools you'll use

1. **`video-generator-agent::beat_dump`** — Rust binary at `~/startups/active/video-generator-agent`. Wraps `video_audio::detect_beats` + `video_audio::analyze_audio`. Outputs JSON with `{bpm, beats[], beat_energies[], downbeats[], sections[]}`. Sections come with `mean_energy` ∈ [0,1] and `label` ∈ {verse, chorus} — use both to drive cut density.
2. **`ffmpeg`** with `-filter_complex_script` (filter chain too long for inline arg)
3. **`uv run --script`** for the Python orchestrator (PEP-723 inline metadata, no venv setup)

## Workflow

### 1. Gather inputs
Ask the user (single combined question):
- **Audio path** (.mp3/.wav/.m4a/.flac)
- **Source video path** (any aspect — will be scaled to 1080×1920)
- **Density preset**: `chill` (1s verse / 0.5s chorus) | `medium` (0.5s verse / 0.25s chorus, default) | `wild` (0.25s verse / 0.125s chorus — near subliminal)
- **Target duration**: defaults to `min(audio_duration, 60)`

### 2. Get beats
```bash
cd ~/startups/active/video-generator-agent
# Build once if missing — produces target/release/beat_dump
test -x target/release/beat_dump || cargo build --release --bin beat_dump
./target/release/beat_dump "<audio-path>" > /tmp/beats_<slug>.json
```
Inspect: `jq '{bpm, n_beats: (.beats|length), sections}' /tmp/beats_<slug>.json`.

If the detected BPM looks halved (e.g. 60 for a clearly faster track), it's likely half-time — treat 0.5s cuts as on-beat, 0.25s as half-beat. Don't fight the detector.

### 3. Probe source video — pick frame pools
```bash
ffprobe -v error -show_entries stream=width,height,duration "<src>"
# Extract ~6 preview frames at evenly spaced timestamps:
for t in 5 20 40 60 80 100; do
  ffmpeg -y -ss $t -i "<src>" -vframes 1 -vf scale=320:-1 /tmp/probe_${t}s.jpg 2>/dev/null
done
```
**Read each frame** (Read tool) and classify by mood:
- `INTIMATE` — close-ups, dark, performance, faces
- `WIDE` — landscape, walking shots, crowds, distance
- `TEXTURE` — sky, water, abstract, B-roll

Build three Python lists of timestamps. **Mix pools in chorus** for tension (don't stay in one pool > 4 cuts).

### 4. Generate render script
Copy `render_template.py` (in this skill dir) to `out/<slug>/render.py`. Edit:
- `SRC_VIDEO`, `SRC_AUDIO`, `OUT` paths
- `BEATS_JSON` path
- Three frame pools (`INTIMATE`, `WIDE`, `TEXTURE`)
- `DENSITY` mapping per section type
- Section list — copy verse/chorus boundaries from `beats.json` `sections`

### 5. Render + verify
```bash
chmod +x out/<slug>/render.py && out/<slug>/render.py
```
Sample ~7 output frames at section boundaries (intro, mid-verse, chorus-1, peak, outro). **Read each** to confirm:
- Aspect ratio not stretched (especially WATER — see lesson #2 below)
- Effect changes visible between adjacent 0.25s cuts
- FLASH_WHITE landed on downbeats (compare to `beats.json::downbeats`)

If a section feels flat, increase density there. If too chaotic, decrease.

## Effect palette (14 effects — port from `render_v4.py`)

| FX | Used in | Description |
|----|---------|-------------|
| INTRO_FADE | intro | Fade-in from black + dark grade |
| OUTRO_FADE | finale | Heavy chromashift + fade to black |
| INTIMATE_DARK | verse | No composite, dark grade (B-) |
| FLASH_WHITE | downbeat snaps | Bright over-exposed beat-flash |
| MIRROR_H | verse | Symmetric horizontal flip (Rorschach) |
| DBL_MIRROR | verse | hflip+vflip overlay @ 48% opacity (ghost) |
| DBL_MIRROR_HUE | verse | DBL_MIRROR + teal hue push (hue=195) |
| WATER | quiet verse | vstack with vflip+blur (reflection) |
| WATER_HUE | quiet verse | WATER + cool blue (hue=210) |
| KALEIDO | chorus | 4-way quadrant kaleidoscope |
| KALEIDO_RGB | chorus/peak | KALEIDO + RGB shift + film noise |
| TILE3X3 | chorus/peak | 9-tile grid |
| CHROMA | transitions | RGB shift only (rh=20,gh=-15,bv=12) |
| INVERT | accents | Color negate |
| PIXEL_CHROMA | builds | Pixelize + tmix frame echo |

Add new effects in `chain(idx, ss, dur, fx)` function — mirror the existing pattern (`trim`, composite, `eq=...`, `setsar=1,format=yuv420p[c{idx}]`).

## Hard-won lessons

1. **Always real beats** — never assume BPM. `beat_dump` takes ~3s, removes all guesswork. Energy values directly drive cut density: chorus E≈1.0 → 0.25s; verse E≈0.4 → 0.5s.

2. **WATER aspect ratio trap**: Source 9:16 + `scale=1080:960` stretches horizontally. Fix: `scale=1080:1920,crop=1080:960:0:480` (preserve aspect, center-crop vertical band). Same applies to any vstack/hstack of two halves where target ratio ≠ source ratio.

3. **`setsar=1`** at end of EVERY filter chain. Composite ops (overlay/hstack/vstack) silently change SAR; concat fails with `Input link parameters do not match`.

4. **`-filter_complex_script` over inline** — past ~60 cuts inline filter args break shell quoting. Always emit to a file.

5. **Downbeat FLASH_WHITE** lets eyes lock onto rhythm even at 0.25s cuts. Without it 8th-note chaos feels arrhythmic. Detect via `near_downbeat(t, eps=0.12)` against `beats.json::downbeats`.

6. **0.25s = visual floor**. Going below (0.125s = 16th) becomes subliminal — viewer reports "felt chaotic" but can't describe any frame. Reserve 0.125s for occasional accent stutters, not sustained sections.

7. **Source variety** — rapid cuts within one mood pool feel monotonous. Mix `INTIMATE + WIDE` in chorus; stay in `INTIMATE` for verse intimacy. Stride-shuffle (`pool[(idx * 7) % len]`) gives non-repeating sequence without RNG seed drift.

8. **CRF 21 + preset medium** = ~75MB for 40s 1080p vertical. For TikTok (<50MB ideal) bump to CRF 24 + preset slow.

9. **Don't trust your section guess** — `video_audio::analyze_audio` finds real verse/chorus boundaries by motif similarity + energy. On `control2.mp3` I guessed "breakdown" at 28-38s; the analyzer correctly labelled it `chorus` at peak energy 1.0. The detector is right; rewrite cuts to match.

10. **Source video aspect mismatch** — if source is landscape (16:9) and target is vertical (9:16), don't `scale=1080:1920` (stretches faces vertically). Use `scale=-1:1920,crop=1080:1920` (zoom-crop, loses sides) OR `scale=1080:-1,pad=1080:1920:0:(1920-ih)/2:black` (letterboxed). Ask the user which.

## Template file
`~/.claude/skills/music-reels-cut/render_template.py` — copy & edit. Comments mark `# EDIT:` spots.

## Reference render
A full proven example with all 14 effects + beat detection + downbeat snaps lives at:
`~/startups/active/video-generator-agent/out/control_mini/render_v4.py`
plus its `beats.json` and the 4 iteration scripts (`render_v1.sh` → `render_v4.py`) showing the evolution from "guessed BPM 90" → "real 60 BPM + section-aware density".
