---
name: click-free-voices
description: >
  How to make polyphonic MIDI synth voice management click-free in the SuperDuper
  DSP plugins (and any AdsrEnvelope-based voice pool). Use when building or
  debugging a synth that clicks/pops on fast playing, repeated notes, or when
  playing over a held drone — i.e. on voice RETRIGGER and voice STEAL. Covers the
  three root causes, the fix pattern, when it does NOT apply, and the click_audit
  test that proves it.
---

# Click-free polyphonic voice management

Symptom the user reports: **faint clicks when playing fast, especially over a
sustained drone** ("еле слышно при быстром нажатии", "под конец 2 раза"). The
audio is otherwise fine. It is almost never the oscillator or filter — it is the
**voice allocator**: what happens when a note lands on a voice that is already
sounding.

There are exactly three note-on situations. Only the first is trivially safe.

| Situation | Path in `allocate_voice` | Safe? |
|---|---|---|
| Fresh note into an **idle** slot | "free voice" | ✅ starts from silence |
| **Retrigger** — same key already held | "retrigger" | ❌ clicks (see #1) |
| **Steal** — all slots busy, replace one | "steal" | ❌ clicks (see #2, #3) |

## Root cause #1 — `gate_on()` zeroes a sounding voice (retrigger click)

`AdsrEnvelope::gate_on()` sets the stage to **PreDelay**, and `process()` in the
PreDelay stage does `self.level = 0.0`. So calling `gate_on()` on a voice that is
currently at, say, sustain 0.8 **drops its level to 0 for a sample, then
re-attacks from 0** — an audible downward step. This is invisible for a fresh
note (already at 0) but a real click when the same key is replayed over a drone.

**Fix:** for a same-key retrigger of a still-sounding voice, use
`AdsrEnvelope::retrigger()` (added for exactly this): it jumps straight to Attack
and **keeps the current level** — a legato re-attack, no drop.

```rust
// WRONG — drops a sounding voice to zero:
if v.key == key && v.note_id == note_id { v.env.gate_on(); /* … */ return; }
// RIGHT:
if v.key == key && v.note_id == note_id { v.env.retrigger(); /* … */ return; }
```

For Kubyz-style voices, ALSO skip `on_note_on()` on retrigger — it rescatters the
oscillator phases and restarts the note-fade, both of which step a sounding voice.
Only call phase-scatter / note-fade for notes that actually start from silence.

**Rule:** `gate_on` = "start from silence". `retrigger` = "re-attack what's
already sounding". Never use `gate_on` on a voice you don't intend to silence.

## Root cause #2 — hard-swapping a stolen voice (steal click)

Stealing by overwriting `key`/pitch in place — even if you preserve oscillator
and filter state — makes the waveform **jump** at full amplitude: the phase
increment changes (new pitch), the anti-alias mip level changes, so `W(phase)`
reads a different value next sample. At 0.8 amplitude that is a clear click.

**Fix: deferred steal.** Don't swap in place. Choke-fade the OLD note to silence
over ~4 ms (it keeps rendering at its old pitch during the fade), and **park** the
new note; the render loop starts the parked note from silence the instant the fade
reaches zero. The join is 0→0 — click-free. Reuses the existing choke machinery.

```rust
// In allocate_voice, steal branch — instead of hard-swapping:
let fade = ((self.sample_rate * 0.004) as u32).max(1);
let v = &mut self.voices[steal_idx];
v.choke_level = v.env.level();     // fade the old note out from its current level
v.choke_total = fade;
v.choke_remaining = fade;
v.pending_key = key;               // park the new note (NOTE_FREE = nothing parked)
v.pending_note_id = note_id;
v.pending_velocity = velocity;
v.age_stamp = stamp;               // stamp as newest so a further steal this block
                                   // picks a different victim, not this parked note

// In the render loop, where the choke completes:
v.choke_remaining -= 1;
if v.choke_remaining == 0 {
    if v.pending_key != NOTE_FREE {
        v.key = v.pending_key; v.note_id = v.pending_note_id; v.velocity = v.pending_velocity;
        v.pending_key = NOTE_FREE;
        v.env = AdsrEnvelope::default(); v.env.gate_on();  // fresh note, from silence
        // (Kubyz: also v.on_note_on(sr) here — this one DOES start from silence)
    } else {
        v.env = AdsrEnvelope::default(); v.key = NOTE_FREE;  // plain choke → free slot
    }
}
```

Add `pending_key: u8` (= `NOTE_FREE` when empty), `pending_note_id: i32`,
`pending_velocity: f32` to the voice struct + its `Default`.

## Root cause #3 — re-choking a voice mid-fade (steal click, subtle)

Once #2 is in, late in a fast run several voices are simultaneously in their 4 ms
deferred fade. A new steal must **not** pick one of them: re-choking resets
`choke_remaining` to full and `choke_level` to the frozen env level, so the output
jumps back up from mid-fade — a click — and clobbers the parked note. A choking
voice's `env.is_releasing()` is still true (env frozen), so it *looks* like a
cheap victim.

**Fix:** skip `choke_remaining > 0` in BOTH victim searches (quietest-releasing and
oldest). Only if every voice is mid-fade (8 steals inside 4 ms — practically never)
fall back to the oldest overall.

## When this does NOT apply — don't "fix" these

- **One-shot synths (Drum, Sampler):** a retrigger is meant to **restart** the hit
  / sample from zero. `gate_on` is correct there — leave it. Their steal can still
  hard-cut, but percussion is transient-masked; only reach for deferred steal if a
  user actually reports it.
- **Ramp-based carriers (Vocoder):** if the voice already glides pitch (portamento)
  and ramps gain with a one-pole (~5 ms) on every note change, steal and retrigger
  are already smooth — no `gate_on`/`retrigger` involved. Don't add an envelope.
- **Ambient / generators:** no MIDI note events, nothing to allocate.

Decision in one line: **legato-continuous voice → `retrigger` + deferred steal;
percussive/one-shot voice → restart-from-zero is the feature, leave it.**

## Verify it — the `click_audit` test

Copy `effects/superduper-wave/tests/click_audit.rs` (or pad/kubyz). Key points that
make it actually catch the bug:

1. **Sequence = drone + overlapping stabs.** Hold an 8-note cluster (fills the
   pool) then rain fast stabs on top, and make **some stab keys equal drone keys**
   (60, 64) so the same-key retrigger path fires, plus enough stabs to force steals.
2. **Anomaly metric, not raw jump.** An 8-voice sum legitimately has steep slopes.
   Score each sample by `|Δ[i]| / median(|Δ|)` over a ~10 ms window; a click is
   ~15–30×, a clean zero-crossing is ~6×. Assert worst < ~12×.
3. **The seam gotcha (this cost the most time):** REAPER renders **per event-batch**
   — a note-on at sample offset 192 splits the block into `render_subblock([0..192])`
   and `render_subblock([192..256])`. The click lands at that **sub-block seam**. A
   per-sample detector inside `render_subblock` resets its "previous sample" each
   call and misses it. To debug, compare `out[start]` vs `out[start-1]` right AFTER
   each `render_subblock` call, and dump every voice's `key/level/choke/pending`.
4. **Only analyse rendered samples.** `n_blocks = total/BLOCK` truncates the last
   partial block to zeros; a long release still sounding there reads as a giant fake
   click. Slice to `(len/BLOCK)*BLOCK`.
5. **Ship the WAV.** Write `/tmp/<plugin>_click_audit.wav` and `afplay` it — the ear
   is the final judge ("послушай, тех 2 щелчков больше нет").

Measured on Wave with the drone+stab sequence: worst anomaly **29.6× → 6.6×**, max
single-sample jump **0.162 → 0.031**; Kubyz and Pad land at **0.0×** (the built-in
note-fade / smooth sine partials mop up the rest).

## Where this lives in the codebase

- `synth_core::dsp_blocks::AdsrEnvelope::retrigger()` — the shared legato re-attack.
- Wave: `effects/superduper-wave/src/lib.rs` `allocate_voice` + the choke-complete
  block in `render_subblock`; pending fields in `synth_core::wave_osc::WaveVoice`.
- Kubyz: same shape, pending fields in `synth_core::kubyz::voice::KubyzVoice`.
- Pad: same shape, pending fields on the local `Voice` in `superduper-pad`.
- Regression tests: `tests/click_audit.rs` in wave / kubyz / pad.

Relates to project `CLAUDE.md` lesson 17 (voice steal — preserve oscillator/filter
state): that lesson stops the *filter-integrator-zeroing* click; this skill stops
the *envelope-drop* and *pitch-hard-swap* clicks, which lesson 17 alone misses.
