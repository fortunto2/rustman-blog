---
name: iphone-daw-bridge
description: Bridge iPhone audio and MIDI into a Mac DAW (REAPER, Logic, Ableton). Covers IDAM (Inter-Device Audio Mode over USB Lightning/USB-C — lossless ~5 ms latency), AirPlay+BlackHole fallback for non-IDAM cases, building Aggregate Devices via CoreAudio HAL with Swift (not the Audio MIDI Setup GUI), the IDAM 44100 Hz sample-rate trap, drift compensation, and MIDI Clock master/slave with REAPER. Use when the user asks about recording iPhone or iOS-app output into a Mac DAW, "iPhone in REAPER/Logic", IDAM, AirPlay recording, sample-rate crackles with iOS USB audio, MIDI Clock sync iPhone↔Mac, BlackHole or Sonobus on Mac, or building aggregate audio devices from the command line.
---

# iPhone ↔ Mac DAW bridge

How to actually get an iPhone (or any iOS device) recording and
syncing into a Mac DAW. Order matters — pick the highest-quality path
the iOS app supports.

## Decision tree

| What does the iOS app expose?              | Use this                       |
| ------------------------------------------ | ------------------------------ |
| It is an AUv3 instrument (`aumu`/`aurg`)   | **AUv3** inside an iOS host (AUM/Cubasis) — record from there. On Mac AUv3 is not directly usable, so stream via IDAM. |
| Standalone app, plays into iOS system out  | **IDAM** over USB cable (lossless, 44.1 kHz, ~5 ms) |
| Standalone, no USB-Audio Class on iOS side | **AirPlay Receiver on Mac + BlackHole** virtual driver |
| Only the iPhone built-in microphone        | **Continuity Microphone** (no setup, but it captures mic, not app audio) |
| iPad with Camera Connection Kit & class-compliant | as USB audio interface (rare) |

The most common mistake: trying to use Sonobus or AudioBus to capture
a standalone iOS app — those only see AUv3/AudioBus-aware sources,
not standalone-app audio.

## IDAM — Inter-Device Audio and MIDI

Apple's built-in USB Audio Class + MIDI bridge. Audio and MIDI travel
over the same Lightning/USB-C cable.

### Enable
1. Connect iPhone to Mac via cable.
2. Open `Audio MIDI Setup.app` → MIDI Studio → find the iPhone tile
   → click **Enable** under "Inter-device Audio and MIDI Mode".
3. iPhone screen will show "Connected to Mac" and route system audio
   over USB. iPhone speakers go silent — this is normal.

### What it gives
- New audio input device named `iPhone` (2 ins / 0 outs, USB transport).
- New CoreMIDI source + destination both named `iPhone`.
- iOS reports it as `'usb '` transport, 44100 Hz nominal rate
  **hardcoded** — apps that internally run at 48 kHz are resampled
  inside iOS before the USB stream leaves.

### Sample-rate trap
**Always set the DAW project AND every aggregate-device sub-member to
44100 Hz when recording through IDAM.** A mismatch (e.g. headphones at
48 kHz + iPhone at 44.1) produces clicks/crackles because the
aggregate has to resample on the fly. Even if drift compensation is
on, asynchronous resampling at runtime is what most "trying to record
iPhone but it crackles" reports are about.

Force-set rates from CLI:
```swift
// kAudioDevicePropertyNominalSampleRate on each subdevice
var rate: Double = 44100
AudioObjectSetPropertyData(deviceID, &addr, 0, nil,
    UInt32(MemoryLayout<Double>.size), &rate)
```

### Build aggregate device for DAW (programmatic, not Audio MIDI Setup GUI)
DAW wants **one** audio interface. To let REAPER record from iPhone
input while playing back to local headphones, create an aggregate
that bundles both. Use `AudioHardwareCreateAggregateDevice` — it
persists in CoreAudio prefs across reboots, and is faster/repeatable
than clicking through Audio MIDI Setup.

```swift
import CoreAudio
let dict: [String: Any] = [
    kAudioAggregateDeviceNameKey as String: "REAPER + iPhone",
    kAudioAggregateDeviceUIDKey  as String: "co.you.reaper-iphone",
    kAudioAggregateDeviceMainSubDeviceKey as String: headphonesUID, // clock source
    kAudioAggregateDeviceIsPrivateKey as String: 0,
    kAudioAggregateDeviceIsStackedKey as String: 0,  // 1 = Multi-Output (stacked)
    kAudioAggregateDeviceSubDeviceListKey as String: [
        ["UID": headphonesUID],   // first = clock master
        ["UID": iphoneUID],
    ],
]
var newID: AudioObjectID = 0
AudioHardwareCreateAggregateDevice(dict as CFDictionary, &newID)
```

The `main` sub-device is the clock master. The non-main sub-device
needs drift compensation:

```swift
// kAudioSubDevicePropertyDriftCompensation on the non-main subdevice
var v: UInt32 = 1
AudioObjectSetPropertyData(subdeviceID, &addr, 0, nil,
    UInt32(MemoryLayout<UInt32>.size), &v)
```

Without drift compensation, the two clocks (iPhone USB / headphones
DAC) drift apart and you hear clicks every ~30 seconds.

### Get UID from a device name
```swift
// kAudioDevicePropertyDeviceUID returns a CFString
// kAudioObjectPropertyName  returns the human-readable name
```
For iPhone IDAM the UID looks like
`AppleUSBAudioEngine:Apple Inc.:iPhone:000081200011754C…:3` — the long
hex section is the device serial, so it stays stable across reconnects.

### REAPER project settings
- Preferences → Audio → Device → pick the aggregate you just made.
- Sample rate: **44100**.
- Buffer size 256–512 to start; 128 only after everything works clean.
- Track input: usually the iPhone subdevice sits on channels **3/4**
  (1/2 are headphones output of the aggregate). Channel numbering
  follows the order of the sub-device list.

## AirPlay Receiver + BlackHole (fallback)

Use when IDAM is not available (older iOS, or you need wireless).

### Setup once
1. Mac: System Settings → General → AirDrop & Handoff → **AirPlay
   Receiver: On**. Allow for "Anyone on the same network".
2. `brew install --cask blackhole-2ch` — needs sudo (it's an HAL
   plug-in, installs into `/Library/Audio/Plug-Ins/HAL/`). Reboot is
   **not** required, just `sudo killall coreaudiod` and the new
   plug-in loads on respawn.
3. Verify: `system_profiler SPAudioDataType | grep BlackHole`.

### Routing
Switch Mac default output to `BlackHole 2ch` (or to a Multi-Output
that duplicates to BlackHole + headphones, so you can monitor while
recording). iPhone → Control Center → AirPlay → pick the Mac.

AirPlay 2 latency: 100–200 ms. Fine for offline recording, painful
for playing along.

## Switching default audio output from the command line

Compile this tiny helper once, keep it in `~/bin/audio-route`:

```swift
// see also: kAudioHardwarePropertyDefaultOutputDevice / DefaultInputDevice
var addr = AudioObjectPropertyAddress(
    mSelector: kAudioHardwarePropertyDefaultOutputDevice,
    mScope: kAudioObjectPropertyScopeGlobal,
    mElement: kAudioObjectPropertyElementMain)
var id = targetDeviceID
AudioObjectSetPropertyData(AudioObjectID(kAudioObjectSystemObject),
    &addr, 0, nil, UInt32(MemoryLayout<AudioObjectID>.size), &id)
```

A full implementation with `list / get / set / set-input` subcommands
sits in this repo at `audio_route.swift`. Build with
`swiftc -O -o ~/bin/audio-route audio_route.swift`. Use to switch
output without opening System Settings.

## MIDI Clock sync (REAPER ↔ iOS app)

IDAM also exposes MIDI in both directions over the same cable, so no
extra setup beyond the audio bridge above.

### REAPER as master (most common)
- Preferences → MIDI Outputs → right-click `Apple Inc. - iPhone`
  → **Enable output** → right-click again → **Send clock to output**
  (column "Clock" gets a dot).
- Tempo in REAPER controls the iOS app's transport.

### iOS app side
- The app must subscribe to incoming MIDI (CoreMIDI input port
  connected to source endpoints) and handle `0xF8` (24 PPQN clock),
  `0xFA` start, `0xFB` continue, `0xFC` stop.
- Tempo derivation: count 24 ticks, measure elapsed time, BPM = 60 /
  elapsed. Use a running average of 4–8 samples for stability.

### Common bug: doubled BPM
If the app reports 2× the actual tempo, it is almost always
**multiple subscription paths to the same clock stream**. Causes:

1. The app subscribes to **every** CoreMIDI source via
   `MIDIGetSource(i)` loop — and `MIDIGetSource` includes the app's
   *own* virtual source created by `MIDISourceCreateWithProtocol`.
   When the sequencer sends `0xF8` out, the app hears it again on
   input → every tick counted twice.
2. IDAM is active AND Network MIDI is enabled. The Mac DAW sends
   clock only to the USB endpoint, but iOS may bridge MIDI between
   transports — or the app subscribes to both `_apple-midi._udp`
   session source AND IDAM source. Same packets, two paths.
3. Bluetooth MIDI Central paired in addition.

Fixes:
- Skip own virtual source: when iterating `MIDIGetSource()`, compare
  the endpoint's `kMIDIPropertyDriverOwner` or store the
  `MIDIEndpointRef` returned by your own `MIDISourceCreate…` and
  filter it out.
- Make transports mutually exclusive in app settings — one of
  IDAM / Network MIDI / Bluetooth MIDI active at a time, not all three.
- De-duplicate at the handler: ignore a `0xF8` arriving within
  `previousTickInterval / 2` of the last one.

### iOS app as master, REAPER slave (rarer)
- iOS app: emit `0xF8` 24 times per quarter via its virtual source.
- REAPER: Preferences → Audio → Sync → External Timecode Sync →
  source `iPhone`, type **MIDI Clock**.

## Bonjour / discovery debugging

When iPhone is in IDAM mode it stops advertising for Network MIDI, so
seeing nothing under Network in Audio MIDI Setup is correct. If you
*do* see `_apple-midi._udp` advertisements for the iPhone while IDAM
is active, the iOS app still has Network MIDI on and you are about to
hit the doubled-clock bug above.

Check from the Mac:
```bash
dns-sd -B _apple-midi._udp local.   # iPhone MIDI session advertisements
dns-sd -B _airplay._tcp   local.    # AirPlay receivers (Mac itself shows up by name)
```

## Persistence

What survives reboot without re-doing it:
- Aggregate / Multi-Output devices created via `AudioHardwareCreateAggregateDevice`
  with `kAudioAggregateDeviceIsPrivateKey = 0` — stored in CoreAudio prefs.
- BlackHole driver — in `/Library/Audio/Plug-Ins/HAL/`.
- AirPlay Receiver On/Off — in system Sharing prefs.
- REAPER `reaper.ini` remembers the picked audio device by name.
- IDAM "Enabled" per iPhone-Mac pair, remembered by Apple keyring.

What does **not** persist:
- macOS default output device when a new audio interface plugs in.
  Use `audio-route set "REAPER + iPhone"` from a script / Raycast.

## Useful paths

| Where | What lives there |
|-------|------------------|
| `~/Library/Preferences/com.apple.MIDIServer.plist` | Network MIDI sessions, if you ever create them by code |
| `/Library/Audio/Plug-Ins/HAL/` | BlackHole, ZoomAudio, other HAL drivers |
| `~/Library/Application Support/REAPER/reaper.ini` | REAPER MIDI input/output enable flags, current audio device |
| `~/bin/audio-route` | The CLI helper to switch default output |
