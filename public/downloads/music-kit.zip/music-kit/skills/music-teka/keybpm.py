import subprocess, sys
import numpy as np
SR=22050
def pcm(path,start=60,dur=60):
    raw=subprocess.run(["ffmpeg","-nostdin","-v","error","-ss",str(start),"-i",path,"-t",str(dur),"-ac","1","-ar",str(SR),"-f","f32le","-"],capture_output=True).stdout
    return np.frombuffer(raw,dtype=np.float32)
def bpm_of(seg,lo=70,hi=180):
    sr2=11025; seg=seg[::2]
    hop=sr2//50; n=len(seg)//hop
    rms=np.sqrt(np.mean(seg[:n*hop].reshape(n,hop)**2,axis=1))
    env=np.maximum(np.diff(rms),0); env-=env.mean()
    ac=np.correlate(env,env,"full")[len(env)-1:]
    best=(0,-1)
    for bpm in np.arange(lo,hi,0.25):
        lag=int(round(50*60/bpm))
        v=ac[lag]+0.5*ac[min(2*lag,len(ac)-1)]
        if v>best[1]: best=(bpm,v)
    return best[0]
MAJ=np.array([6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88])
MIN=np.array([6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17])
NOTES=["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
CAMELOT={("A","min"):"8A"}  # built below properly
def key_of(seg):
    n=4096; chroma=np.zeros(12)
    w=np.hanning(n)
    for i in range(0,len(seg)-n,n//2):
        sp=np.abs(np.fft.rfft(seg[i:i+n]*w))
        freqs=np.fft.rfftfreq(n,1/SR)
        for j in range(1,len(freqs)):
            f=freqs[j]
            if 55<=f<=2000:
                pc=int(round(12*np.log2(f/440)))%12
                chroma[(pc+9)%12]+=sp[j]
    best=(None,-2)
    for i in range(12):
        c=np.roll(chroma,-i)
        for prof,mode in ((MAJ,"maj"),(MIN,"min")):
            r=np.corrcoef(c,prof)[0,1]
            if r>best[1]: best=((NOTES[i],mode),r)
    return best[0]
# camelot map
CAM={}
circle_min=["A","E","B","F#","C#","G#","D#","A#","F","C","G","D"]
for idx,note in enumerate(circle_min): CAM[(note,"min")]=f"{idx+1}A"
circle_maj=["C","G","D","A","E","B","F#","C#","G#","D#","A#","F"]
for idx,note in enumerate(circle_maj): CAM[(note,"maj")]=f"{idx+1}B"
for p in sys.argv[1:]:
    seg=pcm(p)
    k=key_of(seg); b=bpm_of(seg)
    print(f"{p.split('/')[-1]}: BPM~{b:.1f}, key {k[0]}{'m' if k[1]=='min' else ''} ({CAM.get(k,'?')})")
