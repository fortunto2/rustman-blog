#!/usr/bin/env python3
"""Retag DJ library files for djay Pro.

My YouTube downloads (detected by embedded youtube URL) get artist/title
rewritten from the "Artist - Title" filename (their embedded tags are
uploader junk); other files (torrent rips) only get missing fields filled.
Genre = folder label so djay can filter by it. Never writes BPM.

Usage:
    retag.py                    # full library sweep
    retag.py FILE [FILE...]     # tag specific new downloads
    retag.py FOLDER             # tag one folder recursively
Run with: uv run --with mutagen python retag.py
"""
import re
import sys
from pathlib import Path

import mutagen
from mutagen.id3 import ID3, ID3NoHeaderError
from mutagen.easyid3 import EasyID3

MUSIC = Path("~/Music").expanduser()
FOLDERS = {  # path -> (genre, recursive)
    MUSIC / "DJ/Hits": ("Hits", False),
    MUSIC / "DJ/Techno": ("Techno", False),
    MUSIC / "DJ/Русское": ("Русское", False),
    MUSIC / "DJ/Татар-Башкорт": ("Tatar-Bashkir", True),
    MUSIC / "DJ/Türkçe": ("Türkçe", False),
    MUSIC / "DJ/Cinematic": ("Soundtrack", True),
    MUSIC / "DJ/Sets": ("DJ Set", False),
    MUSIC / "DJ/Beats": ("Beats", False),
    MUSIC / "DJ/Misc": (None, False),
    MUSIC / "Karaoke/Татар-Башкорт/audio": ("Karaoke", False),
    MUSIC / "Karaoke/Русские/audio": ("Karaoke", False),
    MUSIC / "Karaoke/English/audio": ("Karaoke", False),
    MUSIC / "Karaoke/Türkçe/audio": ("Karaoke", False),
}
EXTS = {".mp3", ".flac", ".m4a"}
NUM_RE = re.compile(r"^\d{1,3}[\s._-]+")


def parse_name(stem: str):
    stem = NUM_RE.sub("", stem).strip()
    if " - " in stem:
        artist, title = stem.split(" - ", 1)
        return artist.strip(), title.strip()
    return None, stem


def is_my_youtube_mp3(path: Path) -> bool:
    if path.suffix.lower() != ".mp3":
        return False
    try:
        id3 = ID3(path)
    except ID3NoHeaderError:
        return False
    for key, frame in id3.items():
        if key.startswith("TXXX:purl") or key.startswith("WOAF"):
            return True
        try:
            if "youtube.com" in str(frame) or "youtu.be" in str(frame):
                return True
        except Exception:
            pass
    return False


def get_easy(path: Path):
    if path.suffix.lower() == ".mp3":
        try:
            return EasyID3(path)
        except ID3NoHeaderError:
            e = EasyID3()
            e.save(path)
            return EasyID3(path)
    return mutagen.File(path, easy=True)


def genre_for(path: Path):
    for folder, (genre, _) in FOLDERS.items():
        if path.is_relative_to(folder):
            return genre
    if "Karaoke" in path.parts:
        return "Karaoke"
    dj = MUSIC / "DJ"
    if path.is_relative_to(dj):
        return path.relative_to(dj).parts[0]  # new user-created DJ subfolder
    return None


def collect_targets():
    """(file, genre) pairs: explicit args, else full library sweep."""
    args = [Path(a).expanduser().resolve() for a in sys.argv[1:]]
    if args:
        for a in args:
            if a.is_dir():
                yield from ((f, genre_for(f)) for f in sorted(a.rglob("*")))
            else:
                yield a, genre_for(a)
        return
    for folder, (genre, recursive) in FOLDERS.items():
        if not folder.exists():
            continue
        files = folder.rglob("*") if recursive else folder.glob("*")
        yield from ((f, genre) for f in sorted(files))


changed = skipped = errors = 0
log = []
for f, genre in collect_targets():
    if not f.is_file() or f.suffix.lower() not in EXTS:
        continue
    if "_pretrim" in f.parts or "_originals" in f.parts:
        continue
    try:
        tags = get_easy(f)
        if tags is None:
            errors += 1
            continue
        fn_artist, fn_title = parse_name(f.stem)
        mine = is_my_youtube_mp3(f)
        delta = []
        cur_artist = (tags.get("artist") or [""])[0].strip()
        cur_title = (tags.get("title") or [""])[0].strip()
        cur_genre = (tags.get("genre") or [""])[0].strip()
        if mine:
            if fn_artist and cur_artist != fn_artist:
                tags["artist"] = fn_artist
                delta.append(f"artist:'{cur_artist}'→'{fn_artist}'")
            if fn_title and cur_title != fn_title:
                tags["title"] = fn_title
                delta.append(f"title:'{cur_title[:40]}'→'{fn_title}'")
            if genre and cur_genre != genre:
                tags["genre"] = genre
                delta.append(f"genre→{genre}")
        else:
            if not cur_artist and fn_artist:
                tags["artist"] = fn_artist
                delta.append(f"artist→'{fn_artist}'")
            if not cur_title:
                tags["title"] = fn_title
                delta.append(f"title→'{fn_title}'")
            if not cur_genre and genre:
                tags["genre"] = genre
                delta.append(f"genre→{genre}")
        if delta:
            tags.save()
            changed += 1
            log.append(f"{f} :: {'; '.join(delta)}")
        else:
            skipped += 1
    except Exception as exc:  # noqa: BLE001
        errors += 1
        log.append(f"ERROR {f.name}: {exc}")

print(f"changed={changed} unchanged={skipped} errors={errors}")
for line in log:
    print(line)
