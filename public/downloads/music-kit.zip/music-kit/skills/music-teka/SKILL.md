---
name: music-teka
description: Add music/karaoke to Rustam's DJ library (~/Music/DJ, ~/Music/Karaoke) with correct quality, naming, tags, and dedup. Use when user sends YouTube links or song names to download ("скачай в хиты/техно/караоке/синематик", "качай", "в песни", "пополни фонотеку"), asks to find a track, or wants library maintenance (retag, dedup, trim karaoke intros).
---

# Music Teka — library replenishment

User DJs with **djay Pro** (Algoriddim, macOS). Principle: **disk folders = genre/language (stable), djay playlists = event (changeable)**. BPM is computed by djay — never write BPM tags.

## Library map (genre tag = folder label)

| Folder | Content | Genre tag |
|---|---|---|
| `~/Music/DJ/Hits/` | recognizable party hits, 90s/00s, millennial, movie songs | Hits |
| `~/Music/DJ/Techno/` | lesser-known ready-to-mix techno/bass | Techno |
| `~/Music/DJ/Русское/` | Russian-language pop/rock | Русское |
| `~/Music/DJ/Татар-Башкорт/` | Tatar & Bashkir (subfolders: bashkir, ирина, сабантуй) | Tatar-Bashkir |
| `~/Music/DJ/Türkçe/` | Turkish party | Türkçe |
| `~/Music/DJ/Cinematic/` | film scores & movie themes | Soundtrack |
| `~/Music/DJ/Sets/` | long DJ sets/lives | DJ Set |
| `~/Music/DJ/Beats/` | rap/trap beats | Beats |
| `~/Music/Karaoke/{Татар-Башкорт,Русские,English,Türkçe}/` | karaoke mp4 + `audio/` mp3 | Karaoke |
| `~/Music/Albums/` | FLAC albums from torrents — never auto-write here | — |

If user names a folder that doesn't exist yet ("создай папку X"), create it under `~/Music/DJ/` and add it to this table + memory.

## Adding a song (link or name)

1. **Probe first**: `yt-dlp --print "%(artist)s|%(title)s|%(channel)s|%(duration)s" URL` — know what it is before downloading.
2. **Dedup**: check target folder (`ls | grep -i <keyword>`); user re-sends duplicates often. If already present — say so, don't redownload. Compare durations if unsure.
3. **No link? Search**: `yt-dlp --flat-playlist --print "%(id)s|%(duration)s|%(title).80s|%(channel)s" "ytsearch6:<query>"`. Prefer official artist channels / `- Topic` channels. For DJ use prefer full/extended versions over radio edits — mention the choice. Filter out concerts/shorts by duration.
4. **Download mp3** into the right folder, filename **`Artist - Title.mp3`** (clean, no video-title junk):
   ```
   yt-dlp URL -x --audio-format mp3 --audio-quality 0 --embed-metadata --embed-thumbnail --no-progress -o "Artist - Title.%(ext)s"
   ```
5. **Retag** (YouTube embeds uploader junk as artist): run `uv run --with mutagen python ~/.claude/skills/music-teka/retag.py "<file>"` — sets artist/title from filename, genre from folder. Batch mode: pass a folder.
6. Report: what, duration, where, running folder count.

## Adding karaoke

- Folder by language: `~/Music/Karaoke/<lang>/`. **MUST be H.264+AAC** — djay Pro/AVFoundation fails on VP9/AV1/Opus-in-mp4 with `OSStatus 1885563711`:
  ```
  yt-dlp URL -f "bv*[vcodec^=avc1][height<=720]+ba[acodec^=mp4a]/bv*[vcodec^=avc1][height<=720]+ba/b[ext=mp4][height<=720]/b" --merge-output-format mp4 --no-progress -o "Artist - Title (караоке).%(ext)s"
  ```
- Always extract mp3 alongside: `ffmpeg -nostdin -y -v error -i file.mp4 -vn -c:a libmp3lame -q:a 0 "audio/<same name>.mp3"`.
- If wrong codec slipped in: audio-only fix `-c:v copy -c:a aac`; AV1 video → re-encode `-c:v h264_videotoolbox -b:v 2500k`.
- **Intro jingles**: detect with `silencedetect=noise=-35dB:d=0.4` in first 12s; cut at silence_end if silence starts ≤4.5s. Prefer keyframe-aligned stream copy (probe keyframes with `ffprobe -skip_frame nokey`), fall back to videotoolbox re-encode. Keep original in `_pretrim/`. CAUTION: «Калинка Караоке» title cards play OVER the song intro — do not cut those; verify with a frame extract + loudness profile, not silence alone.

## Errors & gotchas

- `HTTP 403` → retry with `--extractor-args "youtube:player_client=android,web"`.
- Empty ytsearch → retry with transliteration/spelling variants (Tatar/Bashkir names especially: ә/э, ү/у, ҡ/к).
- `ffmpeg` inside shell `while read` loops: always `-nostdin` (it eats the loop's stdin).
- Playlist URLs (`&list=`): download only the single video unless user asks for the playlist; offer the batch.
- Multiple links arrive mid-work: queue them, batch metadata probes in one call.
- Big batches (>5): run in background script with OK/FAIL log per item; verify file existence, not exit code (`--max-downloads 1` exits 101).
- Deletions/overwrites: always ask first (user rule). Moves within library are fine when user asked for reorganization.

## After changes

Remind: djay caches tags/paths — «Reload Tags» or re-add folder if names look stale. Update the memory file `project_music_folders_dj.md` when structure changes.
