---
name: conjuredsp
description: Write and modify real-time DSP scripts for ConjureDSP — an AUv3 plugin on macOS that lets users build audio effects in Rust (compiles to WASM) or Python (instant). Use when user asks to create/edit a DSP effect (compressor, EQ, delay, reverb, chorus, distortion, filter, modulation, NAM amp sim), tweak parameters of a ConjureDSP preset, write a process.rs / process.py, design a custom HTML/JS plugin UI with cdp-* components, or work with a .cdp bundle. Do NOT use for non-ConjureDSP synths (Serum → use serum-synth skill) or general REAPER track control (→ reaper-daw skill).
---

# ConjureDSP — Rust/Python DSP in REAPER

ConjureDSP is an AUv3 audio plugin (Michael Jancsy, macOS Sequoia+, Apple Silicon). It hosts user-written DSP scripts in Python or Rust with hot reload. Each preset is a `.cdp` bundle (directory with `manifest.json` + `process.{rs,py}` + optional `ui/`). Default site: https://www.conjuredsp.com/docs/

## Preflight — is the plugin running?

ConjureDSP exposes an MCP server on **`http://localhost:61933/mcp`** but **only while the plugin is loaded and active in a DAW track**. If `claude mcp list` shows `conjuredsp: ✗ Failed to connect`:

1. Open REAPER (or another AUv3 host).
2. Insert `AU: ConjureDSP` on any track and open its UI.
3. The MCP server starts automatically when the plugin window initializes.
4. Re-check with `claude mcp list` or `curl -m2 http://localhost:61933/mcp`.

The current MCP endpoint URL is also written to `~/Library/Application Support/ConjureDSP/mcp-url.txt`. The port may change between plugin restarts — re-read this file if connection fails.

## File layout on disk

| Path | Purpose |
|---|---|
| `~/Library/Group Containers/group.com.MichaelJancsy.ConjureDSP/Presets/*.cdp/` | User preset bundles (git-tracked: there's a `.git` inside Presets/) |
| `~/Library/Application Support/ConjureDSP/agent-workspace/CLAUDE.md` | Authoritative agent instructions (read first; sometimes more current than this skill) |
| `~/Library/Application Support/ConjureDSP/mcp-url.txt` | Current MCP endpoint URL |
| `~/Library/Group Containers/.../rustc-dist/lib/libconjuredsp.rlib` | Compiled Rust library (the `conjuredsp::*` types are NOT open-source; use `get_docs` for the API surface) |

Each `*.cdp` bundle contains at minimum `manifest.json` (params schema, language, optional `ui` block) and an entry script. Read existing bundles to learn patterns — `DnB Bass.cdp` is a good Rust reference (Biquad lowshelf + lowpass + LFO-modulated DelayLine).

## MCP tools (`conjuredsp__*` namespace)

| Tool | When |
|---|---|
| `conjuredsp__get_script` | **ALWAYS call first** before modifying — user may have hand-edited |
| `conjuredsp__get_docs(topic)` | Topics: `params`, `filters`, `delays`, `oscillators`, `utilities`, `accel`, `nam`, `ui`. Python and Rust syntax differ — check before writing |
| `conjuredsp__compile_and_run(code, language)` | Iterate on existing bundle (hot reload) |
| `conjuredsp__save_preset(name, source, scaffold_ui=...)` | Atomic: writes bundle + switches plugin + loads kernel. Use for new presets |
| `conjuredsp__get_error` | Compile/runtime errors |
| `conjuredsp__get_parameters` / `set_parameter(name, value)` | Inspect/adjust live param values |
| `conjuredsp__get_audio_state` | peak/RMS/DC/latency |
| `conjuredsp__list_presets` / `duplicate_bundle(src, dst)` / `list_packages` / `list_tones` | Discovery |
| `conjuredsp__read_bundle_file` / `write_bundle_file(path, content)` | Custom UI authoring (`ui/index.html`, `ui/assets/*`, `manifest.json`) |
| `conjuredsp__validate_bundle` | Static lint of UI bundle |
| `conjuredsp__smoke_test_ui` | Headless WKWebView runtime check — required before claiming UI done |

## Real-time rules (HARD)

The `process()` function runs on the audio thread. Violating any of these will glitch or crash:

- No allocation (`np.zeros`, `Vec::new`, `Box::new` inside `process`)
- No file I/O, no network, no syscalls
- No Python prints, no `println!` in Rust
- No lock acquisition
- Up to **16 parameters** per script
- Persistent state via module globals (Python) or `static mut` / `persist!` / `persist_mut!` (Rust)

## Quick reference — Rust template

```rust
use conjuredsp::*;
setup!();  // declares buffers, WASM exports, ctx() helper

params! {
    CUTOFF = freq().min(100.0).max(20000.0).default(1000.0),
    DRIVE  = pct().default(50.0),
    MIX    = mix().default(1.0),
}

static mut FILTERS: [Biquad; 2] = [Biquad::new(); 2];

#[no_mangle]
pub extern "C" fn process(
    input: *const f32, output: *mut f32,
    channel_count: i32, frame_count: i32, sample_rate: f32,
) {
    let ctx = ctx(input, output, channel_count, frame_count, sample_rate);
    let cutoff = ctx.param(CUTOFF) as f64;
    let drive  = ctx.param(DRIVE) / 100.0;
    let mix_val = ctx.param(MIX);
    let coeffs = BiquadCoeffs::lowpass(cutoff, 0.707, ctx.sample_rate() as f64);

    unsafe {
        for c in 0..ctx.channels() {
            FILTERS[c].set_coeffs(coeffs);
            for i in 0..ctx.frames() {
                let x = ctx.input(c, i);
                let driven = (x * (1.0 + drive * 5.0)).tanh();
                let y = FILTERS[c].process_sample(driven as f64) as f32;
                ctx.set_output(c, i, x * (1.0 - mix_val) + y * mix_val);
            }
        }
    }
}
```

## Quick reference — Python template

```python
from conjuredsp import freq, pct, mix
from conjuredsp.filters import Biquad, BiquadCoeffs

PARAMS = {
    "cutoff": freq(min=100, max=20000, default=1000),
    "drive":  pct(default=50),
    "mix":    mix(default=1.0),
}

_filters = None  # lazy per-channel state

def process(inputs, outputs, frame_count, sample_rate, params, _transport, _telemetry):
    global _filters
    n_ch = len(inputs)
    if _filters is None or len(_filters) != n_ch:
        _filters = [Biquad() for _ in range(n_ch)]
    coeffs = BiquadCoeffs.lowpass(params["cutoff"], 0.707, sample_rate)
    drive = params["drive"] / 100.0
    mix_v = params["mix"]
    for c in range(n_ch):
        _filters[c].set_coeffs(coeffs)
        for i in range(frame_count):
            x = inputs[c][i]
            driven = np.tanh(x * (1 + drive * 5))
            y = _filters[c].process_sample(driven)
            outputs[c][i] = x * (1 - mix_v) + y * mix_v
```

## Parameter builders (cheatsheet)

| Builder | Range | Unit | Curve | Default |
|---|---|---|---|---|
| `freq()` | 20–20000 | Hz | log | 1000 |
| `db()` | −60..+12 | dB | linear | 0 |
| `time_ms()` | 0.1–1000 | ms | log | 100 |
| `pct()` | 0–100 | % | linear | 50 |
| `mix()` | 0.0–1.0 | — | linear | 0.5 |
| `toggle()` | 0/1 | — | — | 0 |
| `ratio()` | 1–20 | :1 | linear | 4 |
| `param(min, max)` | custom | custom | custom | mid |
| `choice("A","B","C")` | Python only | — | — | first |

Chain: `.min(x)`, `.max(x)`, `.default(x)`, `.unit("Hz")`, `.curve("log")`.

## DSP building blocks

- **`Biquad` / `BiquadCoeffs`** — 8 filter types: `lowpass, highpass, bandpass, notch, peak, lowshelf, highshelf, allpass, identity`. Stateful per-channel (`Biquad::new()`, `set_coeffs`, `process_sample(f64)`).
- **`DelayLine<N>`** — circular buffer, `write(x)` + `read(samples)` (linear) or `read_cubic(samples)` (Hermite).
- **`Lfo`** / **`LFO`** — `init(sr, freq)`, `set_waveform(Waveform::{Sine,Triangle,Saw,Square})`, `tick() → [-1, 1]`.
- **`accel::*`** — Apple Accelerate vDSP wrappers: `matmul`, `vec_add`, `vec_mul`, `vec_tanh`, `vec_sigmoid`, `vec_add_scalar`. **Always pre-allocate output buffer.**
- **NAM tone modeling** — `nam!("tone3000://TONE/MODEL")` (Rust) or `load_model(...)` (Python). `list_tones` to discover.
- **Utilities** — `db_to_gain`, `gain_to_db`, `smooth_coeff`, `ms_to_samples`, `soft_clip`, `lerp`, `crossfade`.

## Latency reporting

Declare lookahead/windowing latency so the DAW compensates:
- Python: `LATENCY = 256` (module-level constant, in samples)
- Rust: `latency!(256);` (macro)

**Don't** declare latency for intentional delay/chorus/reverb — those are creative effects, not lookahead.

## Custom UIs (only when asked)

The plugin auto-renders sliders for every param. **Don't write a custom UI unless the user explicitly asks** ("custom UI", "visualization", "XY pad", "skin this"). Plain DSP tasks don't need it.

When the user does ask:
1. Call `conjuredsp__get_docs("ui")` for the full `cdp-*` component reference. Don't guess from memory.
2. `save_preset(..., scaffold_ui=true)` to declare the `ui` block in manifest atomically (avoids generic-slider flash).
3. Write `ui/index.html` via `write_bundle_file`. Use `<cdp-slider>`, `<cdp-knob>`, `<cdp-toggle>`, `<cdp-choice>`, `<cdp-xy>`, `<cdp-meter>`, `<cdp-scope>`, `<cdp-bargraph>`.
4. **Never** add a `<script src="...">` for `cdp-ui.js` — it's pre-injected via `window.ConjureDSP`.
5. **Never** duplicate the param value next to a `<cdp-slider>` — it already renders its own label/value.
6. CSP blocks all external fetch/XHR/WebSocket/CDN imports — bundle assets locally.
7. Wrap JS in `ConjureDSP.ready(() => { ... })` — bridge isn't available before `ready`.
8. Run `validate_bundle` (static) then `smoke_test_ui` (runtime) before claiming done. `smoke_test_ui pass` = binding correctness, not behavioral — for level meters/scopes also ask the user to play audio and confirm visual response.

## Workflow patterns

**Tweak existing preset** (user says "change this", "tweak", "add a knob"):
1. `get_script()` — see what's loaded
2. Edit code
3. `compile_and_run(new_code, language)` — hot reload
4. Tell user what changed

**Create new preset from scratch** (user says "make me a", "create a"):
1. `save_preset(name, source=code, scaffold_ui=false_unless_custom_ui)` — atomic create+switch+load
2. Tell user the bundle name

**Don't** call `compile_and_run` first to "prime" a new preset — pass source directly to `save_preset`. Mixing the two causes drift between disk and kernel.

**Inherit from current preset** (user says "tweak the threshold on this compressor"):
1. `read_bundle_file(current, "process.rs")` — pull current code into context
2. Modify it
3. `save_preset(new_name, source=modified_code)` 
4. If custom UI: also `read_bundle_file` for `ui/index.html`, then `write_bundle_file` after save

## Telemetry (for meters/scopes in UI)

Declare scalar + vector telemetry channels, fill in `process()`, consume in JS:

```rust
telemetry! {
    PEAK_DB  = scalar_telemetry().unit("dB"),
    WAVEFORM = vector_telemetry().unit("samples"),
}
// in process:
ctx.set_telemetry_scalar(PEAK_DB, peak_value);
ctx.set_telemetry_vector(WAVEFORM, &scratch[..ctx.frames()]);
```

JS side: `frame.telemetry['peak_db']` (number), `frame.telemetry['waveform']` (Float32Array).

## Common mistakes

1. **Missing `global`** in Python — `_state = 1` inside `process` creates a local; use `global _state` first.
2. **Allocating in `process()`** — `np.zeros(n)` allocates every block; hoist to module level.
3. **Stale filter coeffs** — recompute `BiquadCoeffs::lowpass(...)` inside `process` when params change, not as a `const`.
4. **Writing telemetry past `ctx.frames()`** — slice `buf[:ctx.frame_count]` or `&buf[..ctx.frames()]`.
5. **`ctx.set_param` does not exist** — DSP scripts can't write params back to the host. Param flow is host → DSP one-way.
6. **`smoke_test_ui` "pass" ≠ visual works** — only binding correctness. Always play audio to verify meters/scopes.
7. **Channel × frame indexing** — Rust `ctx` indexes by `channel * frames + frame`. Don't pass the wrong stride.
8. **`save_preset` always produces a fresh bundle** — nothing auto-inherits from the previously loaded preset. Build-on vs start-fresh is your decision.

## Honesty rules (from agent-workspace/CLAUDE.md)

- Don't fabricate user pushback. If you change approach mid-task, say so explicitly.
- Verify framework capability via `get_docs` or `get_script` before pitching an architecture that depends on it.
- Don't claim "done" on a UI without `smoke_test_ui pass`.

## Related skills

- `reaper-daw` — for hosting / track-level operations around the plugin
- `serum-synth` — different beast (VST closed-source synth)
