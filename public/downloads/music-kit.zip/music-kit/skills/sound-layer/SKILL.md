---
name: sound-layer
description: Sound effects for motion pieces and promo films — real CC0 recordings (1,139 sounds, 19 types: hit, whoosh, riser, ui, click, chime, shimmer…) placed from the picture's own timing, mixed against music and voice to −14 LUFS, then QA'd against the real picture motion. Use for an app promo, a title/logo animation, a calendar/UI motion sequence, transitions in a trailer, «добавь звуки», «саунд-дизайн», «вжухи на переходах». Do NOT use for the music bed itself (scripts/theme_score.py in video-analyzer) or for live music in frame.
---

# Sound layer (third-party: github.com/Bodila51/opus-sound-layer, MIT)

This folder is a git clone of that repo; this SKILL.md is the only local file. Update with `git -C ~/.claude/skills/sound-layer pull`. Never edit its scripts or loosen a QA threshold to make a check pass. The full upstream prompt is `PROMPT.md` beside this file — read it once before the first use.

## How it fits our pipeline

- **Music stays ours.** The score is one layer from `scripts/theme_score.py` (video-analyzer). This skill adds SFX only; pass the score and the voice to `mix.py` as the music/voice stems so it ducks and pitches against them. No second music bed.
- **Library lives outside the repo:** run from a work dir, e.g. `~/Movies/sfx-work/`, so `audio/kit/` (download) is reused across films. First `sfx.py kit` downloads Kenney packs + Freesound picks — run it in the background, 10-minute timeout; check `df -h /` first.
- **Cues come from the picture's timing** (the animation's own keyframes/springs, or our plan's cut list) — never typed by hand. Tag: cut · move · land · appear; one hero hit per ~4 s.
- **Sound only on real actions.** Over speech or live footage: nothing, or at most a soft whoosh on a cut. A promo's UI/calendar sequence is where this earns its keep.
- One sonic family per film (e.g. glass + air for memories). No meme sounds, never synthesized hits.

## Commands

```bash
cd ~/Movies/sfx-work
uv run ~/.claude/skills/sound-layer/scripts/sfx.py kit
uv run ~/.claude/skills/sound-layer/scripts/sfx.py browse --type whoosh --like "soft air glass"   # then LOOK at audio/browse.png
uv run ~/.claude/skills/sound-layer/scripts/mix.py --schema
uv run ~/.claude/skills/sound-layer/scripts/mix.py audio/cues.json
ffmpeg -i video.mp4 -i audio/mix.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 256k -shortest final.mp4
uv run ~/.claude/skills/sound-layer/scripts/qa.py final.mp4      # exit 1 = fix cues/sounds, max 2 rounds
```

Then our own gate still applies before any upload: `scripts/audio_clock.py` in video-analyzer. Credits for the sounds are in `audio/kit/CREDITS.md`; CC0 needs none in the description, but keep the file.
