#!/usr/bin/env python3
"""Shared client for sdsp-chain introspection — the parsing lives ONCE here.

Any script that pushes our plugin parameters into REAPER needs the name→id
map from `sdsp-chain --params <plugin>`; several also need a chain template's
stages. Both encode sdsp-chain's text output format, so both belong in one
module rather than drifting per-script copies (demos8/apply_fx.py carries the
last pre-extraction copy and stays frozen — it is a finished worked example).

    from sdsp_params import CHAIN, param_ids, template_stages
"""

import functools
import os
import shutil
import re
import subprocess
import tomllib
from pathlib import Path

CHAIN = Path(os.environ.get("SDSP_CHAIN") or shutil.which("sdsp-chain") or "~/.cargo-target/release/sdsp-chain").expanduser()

# "  4    Mid Q      0.300     6.000     0.700  " — id, then a name that may
# contain spaces, then min/max/default. Requiring the three numeric columns
# skips the "N presets — see `--presets …`" footer.
_ROW = re.compile(r"^\s*(\d+)\s+(.+?)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)")


def _run(*args):
    out = subprocess.run([str(CHAIN), *args], capture_output=True, text=True)
    if out.returncode != 0:
        raise SystemExit(f"sdsp-chain {' '.join(args)} failed: {out.stderr.strip()}")
    return out.stdout


@functools.lru_cache(maxsize=None)
def param_ids(plugin):
    """name → id, straight from the plugin. Never guess an index."""
    ids = {}
    for line in _run("--params", plugin).splitlines():
        if m := _ROW.match(line):
            ids[m[2].strip()] = int(m[1])
    if not ids:
        raise SystemExit(f"--params {plugin} returned no parameters — wrong key?")
    return ids


def template_stages(name):
    """The [[stage]] list of `sdsp-chain --template <name>`, parsed."""
    return tomllib.loads(_run("--template", name))["stage"]
