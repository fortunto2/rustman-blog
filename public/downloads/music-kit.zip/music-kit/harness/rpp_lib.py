#!/usr/bin/env python3
"""Writers for generating REAPER .rpp project files as text.

Generating the text beats driving REAPER live (media-import dialogs freeze
the IPC bridge's defer loop), and CLAP entries are matched by id, so build
suffixes never matter. demos5/demos8 carry earlier private copies of these
writers (finished one-offs, left frozen); durable generators import this.

Plugin parameters do NOT survive in a generated .rpp — REAPER keeps plugin
state as an opaque blob — so pair a generator with an apply script over
reaper_ipc, then save from REAPER to bake the state in.
"""

import uuid


def guid():
    return "{" + str(uuid.uuid4()).upper() + "}"


def _fx_body(plugins, indent):
    """plugins: (clap display name, clap id, bypassed) triples."""
    out = ""
    for name, cid, bypassed in plugins:
        out += f"""{indent}BYPASS {1 if bypassed else 0} 0 0
{indent}<CLAP "{name}" {cid} ""
{indent}  CFG 4 720 700 ""
{indent}>
{indent}FXID {guid()}
{indent}WAK 0 0
"""
    return out


def fx_chain(plugins):
    if not plugins:
        return ""
    return f"""    <FXCHAIN
      WNDRECT 200 200 720 700
      SHOW 0
      LASTSEL 0
      DOCKED 0
{_fx_body(plugins, "      ")}    >
"""


def master_fx_list(plugins):
    if not plugins:
        return ""
    return f"""  <MASTERFXLIST
    WNDRECT 200 200 720 700
    SHOW 0
    LASTSEL 0
    DOCKED 0
{_fx_body(plugins, "      ")}  >
"""


def track(name, colour, plugins, armed=False, recvs=(), items=""):
    """recvs: (source track index, linear send volume) pairs."""
    recv_lines = "".join(
        f"    AUXRECV {src} 0 {vol:.6f} 0 0 0 0 0 0 -1:U 0 -1 ''\n"
        for src, vol in recvs
    )
    return f"""  <TRACK {guid()}
    NAME "{name}"
    PEAKCOL {colour}
    BEAT -1
    AUTOMODE 0
    PANLAWFLAGS 3
    VOLPAN 1 0 -1 -1 1
    MUTESOLO 0 0 0
    IPHASE 0
    PLAYOFFS 0 1
    ISBUS 0 0
    BUSCOMP 0 0 0 0 0
    SHOWINMIX 1 0.6667 0.5 1 0.5 0 0 0 0
    SEL 0
    REC {1 if armed else 0} 0 1 0 0 0 0 0
    VU 64
    TRACKHEIGHT 0 0 0 0 0 0
    INQ 0 0 0 0.5 100 0 0 100
    NCHAN 2
    FX 1
    TRACKID {guid()}
{recv_lines}{fx_chain(plugins)}{items}  >
"""


def notes(lines):
    body = "".join(f"    |{line}\n" for line in lines)
    return f"  <NOTES 0 2\n{body}  >\n"


def project(tracks, bpm=120, samplerate=48000, master_fx=(), notes_block=""):
    """tracks: concatenated track() blocks."""
    return f"""<REAPER_PROJECT 0.1 "7.0" 1
{notes_block}  RIPPLE 0
  GROUPOVERRIDE 0 0 0
  AUTOXFADE 129
  ENVATTACH 3
  MIXERUIFLAGS 11 48
  PEAKGAIN 1
  FEEDBACK 0
  PANLAW 1
  PROJOFFS 0 0 0
  MAXPROJLEN 0 600
  GRID 3199 8 1 8 1 0 0 0
  TIMEMODE 1 5 -1 30 0 0 -1
  VIDEO_CONFIG 0 0 256
  PANMODE 3
  CURSOR 0
  ZOOM 4 0 0
  VZOOMEX 6 0
  USE_REC_CFG 0
  RECMODE 1
  SMPTESYNC 0 30 100 40 1000 300 0 0 1 0 0
  LOOP 0
  LOOPGRAN 0 4
  RECORD_PATH "Audio" ""
  <RECORD_CFG
  >
  <APPLYFX_CFG
  >
  RENDER_FILE ""
  RENDER_PATTERN "$project"
  RENDER_FMT 0 2 0
  RENDER_1X 0
  RENDER_RANGE 1 0 0 18 1000
  RENDER_RESAMPLE 3 0 1
  RENDER_ADDTOPROJ 0
  RENDER_STEMS 0
  RENDER_DITHER 0
  TIMELOCKMODE 1
  TEMPOENVLOCKMODE 1
  ITEMMIX 1
  DEFPITCHMODE 589824 0
  TAKELANE 1
  SAMPLERATE {samplerate} 0 0
  <RENDER_CFG
  >
  LOCK 1
  <METRONOME 6 2
    VOL 0.25 0.125
    FREQ 800 1600 1
    BEATLEN 4
    SAMPLES "" ""
    PATTERN 2863311530 2863311529
  >
  GLOBAL_AUTO -1
  TEMPO {bpm} 4 4
  PLAYRATE 1 0 0.25 4
  SELECTION 0 0
  SELECTION2 0 0
  MASTERAUTOMODE 0
  MASTERTRACKHEIGHT 0 0
  MASTERPEAKCOL 16576
  MASTERMUTESOLO 0
  MASTERTRACKVIEW 0 0.6667 0.5 0.5 0 0 0 0 0 0 0 0 0 0
  MASTERHWOUT 0 0 1 0 0 0 0 -1
  MASTER_NCH 2 2
  MASTER_VOLUME 1 0 -1 -1 1
  MASTER_PANMODE 3
  MASTER_FX 1
  MASTER_SEL 0
{master_fx_list(master_fx)}{tracks}>
"""
