# Lessons learned (music / DSP / REAPER)

Gotchas we hit in practice. Each one cost real debugging time.


## "REAPER routes no audio through a CLAP plugin unless it explicitly registers the `audio-ports` extension — even for a vanilla stereo-in/stereo-out effect. Without it, `process()` is called but the audio buffer is empty/disconnected, so the plugin appears loaded and parameters work but volume changes are silent."

When building a CLAP audio effect with `clack-plugin` for REAPER, **`audio-ports` is not optional**. Register it in `declare_extensions`:

```rust
fn declare_extensions(builder: &mut PluginExtensions<Self>, _: Option<&Self::Shared<'_>>) {
    builder
        .register::<PluginAudioPorts>()   // ← mandatory for audio to flow
        .register::<PluginParams>();
}
```

Implement `PluginAudioPortsImpl` for the MainThread state. For a stereo effect:

```rust
impl PluginAudioPortsImpl for MyMainThread<'_> {
    fn count(&mut self, _is_input: bool) -> u32 { 1 }
    fn get(&mut self, index: u32, is_input: bool, writer: &mut AudioPortInfoWriter) {
        if index != 0 { return; }
        writer.set(&AudioPortInfo {
            id: ClapId::new(0),
            name: if is_input { b"Input" } else { b"Output" },
            channel_count: 2,
            flags: AudioPortFlags::IS_MAIN,
            port_type: Some(AudioPortType::STEREO),
            in_place_pair: Some(ClapId::new(0)),
        });
    }
}
```

Enable the feature in `Cargo.toml`:
```toml
clack-extensions = { version = "0.1", features = ["params", "audio-ports", "clack-plugin"] }
```

**Symptom of forgetting this:** plugin appears in FX list, slider moves, REAPER calls `process()` (counter increments, `ParamValueEvent`s arrive), but audio passes through unchanged because the host never wires its buffers to your I/O.

**Discovered while building** `superduper-dsp` (M0+M1, 2026-05). Took ~30 min of param-events debugging before this clicked — `process()` was being called but `audio` had nothing to read/write.

Related: debug-plugin-stderr-trap-on-macos for how to log from a Dock-launched plugin host.


## "A CLAP/VST/AU plugin loaded into a Dock-launched DAW (REAPER, Logic, Ableton) cannot reach unified log via stderr — `tracing_subscriber::fmt().with_writer(io::stderr)` produces no output in `log stream --process DAW`. For debug logging from inside a plugin, write to a file directly."

`os_log` / `NSLog` is captured by the unified logging system on macOS; plain `stderr` is not, unless the process was started from a terminal that inherits the file descriptor. REAPER (and most DAWs) launched from the Dock have `stderr` go to `/dev/null`.

**For plugin debugging, write to a file.** Example pattern (from `superduper-dsp/plugin/src/lib.rs`):

```rust
static LOG_FILE: OnceLock<Mutex<Option<File>>> = OnceLock::new();

fn init_logging() {
    LOG_FILE.get_or_init(|| {
        let path = home_dir().join(".myapp").join("plugin.log");
        let _ = create_dir_all(path.parent().unwrap());
        let file = OpenOptions::new().create(true).append(true).open(&path).ok();
        Mutex::new(file)
    });
}

fn dbg_log(args: fmt::Arguments<'_>) {
    if let Some(slot) = LOG_FILE.get() {
        if let Some(file) = slot.lock().as_mut() {
            let _ = writeln!(file, "[{ms}] {}", args);
        }
    }
}

macro_rules! dlog { ($($arg:tt)*) => { dbg_log(format_args!($($arg)*)) } }
```

Tail it: `tail -F ~/.myapp/plugin.log`.

**Not RT-safe** — file I/O in the audio thread. Strictly for development. Wrap audio-thread calls in `if cfg!(debug_assertions)` or behind a verbosity flag once moving past initial bring-up.

**Alternative: `os_log`** via the `oslog` crate (or raw `os_log_create` FFI). Goes straight into unified logging and is RT-safer than file I/O. Worth doing once the project moves past debug-grade tooling.

Related: clap-audio-ports-mandatory-in-reaper — found via this logging trick.


## "REAPER keeps a CLAP module loaded for the whole session; a rebuilt .clap won't go live until restart or Clear cache+rescan"

REAPER loads a CLAP plugin's dylib **once per session** and keeps it resident.
Once any instance of `SuperDuperX.clap` has been instantiated (even one you
later delete), rebuilding + reinstalling that `.clap` does **not** take effect
on the next `track_fx_add_by_name` — REAPER re-uses the in-memory module, so
you get the OLD binary. Symptom hit 2026-07-24: installed Sampler was `[b3195]`
on disk but REAPER kept instantiating `[b53069]` (an earlier session build).

**Tell which binary is live:** the `[bNNNNN]` suffix in the FX display name
(`track_fx_get_name`). `SDSP_BUILD_NUM` = **last 5 digits of unix-seconds at
build time** (`sdk-build`), so it is **NOT monotonic** — don't compare numbers,
just match REAPER's `[bNNNNN]` against `strings <installed-binary> | grep -oE '\[b[0-9]+\]'`.

**To make a rebuilt plugin go live in a running REAPER:** restart REAPER
(`scripts/restart_reaper.sh` — the `__startup.lua` auto-starts the MCP bridge,
so tools work right after) **or** Preferences → Plug-ins → CLAP → *Clear cache
and re-scan* (a GUI click the user must do). The `.clap` file on disk being new
is necessary but not sufficient. Don't build a whole arrangement layer on a
freshly-patched plugin without confirming the live build number first — deliver
via python render (which is host-independent) if a restart isn't wanted mid-session.
See reference_sampler_headless_load.

**Проверка, какой билд реально загружен (2026-09-19):** `lsof -p $(pgrep -x REAPER) | grep <Plugin>` и сравнить inode с `ls -i` файла на диске — display-имя `[bNNNNN]` в проекте кешируется в .rpp и ВРЁТ. Сегодня «неработающий sidechain» компрессора три раунда подряд оказался старым замапленным inode, код был исправен.

**Мост-грабли:** незабранный `request_*.json` переживает перезапуск REAPER, и мост выполняет его при старте — залипший `Main_OnCommand(40004)` (Quit) закрывал REAPER сразу после запуска, выглядело как краш. Перед перезапуском чистить `mcp_bridge_data/`. Синтаксическая ошибка в heredoc-Lua (`\n` вместо `\\n`) открывает модальное «ReaScript Error», и defer-цикл моста стоит, пока окно не закрыто (можно закрыть через osascript click button "Close").


## "superduper-wave boots on ~/.superduper-dsp/wave/last.json (user's last-drawn wavetable), NOT the factory sine — breaks DSP-quality tests that assume a clean sine default"

`superduper-wave`'s `new_shared` calls `user_extra::repo().load_last()` which
loads `~/.superduper-dsp/wave/last.json` (the auto-saved last-edited wavetable)
and **overrides the factory Init (Sine) default**. This is documented intended
behavior (fresh instance = your last patch), but it is machine-local state.

**The trap:** any test that instantiates the plugin via CLAP and assumes a clean
sine (e.g. `tests/quality_audit.rs` measuring THD/aliasing) actually measures
whatever wavetable is saved on disk. On this Mac `last.json` held a hand-drawn
staircase (`frame_a=[1,1,1,…]`), so THD read −7.47 dB and aliasing −24.77 dB —
looked like a real DSP bug (odd-harmonic square spectrum) but the DSP was clean.

**Diagnosis that nails it fast:** if a "distortion" is *identical with antialias
ON vs OFF*, it is NOT the mip/oscillator path — the wavetable content itself is
wrong. Dump `shared.wavetable[0].levels[0]` at activate vs the freshly-baked
`render_formula_mip(sine)` in `PluginShared::new` — if they differ, something
(load_last / state.load / push_custom_frames) overwrote it after new_shared.

**Fix in place:** `SUPERDUPER_WAVE_FACTORY=1` env var makes `new_shared` skip
`load_last` and boot on the factory sine. `quality_audit.rs` sets it. Never
delete the user's `last.json` to "fix" a test — it's their drawn wavetable.

Same load_last pattern exists for other synths (Kubyz) via
`synth_core::user_preset::PresetRepo::load_last` → `<slug>/last.json`. Watch for
the same test-isolation trap there. See reference_superduper_loudness_meter_bug_fixed
for another "looked like DSP bug, was measurement/context" case in this repo.


## "Run Demucs stem separation via uvx (no install) — the exact working invocation, and the --with numpy gotcha"

Stem separation (vocals/drums/bass/other) is **installed persistently** as a
uv tool — `demucs` is a plain command on PATH (`~/.local/bin/demucs` →
`~/.local/share/uv/tools/demucs`, numpy 2.4.6 + torch 2.13 baked in). Just:

```bash
export PATH="$HOME/.local/bin:/opt/homebrew/bin:$PATH"
demucs -o <OUTDIR> "<input>"
```

Installed via `uv tool install demucs --with numpy` (the **`--with numpy` is
what avoids** torch's `Failed to initialize NumPy` crash). Reinstall/upgrade:
`uv tool install --force demucs --with numpy`. No-install fallback (ephemeral):
`uvx --with numpy --from demucs demucs …` (same numpy caveat; `--from demucs`
because `uvx demucs` alone mis-resolves the entrypoint). The prior "scratchpad
`kx` venv" note is stale (per-session, gone). First run caches
torch + htdemucs weights in `~/.cache/uv`; later runs are fast. Output →
`<OUTDIR>/htdemucs/<name>/{vocals,drums,bass,other}.wav`. `--two-stems=vocals`
= just vocals + no_vocals (≈2× faster, clean acapella/instrumental).

CPU-only on this M1 (~1-3 min/song); `timeout` isn't on macOS (don't wrap).
Full how-to + variants in the **`stem-split`** global skill. Feeds straight
into sdsp-mash `track` and sample-chop flips (chop the isolated
`vocals.wav` = clean Fred-again.. chops, no backing bleed). Past batch outputs:
`…/scratchpad/mash/htdemucs/` + `…/verify/htdemucs/`.


## "synth-core's LUFS/True-Peak meter had two systemic bugs (fixed 2026-07-16) — affects sdsp-chain, sdsp-mash, and the Spectrum plugin's LUFS display"

`synth-core/src/loudness.rs` had two bugs, found while debugging an sdsp-mash mashup that
sounded flat despite the engine reporting good LUFS/TP numbers.

**Bugs (both fixed, regression-tested against EBU 3341 calibration signal):**
1. BS.1770 loudness summed-then-divided by `block_size × 2` (channel averaging) instead of
   summing across channels per §5.6 → every stereo reading read **~3.01 dB too quiet**.
2. True-peak detector used linear interpolation between samples — mathematically incapable
   of exceeding the max of neighboring samples → **inter-sample overs were invisible**,
   this was effectively a sample-peak meter mislabeled as true-peak.

**Why it matters beyond tonight's mashups:** this is shared code — used by `sdsp-chain`
(headless mastering CLI) AND the **Spectrum plugin's real-time LUFS meter** (used in REAPER
sessions). Any mastering decision made by eye on that meter was ~3 dB hotter than believed,
with true-peak overs going undetected. Old sdsp-mash renders (minisets, pingpong, lead+bridge
from 2026-07-15/16) were calibrated against the broken meter — actual loudness is ~-7 LUFS
with mp3 true-peak overs up to +0.7 dBFS, not the -9..-11 LUFS / -1.0 dBTP originally reported.

**How to apply:** if remastering anything via sdsp-chain/sdsp-mash from before 2026-07-16
(evening), re-verify with `ffmpeg -af ebur128=peak=true -f null -` on the actual delivered
file — don't trust the engine's own printed LUFS/TP until confirmed fixed in that session.
Same caution applies to any REAPER mix decisions made watching the Spectrum plugin meter
before this fix.


## "SuperDuper Sampler now loads a sample when the Sample param changes (headless/MCP), not only via GUI; sample index is deterministic"

SuperDuper **Sampler** used to swap `active_sample` **only** in the GUI dropdown
helper (`pick_sample`), so a fresh instance driven over the wire stayed empty
(silent) and setting the `Sample` param did nothing. Fixed 2026-07-24 (build
`[b3195]`+): audio `process()` detects a `P_SAMPLE` change vs `current_index`
→ `host.request_callback()`; `on_main_thread()` **and** the main-thread param
`flush` call `maybe_load_pending_sample()` which decodes + swaps off the RT
thread (clamps out-of-range index to the last sample). Now MCP / producer-pal /
automation can pick a sample with no GUI. Verify in REAPER via
`~/.superduper-dsp/sampler.log` line `headless sample load: idx N -> pack/stem`.
Unit test: `effects/superduper-sampler/tests/headless_sample_load.rs`.

**Sample index is deterministic** — `scan_folders` collects every `.wav`
(recursive, depth ≤4) under roots `~/Music/SuperDuper Samples` +
`~/Music/Favorite 808s` (the latter often doesn't exist as a separate root —
it's a *subfolder* inside SuperDuper Samples), tags each with `pack` (first-
level subfolder name, or root name at root level), and sorts by `(pack, path)`
(path = Rust component-wise Ord). So the `Sample` param index for any file can
be computed in python (replicate the sort) — no GUI probing. Param range is
0..255 (`param_count` capped 255): if the library exceeds 256 files, samples
sorting past index 255 are unreachable via the param (was true — 342 files;
`kubiz-bash` plucks land 214–250, still reachable; `kubiz-tatar`/`yakut` past
255 are not). Index script: scratchpad `sampler_index.py`.

This unlocks the beatmaker **chop workflow** the user wants (project_dj_set_dramaturgy_kubyz):
I slice a track into WAVs in python, drop them in a scanned folder, compute
each slice's index, and sequence via Sampler + MIDI — all headless. A true
per-key slice-map (MPC-style, one loaded file → slices across keys) is the
bigger follow-on, not yet built. See reference_reaper_clap_dylib_session_cache
— REAPER must restart / rescan to pick up the rebuilt Sampler binary.


## Pyodide Python (WASM/Emscripten) lives in ~/.local/bin/python3.* and looks like normal CPython but breaks any package that builds C extensions or spawns subprocesses.

`~/.local/bin/python3.12`, `python3.13`, etc. on this machine are **Pyodide builds** (Emscripten/WASM, managed by uv), NOT native CPython. Symptoms when used by mistake:
- `OSError: [Errno 138] emscripten does not support processes`
- `Cannot find pyodide pip. Make a pyodide venv first?`
- No `pip` / no `ensurepip` in the resulting venv.
- C-extension wheels (cffi, cryptography, pydantic-core) fail to build/resolve.

**Native CPython on this Mac:**
- Homebrew: `/opt/homebrew/bin/python3.10 … python3.14` (preferred)
- python.org framework: `/usr/local/bin/python3.11`, `/usr/local/bin/python3.13` → `/Library/Frameworks/Python.framework/Versions/*/bin/`

**How to apply:** When creating venvs for normal CLI/desktop tools (MCP servers, audio scripts, DAW integrations), always pass an explicit interpreter path from `/opt/homebrew/bin/...` or `/Library/Frameworks/...`. Verify with `uv python list` — Pyodide entries show `pyodide-3.x.y-emscripten-wasm32-musl`. Reserve `~/.local/bin/python*` for Pyodide experiments only.


## "Mixxx has NO Ableton Link support — confirmed by binary inspection, not just docs"

Mixxx does **not** support Ableton Link (verified on Mixxx 2.5.6, macOS, this machine). Confirmed by inspecting the app binary, not docs:

- `otool -L /Applications/Mixxx.app/Contents/MacOS/mixxx` → no link/carabiner library linked.
- No Link frameworks in `Contents/Frameworks/`.
- `strings` on the binary → only `EngineSync` (Mixxx's internal deck-to-deck sync) and "Ableton Push" (a MIDI controller). Zero Ableton-Link control objects.
- Mixxx forum thread "Will Mixxx ever have Ableton Link support?" = long-standing unfulfilled feature request (historical reason: Link's license vs Mixxx GPL).

Consequence: you cannot tempo-sync Mixxx to REAPER (or any DAW) via Link. The crown/SYNC button is only internal deck sync, NOT Link. Mixxx also doesn't reliably send MIDI clock out. **Do not send the user hunting for a Link button in Mixxx — it does not exist.**

Working alternative for "play synths/REAPER in time with Mixxx": **manual BPM match** — read the deck BPM, type it into REAPER's tempo, start the part on the downbeat by ear. For true auto-Link you'd need a Link-capable DJ app instead (Traktor Pro 3+, Serato, djay Pro, VirtualDJ).

reference-reablink-reaper-link note: ReaBlink makes REAPER Link-capable, but it has no Mixxx peer to talk to — `num peers` stays 0. Useful only if a real Link app (Ableton Live, Traktor) joins.

Part of the REAPER↔Mixxx routing setup via BlackHole aggregate ("Mixx Rig").


## "SwiftF0 pitch detector converted to Core ML (212 KB, ~1 ms/s on M1 ANE); split-model recipe + preprocessing contract in ~/Music/1music/swiftf0-coreml/"

SwiftF0 (lars76, CC-BY-4.0, 90% accuracy in its benchmark) runs as native Core ML:
`~/Music/1music/swiftf0-coreml/` holds `SwiftF0.mlpackage` (212 KB fp16, input
[1,132,62] = 1 s @16 kHz), `cnn.onnx` (dynamic frames, for ORT), and README with
the full recipe.

**Why split:** the ONNX graph contains an STFT node — no converter accepts it
(coremltools has no ONNX frontend, onnx2torch dies on opset 20). STFT is done
outside (vDSP / our Rust): pad 384 zeros both sides, frame 1024 / hop 256,
asymmetric hann from the ONNX initializer, |rFFT| bins 3..135, log(+1e-8),
layout [1,132,T]. Verified bit-exact vs the full model. Decode is inside the
model (±9-bin weighted mean over 200 log bins 46.9–2093.8 Hz; confidence = local
prob mass).

**M1 numbers:** ANE 1.05 ms per 1 s window (~960× RT), ORT-CPU full 8.3 ms.
CNN was re-built by hand in torch (weights lifted from initializers, ≤3e-5 Hz
diff) — torch 2.7.1 + torchvision 0.22.1 + coremltools 9.0.

Use for: live2play-inapp-synth-chain iOS pitch tracking, offline analysis
(Melodyne-lite plans in superduper-pitch), track-teardown key/melody extraction.
Our RT plugins keep the FFT-YIN tracker (zero-latency, no NN dep).


## "Wave & Kubyz plugins gained CC7→output-VCA (live volume swell) + an 'Aulos (Odyssey)' factory preset — added 2026-07-24"

Added to **both** `superduper-wave` and `superduper-kubyz` (2026-07-24), PARAMS untouched
(no project/automation breakage), all tests green (Wave 26/26, Kubyz all), bundles rebuilt +
installed to `~/Library/Audio/Plug-Ins/CLAP/`.

**1. CC7 (Channel Volume) → smoothed output VCA.** A live breath/expression *volume* swell for
sustained notes — the thing wind players do. Implemented as an internal `cc_volume: AtomicF32`
(init 1.0 = neutral, so absent CC7 leaves old projects unchanged) + `smooth_cc_vol:
SmoothedParam`, multiplied onto the final output. NOT a param (can't touch frozen PARAMS,
and CC must not raise the dirty bit → no FX-automation feedback loop). Chosen CC7 because it's
free in BOTH plugins' CC maps AND the user's own live2play gesture map already routes
off-hand→CC7→vol (see reference_live2play_default_gesture_map) — so the gesture-volume
now actually drives synth volume for live swells. (Wave already used CC1/11/71/74 for
timbre; Kubyz CC1/2/11/71/74 — CC2 was taken by Mouth Stereo, hence CC7 not CC2.)

**2. "Aulos (Odyssey)" factory preset.** Recalls a whole aulos-like timbre in one shot
(remote via the stepped Preset param — Wave idx 37, Kubyz idx 19 — no GUI). Tuned to the
real spectrum of Göransson's *Odysseus* (1-20) drone: weak fundamental, strong H2/H4/H6,
double-pipe detune beating, formant ~300-800 Hz, breathy, slow swell. Wave: saw→formant_a,
Unison 3 / Detune 12ct / Cutoff 1800 / Reson 0.35 / Drive 0.25 / Noise 0.12 / A 0.5 S 0.9
R 0.6. Kubyz: formants 320/560/780 Hz, H2-H6 lifted, **sustain-swell** env (sustain 0.85,
unlike the pluck-decay jaw-harp presets) since an aulos sustains.

**Why it matters (the vision):** the plugins exist so an agent/DAW can drive them headless.
All ~38 named CLAP params are already remote-controllable via REAPER MCP `track_fx_set_param`
(0..1); the Preset param recalls whole scenes. These two additions close the last gap for
*expressive* remote/live play: real-time volume swell (CC7) + one-call timbre scenes (Aulos).

**Gotcha on adoption:** a REAPER instance with the OLD binary already loaded won't see the new
preset/CC7 until CLAP cache clear + re-scan (Prefs → Plug-ins → CLAP) or a REAPER restart.
Preset recall via param applies most reliably while a note is playing (idle-track param events
may not reach the plugin) — see project CLAUDE.md.

See also: reference_live2play_default_gesture_map, project_live2play_dj_player_2channel.


## "When the Arrow is disconnected its aggregate degrades to 2ch and the Arrow vanishes; connected, cpal sees full channels — target the Arrow directly for livehub"

Discovered building `livehub` (M0), then corrected:

- **If the UA Arrow is physically disconnected/asleep**, the "Mixx Rig" aggregate that
  contains it **degrades to 2ch** (only its BlackHole member survives) and the Arrow
  itself **vanishes** from both `system_profiler SPAudioDataType` and cpal's device list.
  This looks like a cpal limitation but is just the missing hardware member.
- **When the Arrow is connected**, cpal 0.15 sees everything correctly:
  - `Universal Audio Thunderbolt` directly — **6 ch out / 10 ch in**, single stream,
    `supported_*_configs` reports the full count.
  - `Mixx Rig` aggregate — **8 ch out / 12 ch in**.
  So cpal DOES open multichannel CoreAudio devices fine; the earlier "aggregate = 2ch"
  was a disconnected-Arrow artifact, not a cpal bug.

**For livehub: target the Arrow DIRECTLY** (`--device "Universal Audio"`), not the
aggregate. It's the clean end-state — livehub replaces the whole Mixxx/BlackHole/aggregate
chain (project-reaper-mixxx-blackhole-rig, reference-mixxx-no-ableton-link), so
the aggregate becomes obsolete. Arrow direct channel map (0-based interleaved):
**out 0/1 = MON L/R (master/speakers), 2/3 = VIRTUAL, 4/5 = HP L/R (cue/headphones)**;
**in 0/1 = MIC/LINE/HIZ 1-2 (mic = in 0)**. livehub's default device hint is "Universal Audio".
