#!/usr/bin/env python3
"""Talk to REAPER directly through the MCP bridge's file IPC.

The bridge (mcp_bridge_file_v2.lua) can call ANY reaper.* function by name, not
just the DSL tools the MCP server exposes. Writing the request file ourselves is
an order of magnitude faster than one MCP round-trip per parameter — a full FX
setup is ~30 calls, which is minutes over MCP and about a second here.

Why this matters beyond speed: REAPER stores CLAP parameters in an opaque base64
blob, so a generated .rpp always loads its plugins at defaults. Keeping the
settings in a Python list means regenerating the project costs nothing — rebuild
the .rpp, re-run the setup, and the mix is exactly where it was.

Request ids live in 900-999. The bridge's poll loop is a literal
`for i = 1, 1000` over request_<i>.json, so an id above 1000 is never seen —
requests just pile up unanswered. The MCP server counts up from 0, so the top of
the range is the safe end. Do not run this while MCP tool calls are in flight.

    from reaper_ipc import call, set_params
"""

import json
import time
from pathlib import Path

DATA = Path.home() / "Library/Application Support/REAPER/Scripts/mcp_bridge_data"
ID_LO, ID_HI = 900, 999
# Start each client at a random slot: every fresh python process used to
# begin at 900, so a response left behind by a hung predecessor was read as
# the answer to the newcomer's first call (measured 2026-09-20: a TrackFX
# add returned command-id 55877 as its "fx index"). Randomising the start
# makes stale collisions unlikely; the stale-response purge below does the rest.
import random as _random
_next_id = [ID_LO + _random.randrange(ID_HI - ID_LO)]


def call(func, *args, timeout=10.0):
    """Invoke reaper.<func>(*args). Returns the bridge's decoded reply."""
    rid = _next_id[0]
    stale = DATA / f"response_{rid}.json"
    if stale.exists():
        stale.unlink(missing_ok=True)
    _next_id[0] = ID_LO if rid >= ID_HI else rid + 1
    req = DATA / f"request_{rid}.json"
    res = DATA / f"response_{rid}.json"
    req.write_text(json.dumps({"id": rid, "func": func, "args": list(args)}))
    deadline = time.time() + timeout
    while time.time() < deadline:
        if res.exists():
            try:
                out = json.loads(res.read_text())
            except json.JSONDecodeError:
                time.sleep(0.02)
                continue
            res.unlink(missing_ok=True)
            return out
        time.sleep(0.02)
    req.unlink(missing_ok=True)
    raise TimeoutError(f"{func}{args}: bridge did not answer in {timeout}s "
                       "(is the Lua action still running in REAPER?)")


def set_params(rows, verbose=True):
    """rows: (track_index, fx_index, param_index, value, label). 0-based indices,
    values in real units (Hz, dB, semitones, or a stepped param's index)."""
    for track, fx, param, value, label in rows:
        call("TrackFX_SetParam", track, fx, param, float(value))
        if verbose:
            print(f"  t{track} fx{fx} p{param:<3d} = {value:<8g} {label}")


def track_volume_db(track, db):
    call("SetMediaTrackInfo_Value", track, "D_VOL", 10 ** (db / 20.0))


def open_project_in_new_tab(path, timeout=10.0):
    """New tab first: opening into the current tab pops a save dialog when the
    project is dirty, and a modal dialog freezes the bridge's defer loop.

    Main_openProject completes on a LATER defer tick — scripts sent right
    after it used to run in the previous tab (measured 2026-09-23: a test
    rig built itself inside the Manifest project). So poll until the active
    project actually is the requested file before returning."""
    call("Main_OnCommand", 40859, 0)      # New project tab
    call("Main_openProject", str(path))
    want = str(path)
    deadline = time.time() + timeout
    while time.time() < deadline:
        got = call("EnumProjects", -1, "", 512)
        name = got.get("ret_str") or got.get("filename") or ""
        if isinstance(name, str) and name.endswith(want.rsplit("/", 1)[-1]):
            return
        time.sleep(0.4)
    raise TimeoutError(f"active project never became {want}")


def run_reascript(lua_source, name="reaper_ipc_oneshot"):
    """Register a one-shot ReaScript and run it. The escape hatch for anything
    the generic bridge can't address — e.g. the master track has no index, so
    TrackFX_SetParam on it needs reaper.GetMasterTrack() inside Lua."""
    script = Path(f"/tmp/{name}.lua")
    script.write_text(lua_source if lua_source.endswith("\n") else lua_source + "\n")
    # Syntax-check BEFORE handing the file to REAPER. A malformed script
    # does not fail there — it opens a modal "ReaScript Error" window, and a
    # modal freezes the bridge's defer loop, so one typo hangs every later
    # call until a human clicks Close. Both real cases from 2026-09-20 are
    # caught here: a raw newline inside a string (python heredoc "\n" typo)
    # and `.."..N.."` concatenation parsing as the malformed number `N..`.
    import shutil as _sh, subprocess as _sp
    _luac = _sh.which("luac") or "/opt/homebrew/bin/luac"
    if Path(_luac).exists():
        _r = _sp.run([_luac, "-p", str(script)], capture_output=True, text=True)
        if _r.returncode != 0:
            raise SyntaxError(
                "Lua rejected before reaching REAPER (a modal there freezes the bridge):\n"
                + _r.stderr.strip())
    cid = call("AddRemoveReaScript", True, 0, str(script), True).get("ret", 0)
    if not cid:
        raise RuntimeError(f"AddRemoveReaScript refused {script}")
    call("Main_OnCommand", cid, 0)
