#!/usr/bin/env python3
"""Write the "SuperDuper Vocal Chain" REAPER project template.

The chain comes from `sdsp-chain --template vocal` — the ONE place the stage
order lives. Serial stages become the Vocal track's FX (with tune prepended,
bypassed); the trailing delay/reverb stages become 100%-wet send returns
(the pro topology the serial template can only approximate). The Beat track
and its vocal pocket are project-topology choices, not chain choices, so
they are defined here.

Plugin PARAMETERS are not stored in a generated .rpp — REAPER keeps plugin
state as an opaque blob — so after generating, open the project once and run
apply_fx.py: it reads the same template, sets every knob, and saves. From
then on the template is self-contained.

    python3 build_rpp.py     # writes into REAPER's ProjectTemplates + a copy here
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import rpp_lib  # noqa: E402
from sdsp_params import template_stages  # noqa: E402

NAME = "SuperDuper Vocal Chain.rpp"
TEMPLATES = Path.home() / "Library/Application Support/REAPER/ProjectTemplates"

CLAP = {
    "tune":       ("CLAPi: SuperDuper Tune (SuperDuperAI)",       "co.superduperai.tune"),
    "eq":         ("CLAPi: SuperDuper Eq (SuperDuperAI)",         "co.superduperai.eq"),
    "compressor": ("CLAPi: SuperDuper Compressor (SuperDuperAI)", "co.superduperai.compressor"),
    "vocal":      ("CLAPi: SuperDuper Vocal (SuperDuperAI)",      "co.superduperai.vocal"),
    "saturator":  ("CLAPi: SuperDuper Saturator (SuperDuperAI)",  "co.superduperai.saturator"),
    "soothe":     ("CLAPi: SuperDuper Soothe (SuperDuperAI)",     "co.superduperai.soothe"),
    "delay":      ("CLAPi: SuperDuper Delay (SuperDuperAI)",      "co.superduperai.delay"),
    "reverb":     ("CLAPi: SuperDuper Reverb (SuperDuperAI)",     "co.superduperai.reverb"),
    "limiter":    ("CLAPi: SuperDuper Limiter (SuperDuperAI)",    "co.superduperai.limiter"),
}

SPACE = ("delay", "reverb")          # stage kinds that become send returns
RECV_LEVEL = {"delay": 0.15, "reverb": 0.20}   # linear send volume from Vocal

# Track indices shared with apply_fx.py.
T_VOCAL, T_BEAT, T_RETURNS = 0, 1, 2


def split_stages(stages):
    """(serial stages, trailing space stages). The rule: the maximal trailing
    run of delay/reverb stages moves onto ducked send returns."""
    n = len(stages)
    while n > 0 and stages[n - 1]["plugin"] in SPACE:
        n -= 1
    return stages[:n], stages[n:]


def clap(key, bypassed=False):
    name, cid = CLAP[key]        # KeyError here = extend CLAP{} for a new stage
    return (name, cid, bypassed)


def main():
    serial, space = split_stages(template_stages("vocal"))
    if not space:
        raise SystemExit("template has no trailing delay/reverb — nothing to put on returns")

    vocal_fx = [clap("tune", bypassed=True)] + [clap(s["plugin"]) for s in serial]
    body = rpp_lib.track("Vocal", 0x22AACC, vocal_fx, armed=True)
    body += rpp_lib.track("Beat", 0x4466CC, [clap("eq")])
    for st in space:
        body += rpp_lib.track(
            f"{st['plugin'].capitalize()} FX", 0x996699, [clap(st["plugin"])],
            recvs=[(T_VOCAL, RECV_LEVEL.get(st["plugin"], 0.2))])

    notes = rpp_lib.notes([
        'SuperDuper Vocal Chain — record into "Vocal", drop the instrumental on "Beat".',
        "",
        "The FX order IS the template: tune (bypassed; enable + set Key for hard-tune),",
        "then the serial chain, with the space stages on ducked send returns.",
        "",
        "Numbers are starting points, the order is not. Reference:",
        "  sdsp-chain --template vocal        (same chain, headless)",
        '  sdsp-mix skill, "The channel chain" (why each slot)',
        "",
        "Regenerate params after edits to the chain template:",
        "  python3 ~/Music/1music/vocal-template/apply_fx.py",
    ])
    project = rpp_lib.project(body, bpm=120, samplerate=48000,
                              master_fx=[clap("limiter")], notes_block=notes)

    TEMPLATES.mkdir(parents=True, exist_ok=True)
    out = TEMPLATES / NAME
    out.write_text(project)
    (HERE / NAME).write_text(project)
    print(f"wrote {out}")
    print(f"  vocal chain: tune + {' → '.join(s['plugin'] for s in serial)}")
    print(f"  returns: {', '.join(s['plugin'] for s in space)}")
    print("  open it once and run apply_fx.py, then save — see NOTES inside")


if __name__ == "__main__":
    main()
