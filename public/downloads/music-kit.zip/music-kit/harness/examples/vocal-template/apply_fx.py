#!/usr/bin/env python3
"""Set every knob of the open "SuperDuper Vocal Chain" project and save it.

Single source of truth: the chain template (`sdsp-chain --template vocal`).
Both this script and build_rpp.py derive the track/FX layout from that TOML
through the same split_stages() — serial stages on the Vocal track, trailing
delay/reverb on 100%-wet send returns — so a template edit changes both or
breaks both loudly, never one silently.

    python3 build_rpp.py
    open -a REAPER "~/Library/Application Support/REAPER/ProjectTemplates/SuperDuper Vocal Chain.rpp"
    python3 apply_fx.py
"""

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from build_rpp import T_BEAT, T_RETURNS, T_VOCAL, split_stages  # noqa: E402
from reaper_ipc import call, run_reascript, set_params  # noqa: E402
from sdsp_params import param_ids, template_stages  # noqa: E402

# Not in the TOML: tune ships commented-out there (keep these four in sync
# with its commented stage 0), and the other two are project-topology
# choices — the pocket lives on the Beat track, the safety ceiling on master.
TUNE = {"Key": 0.0, "Scale": 1.0, "Retune": 0.0, "Amount": 1.0}
POCKET = {"Mid Freq": 500.0, "Mid Gain": -3.0, "Mid Q": 0.6}
MASTER_LIMITER = {"Input": 0.0, "Ceiling": -1.0, "True Peak": 1.0}


def rows(track, fx, plugin, values, label):
    ids = param_ids(plugin)
    out = []
    for pname, val in values.items():
        pid = ids.get(pname)
        if pid is None:
            raise SystemExit(f"{plugin} has no parameter {pname!r}")
        out.append((track, fx, pid, float(val), f"{label} {pname}"))
    return out


def main():
    serial, space = split_stages(template_stages("vocal"))
    expected_tracks = 2 + len(space)
    n = call("CountTracks", 0).get("ret")
    if n != expected_tracks:
        raise SystemExit(f"expected the {expected_tracks}-track template project "
                        f"open in REAPER, found {n} tracks — regenerate with build_rpp.py?")

    params = rows(T_VOCAL, 0, "tune", TUNE, "vocal/tune")
    for i, st in enumerate(serial):
        params += rows(T_VOCAL, 1 + i, st["plugin"], st.get("params", {}),
                       f"vocal/{st['plugin']}")
    # Returns run 100% wet — the send level plays the template's Mix role.
    for i, st in enumerate(space):
        p = dict(st.get("params", {}), Mix=1.0)
        params += rows(T_RETURNS + i, 0, st["plugin"], p, f"return/{st['plugin']}")
    params += rows(T_BEAT, 0, "eq", POCKET, "beat/eq")

    # Plugins only reliably take parameter events while transport runs.
    call("Main_OnCommand", 1007, 0)          # Play
    print(f"parameters ({len(params)})")
    set_params(params)
    ids = param_ids("limiter")
    lua = ["local m = reaper.GetMasterTrack(0)"] + [
        f"reaper.TrackFX_SetParam(m, 0, {ids[p]}, {v})" for p, v in MASTER_LIMITER.items()
    ]
    run_reascript("\n".join(lua), "sdsp_master_vocal_tpl")
    print(f"  master limiter: {len(MASTER_LIMITER)} params")
    call("Main_OnCommand", 1016, 0)          # Stop

    # Spot-check one knob per track (values taken from the parsed template,
    # not hardcoded) before trusting the save.
    checks = [(T_VOCAL, 1, serial[0]["plugin"],
               *next(iter(serial[0]["params"].items())))]
    checks += [(T_RETURNS + i, 0, st["plugin"], "Mix", 1.0) for i, st in enumerate(space)]
    checks += [(T_BEAT, 0, "eq", "Mid Gain", POCKET["Mid Gain"])]
    ok = True
    for tr, fx, plugin, pname, want in checks:
        # The bridge returns TrackFX_GetParam's multi-value result as
        # {"value":…, "min":…, "max":…}, not under "ret".
        got = call("TrackFX_GetParam", tr, fx, param_ids(plugin)[pname]).get("value")
        good = got is not None and abs(got - float(want)) < 0.05
        ok &= good
        print(f"  {'ok ' if good else '!! '}track {tr} fx {fx} {pname} = {got} (want {want})")
    if not ok:
        raise SystemExit("readback mismatch — NOT saving; is the right project focused?")

    call("Main_OnCommand", 40026, 0)         # File: Save project
    print("saved — the template now carries its parameters")


if __name__ == "__main__":
    main()
