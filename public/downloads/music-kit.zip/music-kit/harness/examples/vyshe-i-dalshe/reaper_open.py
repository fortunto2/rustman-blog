"""Open a regenerated .rpp in REAPER without REAPER writing over it.

Two traps, both hit while building vyshe-minimal:
  * `Main_openProject` on a path that is already open in another tab only SWITCHES to that
    tab (old in-memory state); the save at the end then wrote the old state over the
    regenerated file. So every tab holding the path is closed first.
  * closing a dirty tab prompts "Save before closing?" = modal = dead bridge. A dirty tab is
    parked under a scratch name with a real Save As (option 1), which clears dirty.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from reaper_ipc import call, run_reascript  # noqa: E402


def is_project(ntracks, marker_t):
    m = call("EnumProjectMarkers", 0).get("ret")
    return bool(m) and abs(m[2] - marker_t) < 0.01 and call("CountTracks", 0)["ret"] == ntracks


def tabs():
    """[(index, filename, dirty)] — the bridge's EnumProjects returns only a pointer, so Lua dumps it."""
    run_reascript(r"""
local f = io.open("/tmp/vd_tabs.txt", "w")
local i = 0
while true do
  local proj, fn = reaper.EnumProjects(i, "")
  if not proj then break end
  f:write(i .. "\t" .. fn .. "\t" .. reaper.IsProjectDirty(proj) .. "\n")
  i = i + 1
end
f:close()
""", "vd_tabs")
    time.sleep(1.2)
    out = []
    for line in open("/tmp/vd_tabs.txt").read().splitlines():
        i, fn, d = line.split("\t")
        out.append((int(i), fn, int(d)))
    return out


def close_tabs_with(rpp: Path):
    """Close every tab holding rpp. The close itself (40860) goes through the bridge directly:
    issuing it from inside a ReaScript killed the bridge's defer loop (2026-10-17)."""
    closed = 0
    while closed < 8:
        hit = [t for t in tabs() if t[1] == str(rpp)]
        if not hit:
            break
        i, _fn, dirty = hit[0]
        park = str(rpp.with_name(f"{rpp.stem}.parked-{int(time.time())}.rpp"))
        run_reascript(f"""
local proj = reaper.EnumProjects({i}, "")
reaper.SelectProjectInstance(proj)
if {dirty} ~= 0 then reaper.Main_SaveProjectEx(proj, "{park}", 1) end
""", "vd_select_tab")
        time.sleep(1.0)
        call("Main_OnCommand", 40860, 0)
        time.sleep(1.2)
        closed += 1
    return closed


def open_fresh(rpp: Path, ntracks, marker_t):
    n = close_tabs_with(rpp)
    size = rpp.stat().st_size
    call("Main_OnCommand", 40859, 0)
    call("Main_openProject", str(rpp))
    for _ in range(60):
        time.sleep(0.5)
        if is_project(ntracks, marker_t):
            assert rpp.stat().st_size == size, "REAPER rewrote the project file while opening"
            print(f"opened {rpp.name} (closed {n} stale tab(s))")
            return
    raise RuntimeError("project did not come up")


def colour_items_by_chord(tracks, colours):
    """Item colour from the chord in the item name ("… · Ab"), so repeats read on the timeline."""
    lua_col = ", ".join(f'["{k}"]=0x{v:06x}' for k, v in colours.items())
    run_reascript(f"""
local col = {{ {lua_col} }}
for _, ti in ipairs({{{", ".join(str(t) for t in tracks)}}}) do
  local tr = reaper.GetTrack(0, ti)
  for i = 0, reaper.CountTrackMediaItems(tr) - 1 do
    local it = reaper.GetTrackMediaItem(tr, i)
    local _, nm = reaper.GetSetMediaItemTakeInfo_String(reaper.GetActiveTake(it), "P_NAME", "", false)
    local chord = nm:match("· (.+)$")
    if chord and col[chord] then
      local c = col[chord]
      reaper.SetMediaItemInfo_Value(it, "I_CUSTOMCOLOR", reaper.ColorToNative((c >> 16) & 255, (c >> 8) & 255, c & 255) | 0x1000000)
    end
  end
end
reaper.UpdateArrange()
""", "vd_colour")
    time.sleep(1.5)


CHORD_COLOURS = {"Fm": 0x4a6fd0, "Db": 0xd08a3a, "Ab": 0x3fa66b, "Eb/G": 0xb04ac8,
                 "Eb": 0x8c4ac8, "Cm": 0xc84a4a, "Bbm": 0xc8b43a}
