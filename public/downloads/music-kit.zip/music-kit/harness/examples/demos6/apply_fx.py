#!/usr/bin/env python3
"""The mix settings for blade-trap.rpp, as data.

Same idea as demos7/apply_fx.py: a generated .rpp loads every plugin at its
defaults, because REAPER keeps CLAP parameters in an opaque blob. Keeping the
settings here means rebuilding the project costs nothing.

Includes the one setting whose absence silently broke this track: Wave's
**Bend Range**. build_blade.py writes the 808 slides as pitch-bend events scaled
for a 12-semitone range, but Wave defaults to 2 — so every "slide up a fifth"
actually slid a whole tone, and the bass sounded like it was stuck rather than
gliding. The generator's numbers and this value have to agree.

    python3 build_blade.py && python3 apply_fx.py --open && python3 apply_fx.py
"""

from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from reaper_ipc import call, open_project_in_new_tab, set_params, track_volume_db  # noqa: E402

HERE = Path(__file__).resolve().parent

# Track order in the generated project (0-based).
PAD, LEAD, BASS, DRONE, DRUMS, ECHO, PLUCK, AIR = range(8)

P_WAVE_PRESET, P_KUBYZ_PRESET, P_DRUM_PRESET = 37, 19, 27
P_WAVE_BEND_RANGE = 24
BEND_RANGE_ST = 12.0        # must match bend_ramp() in build_blade.py

FX = [
    # ---- pad: Saw, swelling, with the voice's band carved out ---------------
    (PAD, 0, P_WAVE_PRESET, 1,   "Wave preset: Saw"),
    (PAD, 0, 8,  1.2,   "attack s — the swell IS the sound"),
    (PAD, 0, 11, 3.5,   "release s"),
    (PAD, 0, 12, 1.0,   "output dB"),
    (PAD, 1, 7,  220.0, "eq highpass — leave the low mids to the 808"),
    (PAD, 1, 2,  450.0, "eq mid freq"),
    (PAD, 1, 3,  -5.0,  "eq mid gain — the pocket the rap sits in"),
    (PAD, 1, 6,  4.0,   "eq high gain"),
    (PAD, 2, 0,  0.45,  "supermass mix"),

    # ---- lead: the Vangelis line -------------------------------------------
    (LEAD, 0, P_WAVE_PRESET, 14, "Wave preset: Aulos (Odyssey)"),
    (LEAD, 0, 8,  0.30, "attack s"),
    (LEAD, 0, 11, 2.5,  "release s"),
    (LEAD, 0, 12, 2.0,  "output dB"),
    (LEAD, 1, 0,  592.0, "delay ms — dotted quarter at 152 BPM"),
    (LEAD, 1, 5,  0.30, "delay mix"),
    (LEAD, 2, 0,  0.32, "supermass mix"),

    # ---- the 808 ------------------------------------------------------------
    (BASS, 0, P_WAVE_PRESET, 11, "Wave preset: 808 Sub"),
    (BASS, 0, P_WAVE_BEND_RANGE, BEND_RANGE_ST,
     "bend range ST — without this the slides are 6x too small"),
    (BASS, 0, 8,  0.004, "attack s"),
    (BASS, 0, 11, 0.35,  "release s"),
    (BASS, 0, 12, 3.0,   "output dB"),
    (BASS, 1, 0,  11.0,  "saturator drive — harmonics so it reads on a phone"),
    (BASS, 1, 4,  0.55,  "saturator mix"),

    # ---- kubyz drone --------------------------------------------------------
    (DRONE, 0, P_KUBYZ_PRESET, 1, "Kubyz preset: Bashkir"),
    (DRONE, 1, 0, 0.50, "supermass mix"),

    # ---- the kit ------------------------------------------------------------
    (DRUMS, 0, P_DRUM_PRESET, 1, "Drum preset: Trap"),
    (DRUMS, 0, 2,  0.72, "kick level"),
    (DRUMS, 0, 6,  0.90, "snare level"),
    (DRUMS, 0, 10, 0.80, "hat closed level"),
    (DRUMS, 0, 8,  5.0,  "hat closed tune +5 st"),
    (DRUMS, 0, 14, 0.65, "hat open level"),
    (DRUMS, 0, 18, 0.85, "clap level"),
    (DRUMS, 0, 25, 0.0,  "kit master dB"),
    (DRUMS, 1, 0, -14.0, "comp threshold"),
    (DRUMS, 1, 5,  3.0,  "comp makeup"),

    # ---- kubyz layers -------------------------------------------------------
    (ECHO,  0, 0, 0.35, "supermass mix"),
    (PLUCK, 0, 6, 0.40, "reverb mix"),
    (AIR,   0, 0, 0.50, "supermass mix"),
]

GAINS = [
    (PAD,    -9.0),
    (LEAD,   -6.0),
    (BASS,   -7.0),
    (DRONE, -16.0),
    (DRUMS,   0.0),
    (ECHO,   -9.0),
    (PLUCK, -17.0),
    (AIR,   -16.0),
]


def main():
    if "--open" in sys.argv:
        open_project_in_new_tab(HERE / "blade-trap.rpp")
        print("opened blade-trap.rpp in a new tab")
        return

    # Parameter events only reliably reach a plugin while the transport runs.
    call("Main_OnCommand", 1007, 0)      # Play
    print("fx")
    set_params(FX)
    print("gains")
    for track, db in GAINS:
        track_volume_db(track, db)
        print(f"  t{track} {db:+.1f} dB")
    call("Main_OnCommand", 1016, 0)      # Stop
    print("done")


if __name__ == "__main__":
    main()
