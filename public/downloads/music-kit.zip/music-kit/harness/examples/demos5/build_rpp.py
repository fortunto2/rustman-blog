#!/usr/bin/env python3
"""Write a full REAPER project for the beat24 track, directly as .rpp.

Why not drive REAPER live: inserting media through the MCP bridge opens a modal
import dialog after a while, and a modal dialog freezes the bridge's Lua defer
loop — 54 items in, everything stopped. An .rpp is a text file, so generating it
is both faster and immune to that.

Layout: ten audio layers (all from the kubyz drum kit) plus two of our own synths
carrying the harmony — Kubyz for the drone, Wave for the chords. Both are CLAP
instances matched by id, so REAPER resolves them regardless of build number.

    python3 build_rpp.py           # writes kubyz-track.rpp
"""

import math
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = HERE / "src"
OUT = HERE / "kubyz-track.rpp"

BPM = 100.0
BAR = 60.0 / BPM * 4          # 2.4 s
LOOP = BAR * 4                # a 4-bar layer loop
TPQN = 960                    # MIDI ticks per quarter note
TICKS_BAR = TPQN * 4

# Section starts in bars
INTRO, V1, CH1, BR, CH2, OUT_S, END = 0, 8, 24, 40, 48, 64, 72


def guid():
    return "{" + str(uuid.uuid4()).upper() + "}"


def bars(n):
    return n * BAR


def every(start_bar, count):
    return [bars(start_bar + 4 * i) for i in range(count)]


def db(x):
    return 10 ** (x / 20.0)


# ---------------------------------------------------------------------------
# Audio layers — every one of them is the kubyz
# ---------------------------------------------------------------------------

AUDIO = [
    ("Wood",    "bed_wood_100_wood_clave_4.wav",   -4.0, 16576,
     every(INTRO, 2) + every(V1, 4) + every(CH1, 4) + every(CH2, 4) + every(OUT_S, 2)),
    ("Shaker",  "bed_shaker_100_shake_16_4.wav",   -9.0, 16576,
     every(V1 + 4, 3) + every(CH1, 4) + every(CH2, 4)),
    ("Tom",     "bed_tom_100_kick_basic_4.wav",    -7.0, 33023,
     every(V1, 4) + every(CH1, 4) + every(CH2, 4)),
    ("Rim",     "bed_rim_100_snare_backbeat_4.wav", -8.0, 33023,
     every(CH1, 4) + every(CH2, 4)),
    ("Whistle", "bed_whistle_100_sparse_4.wav",    -5.0, 25599,
     [bars(CH1), bars(CH1 + 8)] + every(BR, 2) + [bars(CH2), bars(CH2 + 8)] + [bars(OUT_S)]),
    ("Bell",    "bed_bell_100_bell_call_4.wav",    -6.0, 25599,
     every(CH1, 4) + every(CH2, 4)),
    ("Chime",   "bed_chime_100_chime_sparse_4.wav", -9.0, 25599,
     every(BR, 2) + every(OUT_S, 2)),
    ("Glass",   "bed_glass_100_glass_wide_4.wav",  -8.0, 25599,
     every(BR, 2)),
    ("Sub",     "track_sub.wav",                   -6.0, 33023,
     every(V1 + 8, 2) + every(CH1, 4) + every(CH2, 4)),
    ("Air",     "air.wav",                        -11.0, 16576,
     [bars(INTRO), bars(INTRO + 4)] + every(BR, 2) + every(OUT_S, 2)),
]

# Effects per audio track, as (clap display name, clap id).
FX = {
    "Whistle": [("CLAPi: SuperDuper Supermass (SuperDuperAI)", "co.superduperai.supermass")],
    "Bell":    [("CLAPi: SuperDuper Supermass (SuperDuperAI)", "co.superduperai.supermass")],
    "Air":     [("CLAPi: SuperDuper Supermass (SuperDuperAI)", "co.superduperai.supermass")],
}


def audio_item(path, pos, length, name):
    return f"""    <ITEM
      POSITION {pos:.6f}
      SNAPOFFS 0
      LENGTH {length:.6f}
      LOOP 0
      ALLTAKES 0
      FADEIN 1 0 0 1 0 0 0
      FADEOUT 1 0.005 0 1 0 0 0
      MUTE 0 0
      SEL 0
      IGUID {guid()}
      IID {audio_item.counter}
      NAME {name}
      VOLPAN 1 0 1 -1
      SOFFS 0 0
      PLAYRATE 1 1 0 -1 0 0.0025
      CHANMODE 0
      GUID {guid()}
      <SOURCE WAVE
        FILE "{path}"
      >
    >
"""


audio_item.counter = 1


def wav_length(path):
    """Frame count from the RIFF header — no decoding needed."""
    b = Path(path).read_bytes()[:200]
    i = 12
    ch, bits, rate, data = 2, 32, 44100, None
    while i + 8 <= len(b):
        cid, size = b[i:i + 4], int.from_bytes(b[i + 4:i + 8], "little")
        if cid == b"fmt ":
            ch = int.from_bytes(b[i + 10:i + 12], "little")
            rate = int.from_bytes(b[i + 12:i + 16], "little")
            bits = int.from_bytes(b[i + 22:i + 24], "little")
        elif cid == b"data":
            data = size
            break
        i += 8 + size + (size & 1)
    if data is None:
        full = Path(path).stat().st_size - 44
        data = max(0, full)
    return data / (ch * max(1, bits // 8) * rate)


# ---------------------------------------------------------------------------
# Synth layers — our own plugins carry the harmony
# ---------------------------------------------------------------------------

# C# minor (the reed's key): i – VI – III – VII, one chord per bar.
CHORDS = [
    [49, 52, 56],   # C#m
    [45, 49, 52],   # A
    [52, 56, 59],   # E
    [47, 51, 54],   # B
]
DRONE = 37          # C#2 — the reed's own pitch


def midi_events(notes_by_bar, bars_count, vel=0x50):
    """`notes_by_bar[i]` = list of pitches held for that bar. Returns RPP E-lines
    with cumulative tick deltas."""
    lines, prev_tick = [], 0

    def emit(tick, status, d1, d2):
        nonlocal prev_tick
        lines.append(f"        E {tick - prev_tick} {status:02x} {d1:02x} {d2:02x}")
        prev_tick = tick

    for b in range(bars_count):
        notes = notes_by_bar[b % len(notes_by_bar)]
        start = b * TICKS_BAR
        end = start + TICKS_BAR - 20      # tiny gap so repeats retrigger cleanly
        for n in notes:
            emit(start, 0x90, n, vel)
        for n in notes:
            emit(end, 0x80, n, 0)
    lines.append(f"        E {TICKS_BAR * bars_count - prev_tick} b0 7b 00")
    return "\n".join(lines)


def midi_item(pos, bars_count, notes_by_bar, name, vel=0x50):
    return f"""    <ITEM
      POSITION {pos:.6f}
      SNAPOFFS 0
      LENGTH {bars(bars_count):.6f}
      LOOP 0
      ALLTAKES 0
      FADEIN 1 0 0 1 0 0 0
      FADEOUT 1 0 0 1 0 0 0
      MUTE 0 0
      SEL 0
      IGUID {guid()}
      IID {audio_item.counter}
      NAME {name}
      VOLPAN 1 0 1 -1
      SOFFS 0 0
      PLAYRATE 1 1 0 -1 0 0.0025
      CHANMODE 0
      GUID {guid()}
      <SOURCE MIDI
        HASDATA 1 {TPQN} QN
        CCINTERP 32
{midi_events(notes_by_bar, bars_count, vel)}
      >
    >
"""


def fx_chain(plugins):
    if not plugins:
        return ""
    body = ""
    for name, cid in plugins:
        body += f"""      <CLAP "{name}" {cid} ""
        CFG 4 720 700 ""
      >
      WAK 0 0
"""
    return f"""    <FXCHAIN
      WNDRECT 200 200 720 700
      SHOW 0
      LASTSEL 1
      DOCKED 0
      BYPASS 0 0 0
{body}    >
"""


def track(name, vol_db, colour, items, plugins=None):
    return f"""  <TRACK {guid()}
    NAME "{name}"
    PEAKCOL {colour}
    BEAT -1
    AUTOMODE 0
    PANLAWFLAGS 3
    VOLPAN {db(vol_db):.6f} 0 -1 -1 1
    MUTESOLO 0 0 0
    IPHASE 0
    PLAYOFFS 0 1
    ISBUS 0 0
    BUSCOMP 0 0 0 0 0
    SHOWINMIX 1 0.6667 0.5 1 0.5 0 0 0 0
    SEL 0
    REC 0 0 1 0 0 0 0 0
    VU 64
    TRACKHEIGHT 0 0 0 0 0 0
    INQ 0 0 0 0.5 100 0 0 100
    NCHAN 2
    FX 1
    TRACKID {guid()}
{fx_chain(plugins or [])}{items}  >
"""


def main():
    body = ""

    # ---- audio layers -----------------------------------------------------
    for name, fn, vol, colour, positions in AUDIO:
        path = SRC / fn
        if not path.exists():
            print(f"  ! missing {path}")
            continue
        length = wav_length(path)
        items = ""
        for pos in positions:
            items += audio_item(path, pos, length, fn)
            audio_item.counter += 1
        body += track(name, vol, colour, items, FX.get(name))
        print(f"  {name:8s} {len(positions):2d} items × {length:.2f}s  {vol:+.0f} dB")

    # ---- Kubyz: the drone, on its own pitch -------------------------------
    drone_items = ""
    for start, n_bars in [(V1, 16), (CH1, 16), (CH2, 16), (OUT_S, 8)]:
        drone_items += midi_item(bars(start), n_bars, [[DRONE, DRONE + 12]], "kubyz drone", 0x46)
        audio_item.counter += 1
    body += track("Kubyz (drone)", -9.0, 8355711, drone_items,
                  [("CLAPi: SuperDuper Kubyz (SuperDuperAI)", "co.superduperai.kubyz")])
    print("  Kubyz    drone on C#2 + octave, verse/choruses/outro")

    # ---- Wave: the chord movement -----------------------------------------
    chord_items = ""
    for start, n_bars in [(CH1, 16), (BR, 8), (CH2, 16)]:
        chord_items += midi_item(bars(start), n_bars, CHORDS, "chords C#m-A-E-B", 0x4a)
        audio_item.counter += 1
    body += track("Wave (chords)", -12.0, 8355711, chord_items,
                  [("CLAPi: SuperDuper Wave (SuperDuperAI)", "co.superduperai.wave")])
    print("  Wave     C#m-A-E-B, one chord per bar, choruses + bridge")

    head = f"""<REAPER_PROJECT 0.1 "7.77/macOS-arm64" 0
  RIPPLE 0
  GROUPOVERRIDE 0 0 0
  AUTOXFADE 385
  TEMPO {BPM:.0f} 4 4
  PLAYRATE 1 0 0.25 4
  SAMPLERATE 44100 0 0
  LOOP 0
  LOOPGRAN 0 4
  <RENDER_CFG
  >
  CURSOR 0
  ZOOM 12 0 0
  VZOOMEX 6 0
  MASTERAUTOMODE 0
  MASTERTRACKHEIGHT 0 0
  MASTERPEAKCOL 16576
  MASTERMUTESOLO 0
  MASTERTRACKVIEW 0 0.6667 0.5 0.5 0 0 0 0 0 0 0 0 0 0
  MASTER_NCH 2
  MASTER_VOLUME 1 0 -1 -1 1
  MASTER_FX 1
  MASTER_SEL 0
"""
    OUT.write_text(head + body + ">\n")
    print(f"\nwrote {OUT}  ({bars(END):.1f} s = {bars(END)/60:.2f} min, {BPM:.0f} BPM)")


if __name__ == "__main__":
    main()
