# Music harness: Claude Code + REAPER + SuperDuper DSP

Как я делаю музыку с Claude Code: агент управляет REAPER через MCP, ставит мои
плагины, пишет MIDI, сводит по замерам (LUFS/спектр), снимает ноты с аудио,
режет стемы, собирает мэшапы. Здесь всё, что нужно, чтобы повторить у себя.

## Что внутри

| Папка | Что это |
|---|---|
| `CLAUDE.md` | Мой проектный CLAUDE.md: всё, что выяснено про REAPER MCP, баги моста, плагины, UA Arrow. Положи в корень своей музыкальной папки и поправь под себя (железо, пути). |
| `skills/` | Скилы Claude Code. Скопируй в `~/.claude/skills/`. |
| `harness/` | Python-клиент моста REAPER (`reaper_ipc.py`), генератор `.rpp` (`rpp_lib.py`), шаблон `.mcp.json`, примеры проектов, `LESSONS.md` (грабли, на которые наступил). |

## Ссылки (всё публичное)

- **Плагины SuperDuper DSP** (31 CLAP/VST3/AU, Rust): https://github.com/fortunto2/superduper-dsp
  - готовые сборки: https://github.com/fortunto2/superduper-dsp/releases/latest (macOS arm64 + Windows x64)
  - установка: `INSTALL.md` в репо. VST3/AU-обёртки грузят `.clap`, ставь CLAP-zip обязательно.
  - CLI-инструменты в `tools/`: `sdsp-chain` (рендер цепочек без DAW), `sdsp-mash`, `sdsp-score`, `mixcheck.py`.
  - скилы `sdsp-*`, `superduper-*`, `audio-to-midi`, `track-teardown`, `vocal-mix`, `mic-compare` живут в `skills/` репо (здесь копия).
- **REAPER MCP** (мой форк с фиксом моста): https://github.com/fortunto2/total-reaper-mcp
  (оригинал: https://github.com/shiehn/total-reaper-mcp)
- **Ableton через MCP:** `npx producer-pal` + Max for Live девайс (нужен Live Suite).
- **livehub** (мой DJ/VJ хаб на Rust, эксперимент): https://github.com/fortunto2/livehub
- **solo-factory** (общий харнес для разработки, сенсоры, скилы): https://github.com/fortunto2/solo-factory

## Установка (macOS, Apple Silicon)

```bash
# 1. Скилы
cp -R skills/* ~/.claude/skills/

# 2. Плагины: скачать zip из releases, распаковать .clap в ~/Library/Audio/Plug-Ins/CLAP/
#    (VST3 в ~/Library/Audio/Plug-Ins/VST3/), потом в REAPER: Preferences → Plug-ins → Re-scan.

# 3. REAPER MCP
mkdir -p ~/Music/tools && cd ~/Music/tools
git clone https://github.com/fortunto2/total-reaper-mcp && cd total-reaper-mcp
/opt/homebrew/bin/python3.13 -m venv .venv && .venv/bin/pip install -e .
./scripts/install_bridge.sh
# В REAPER: Actions → Show action list → Load → mcp_bridge_file_v2.lua → Run.
# В консоли REAPER должно появиться "REAPER MCP Bridge (File-based, Full API) started".

# 4. .mcp.json в корень музыкальной папки
sed "s|__HOME__|$HOME|" harness/mcp.json.template > ~/Music/.mcp.json
cd ~/Music && claude mcp list   # reaper должен быть Connected

# 5. Python-хелперы (быстрый путь в обход MCP, ~30 параметров/сек)
cp harness/*.py ~/Music/
```

Нужны: REAPER 7+, Claude Code, Python 3.13 (homebrew, не pyodide), `uv`, `ffmpeg`.
Для стемов/нот: `uvx` тянет demucs / basic-pitch сам (см. скилы `stem-split`, `audio-to-midi`).
Для сборки плагинов из исходников: Rust stable + cmake (скил `superduper-plugin`).

## Как работать

Просто говори Claude по-человечески, скилы подхватятся сами:

- «сделай бит 90 bpm в рипере нашими плагинами» → `reaper-daw` + `superduper-song`
- «прогони вокал через цепочку и покажи LUFS» → `sdsp-chain`, `vocal-mix`
- «сними ноты с этой записи» → `audio-to-midi`
- «вытащи акапеллу» → `stem-split`
- «разбери этот трек и пересобери» → `track-teardown`
- «вокал X на бит Y» → `sdsp-mash`
- «сведи по референсу» → `sdsp-mix`

Главное из опыта (подробно в `CLAUDE.md` и `harness/LESSONS.md`):

1. **Аранжировку генерируй `.rpp` файлом**, а не вставкой items через мост: после ~50 вставок REAPER показывает модалку и мост умирает. Пример: `harness/examples/demos5/build_rpp.py`.
2. **Параметры ставь пачкой через `reaper_ipc.py`**, а не MCP-тулами по одному. Пример: `harness/examples/demos6/apply_fx.py`.
3. **Инструмент первым в цепочке FX.** `dsl_add_effect` добавляет в конец.
4. **`dsl_track_create` вставляет трек в начало**, порядок индексов получается обратный.
5. **Пересобранный `.clap` не подхватится, пока REAPER не перезапущен** (кэширует dylib).
6. **Проверяй числами**, а не на слух агента: LUFS, спектрограммы как картинки, A/B-рендеры.

## Не работает без моих приватных репо

- `skills/music-reels-cut` использует бинарь `beat_dump` из приватного `video-generator-agent`. Скил оставлен как описание подхода.
- Пути вида `~/Music/1music/...` в скилах — моя раскладка, поправь под свою.
