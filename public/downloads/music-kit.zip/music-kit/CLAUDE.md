# Audio Setup — UA Arrow

## REAPER MCP (Claude Code integration)
- **Сервер:** `shiehn/total-reaper-mcp` — Lua bridge + Python MCP (file-based IPC, не зависит от python-reapy).
- **Конфиг:** `.mcp.json` в корне проекта (project scope), сервер `reaper` запускается профилем `dsl-production` (53 tools, оптимизировано под LLM).
- **Путь к серверу:** `tools/total-reaper-mcp/` (venv: `tools/total-reaper-mcp/.venv`, Python **3.13 native** из `/opt/homebrew/bin/python3.13` — НЕ `~/.local/bin/python3.13` (это Pyodide/Emscripten, ломает сборку cffi).
- **Lua bridge:** установлен в `~/Library/Application Support/REAPER/Scripts/mcp_bridge_file_v2.lua`. Чтобы MCP заработал — в REAPER один раз: Actions → Show action list → Load → выбрать `mcp_bridge_file_v2.lua` → Run. В REAPER console должно появиться: `REAPER MCP Bridge (File-based, Full API) started`. Bridge должен крутиться пока работаешь через MCP.
- **Профили:** `dsl-production` (53, default), `dsl` (15), `groq-essential` (146), `full` (600+). Сменить — отредактировать `--profile` в `.mcp.json`.
- **Управление:** `claude mcp list` (из этой папки), `claude mcp remove reaper --scope project`.
- **Обновить bridge после `git pull`** в `tools/total-reaper-mcp/`: `./scripts/install_bridge.sh` + перезапустить action в REAPER.

### Что MCP может с REAPER (выясненное на практике)
- ✅ Создание/именование/громкость/панорама треков, маркеры, регионы, MIDI items, рендер.
- ✅ Добавление FX по имени (`track_fx_add_by_name "Serum"` сработало → `VSTi: Serum (Xfer Records)`).
- ✅ Копирование FX между треками со всеми настройками (`track_fx_copy_to_track`).
- ✅ Чтение/запись любого VST-параметра (Serum экспонирует 319).
- ⚠️ **Баги bridge:** `dsl_track_color` падает `MediaTrack expected` (цвета не применяются), `dsl_save` зависает на 5+ сек если REAPER открыл диалог Save As.
- ⚠️ **Порядок FX:** `dsl_add_effect` добавляет в конец — если ставишь синт (VSTi) после reverb, цепочка будет `Reverb → Synth → output` и реверб обрабатывает тишину. **Правило:** инструменты первыми. Если уже криво — удалить FX 0 через `track_fx_delete`, потом снова добавить эффекты — синт окажется в начале.
- ⚠️ **Numbering:** `dsl_*` возвращает треки 1-based в сообщениях, но `track_fx_*` использует 0-based индексы. Не путать.
- ⚠️ **`dsl_track_create` вставляет в index 0 (PREPEND!)** — создаёшь Kick, Snare, Hats по порядку → реальный порядок индексов ОБРАТНЫЙ (idx0=последний созданный). Все последующие integer-индексы (инструменты, MIDI) лягут по перевёрнутой карте. **Лечение:** создавать треки в обратном порядке, ЛИБО переименовать через `dsl_track_rename` по индексам после создания. (Это НЕ баг параллелизма — параллельные `dsl_midi_insert` по индексу ложатся корректно; путаются только имена.)
- ⚠️ **`dsl_track_delete_all` сломан** — рапортует `No tracks to delete` даже когда треки есть. Удалять по одному через `dsl_track_delete` (по имени). **Удаления отдельных MIDI items в профиле `dsl-production` НЕТ** — только снос трека целиком.
- ⚠️ **`dsl_get_tempo_info` врёт** — показывает `120.0 / 4/120.0` независимо от реального темпа. `dsl_set_tempo` РАБОТАЕТ (ставит master). Проверять темп через `Master_GetTempo` (direct IPC). Чтобы поставить настоящий tempo-маркер: `SetTempoTimeSigMarker(0,-1,0.0,-1,-1,bpm,4,4,false)` + `UpdateTimeline` (мостовый `SetTempo` зовёт его с `timepos=-1` → не применяется).
- ⚠️ **`track_fx_set_preset` НЕ применяется к нашим CLAP** (как и к Serum): рапортует успех, но `get_preset`=`No preset selected`. **Но пресет ставится параметром** `Preset` (см. ниже) — GUI больше не обязателен.
- ✅ **Единицы параметров через MCP (проверено 2026-08-13, старая запись про «нормализованы 0..1» была НЕВЕРНОЙ):** `track_fx_set_param` принимает **реальное значение** в единицах параметра — Hz, dB, полутона, а для stepped-параметров **индекс** (Preset = 9 это Reese Bass, а не 9/14). `track_fx_get_param` возвращает реальное значение и настоящий диапазон.
  - ⚠️ **Пока плагин не проинициализирован, `get_param` врёт**: сразу после открытия проекта показывает `range: 0.000 to 1.000`, и запись туда уходит в никуда (`-1.000`). Лечится запуском воспроизведения (`dsl_play`) — после этого диапазон читается настоящий (`0.000 to 14.000`). **Порядок: play → set_param → get_param для проверки → stop.**
  - 💡 **Не гадать индексы и id — спросить инструмент:** `sdsp-chain --params <plugin>` (id/имя/min/max/default/единицы) и `sdsp-chain --presets <plugin>` (список пресетов с индексами). С 2026-09-24 чейн и **рендерит инструменты** (все 7: wave/kubyz/pad/drum/sampler/ambient/wind) — `[[track]] instrument = "kubyz"` + `notes = [[start_s, dur_s, midi, vel], …]` + `preset = N`, без REAPER (детали — скилл `sdsp-chain`, секция Instrument tracks). Индексы `Preset`: Wave 37, Pad 14, Drum 27, Kubyz 19, Sampler 21.
  - `param_count` у Wave завышен (2136), но имена/индексы 0..N корректны.
- ✅ **`dsl_midi_insert`:** `time={"start":сек,"end":сек}` → абсолютное позиционирование item. `note.start`/`length` — **в секундах ОТНОСИТЕЛЬНО начала item** (несмотря на имя `_ppq` в мосте: внутри `MIDI_GetPPQPosFromProjTime(item_pos+start)`).
- ⚠️ **`InsertMedia` через мост вешает мост** (2026-08-13). Вставка аудио-items работает (`SetOnlyTrackSelected(idx)` → `SetEditCurPos(t)` → `InsertMedia(file,0)`; мост сам резолвит **числовой индекс** трека в MediaTrack для `SetOnlyTrackSelected`, `GetSetMediaTrackInfo_String`, `SetMediaTrackInfo_Value` — но НЕ для всех функций, напр. `CountTrackMediaItems` требует указатель, а вернуть полученный `{"__ptr":...}` обратно нельзя). НО после ~50 вставок REAPER открывает модальное окно импорта, а модальное окно **останавливает defer-цикл Lua-моста** → мост перестаёт обрабатывать очередь, запросы копятся без ответов, и лечится только закрытием окна руками. **Вывод: для сборки аранжировки не гонять items через мост, а генерировать `.rpp` напрямую** — это текстовый формат, быстрее и без диалогов (рабочий генератор: `~/Music/1music/demos5/build_rpp.py`).
- 💡 **`.rpp` — самый надёжный путь для аранжировки.** Наши плагины в проекте описываются как `<CLAP "CLAPi: SuperDuper Wave (SuperDuperAI)" co.superduperai.wave ""` + `CFG 4 W H ""`; REAPER матчит **по CLAP id**, поэтому build-суффикс `[bNNNNN]` в имени указывать не нужно. MIDI-item: `<SOURCE MIDI` + `HASDATA 1 960 QN` + строки `E <delta_ticks> <status> <d1> <d2>` (hex, дельты кумулятивные). Аудио-item: `<SOURCE WAVE` + `FILE "..."`. Маркеры проще досыпать через MCP `dsl_marker` после открытия. ⚠️ `dsl_save` без имени сохранил проект как `~/Music/REAPER Projects/Untitled.rpp`, а не в исходный путь — проверять, куда лёг файл.
- 💡 **Generic passthrough моста (мощно):** мост умеет звать **ЛЮБУЮ** `reaper.*` функцию по имени (строка ~4006 `mcp_bridge_file_v2.lua`). Файловый IPC: `~/Library/Application Support/REAPER/Scripts/mcp_bridge_data/request_<N>.json` → `{"id":N,"func":"ReaperFunc","args":[...]}`, ответ в `response_<N>.json`, мост сам удаляет request после обработки. **Сервер инкрементит `request_id` с 0; `reaper_ipc.py` с 2026-09-23 сам стартует со случайного слота 900–99999 и удаляет залипший `response_<id>.json` перед запросом** (раньше два python-процесса с одного слота читали чужие ответы: fx=55938 приходил как «55877»). Мост раньше сканировал только `request_1..1000` литеральным циклом — id вне диапазона висел без ответа и без ошибки; с 2026-08-14 он перечисляет реально существующие файлы (`EnumerateFiles`), так что любой id работает. Готовый клиент: `~/Music/1music/reaper_ipc.py` (`call('TrackFX_SetParam', trk, fx, param, value)`), примеры применения целого микса — `demos6/apply_fx.py`, `demos7/apply_fx.py`. Это в разы быстрее MCP: ~30 параметров за секунду вместо минуты, и настройки живут в git-able файле, а не только в .rpp. Так делается bulk-вставка нот, темп, item-операции, которых нет среди DSL-тулов — без инлайна тысяч нот в аргументы. **НЕ слать MCP-тулы параллельно со своим скриптом.**
- ⚠️ **Харнес моста (уроки 2026-09-23, всё уже встроено в `reaper_ipc.py`):**
  - **Lua-ошибка в ReaScript = модальное окно = мёртвый мост**: defer-цикл стоит, пока окно не закроют руками. Источники: `\n` вместо реального переноса в heredoc и `"..N.."` без пробелов (malformed number). `run_reascript()` теперь гоняет `luac -p` ДО отправки — синтаксис падает локально SyntaxError'ом.
  - **Залипший `request_*.json` переигрывается при следующем старте REAPER** — оставшийся Quit-request закрыл REAPER сразу после запуска (выглядело как краш). При странностях на старте чистить `mcp_bridge_data/request_*.json`.
  - **`Main_openProject` асинхронен**: скрипт после него бежит в СТАРОМ активном табе (тест-риг однажды построился внутри чужого проекта). `open_project_in_new_tab()` поллит `EnumerateProjects(-1)` до смены имени файла.
  - **REAPER single-instance**: `open -a REAPER file.rpp` живому инстансу лишь открывает таб — процесс (и закешированные CLAP dylib) не перезапускается. Настоящий рестарт: сохранить табы → `pkill -TERM -x REAPER` → дождаться выхода → `open`. Какой бинарь реально загружен: `lsof -p $(pgrep -x REAPER) | grep <Plugin>` и сравнить inode с `ls -i` на диске — `[bNNNNN]` в .rpp врёт.


## SuperDuper DSP — НАШ плагинный арсенал (используем В ПЕРВУЮ ОЧЕРЕДЬ)
- **Что это:** 30 собственных CLAP-плагинов в релизе (Rust; ещё Denoise в разработке, не собирается). Исходники `superduper-dsp/effects/<name>/`, сборки `superduper-dsp/dist/*.clap`, установлены в `~/Library/Audio/Plug-Ins/CLAP/`. Скилл для создания/правки: `superduper-plugin`; headless-цепочка: `sdsp-chain`.
- **ПРАВИЛО:** строя трек в REAPER, инструменты и FX-цепочки берём из наших плагинов (не UAD/Serum), если пользователь не просит иначе.
- 💡 **Порядок стадий в цепочке фиксирован, меняются только цифры:** tune (на сухом) → чистка (HP + вырез мути, трим до ~−20 LUFS) → быстрый компрессор (пики, 1176) → медленный (левелинг, LA-2A) → де-эссер → сатурация → тональный EQ → пространство (заdучканное). Готовый старт: `sdsp-chain --template vocal` (шаблоны в `tools/sdsp-chain/templates/`); почему каждая стадия на своём месте — скилл `sdsp-mix`, раздел «The channel chain». **REAPER-версия — project template «SuperDuper Vocal Chain»** (File → Project templates; Vocal с цепочкой + Beat с карманом + dучащиеся Delay/Reverb-посылы, параметры уже в .rpp). Генератор: `vocal-template/build_rpp.py` + `apply_fx.py` (один источник правды — тот же TOML; после правок цепочки перегенерить и пересохранить).
- ⚠️ **`duck_from`/`duck_db` в sdsp-chain — НЕ глубина в dB** (вопреки комментарию в коде). Порог зашит на −26 dB, а `duck_db` идёт в **ratio** (`1 + depth`). Для управляемого сайдчейна писать явную стадию: `[[track.stage]] plugin = "compressor"` + `sidechain = "track:kick"`, а **глубину задавать параметром `Range`** (Threshold −30, Ratio 10, Range = глубина в dB) — тогда она не зависит от уровня ключа. Рецепт целиком + метод проверки (A/B-рендер с даком и без) — скилл `sdsp-mix`. ⚠️ До 2026-08-27 компрессор в паузах ключа молча переключал детекцию на основной вход (поблочная проверка «sidechain routed?») → дак не отпускал никогда; исправлено латчем, старые рендеры несут статический −Range вместо пампа.
- ⚠️ **Автоматизация LP ниже фиксированного HP = тишина** (слой ушёл в −36 LUFS, никакой gain не спасал). Проверять, что вся кривая LP выше HP.
- 💡 **Разбор чужого трека и пересборка** — скилл `track-teardown` (`superduper-dsp/skills/`), рабочий пример `demos8/`. Спектрограммы читаются как картинки, уровни решаются численно (`balance.py`), а не подбираются на глаз.
- ⚠️ **VST3i vs CLAPi:** через clap-wrapper существуют ОБЕ версии каждого плагина. `track_fx_add_by_name "SuperDuper Wave"` фаззи-матчит и по умолчанию ставит **VST3i** (тот же код, звучит идентично). Чтобы заставить CLAP — искать с префиксом `CLAPi:`. Display-имя содержит суффикс билда: `SuperDuper Wave [bNNNNN] (SuperDuperAI)`.
- **Инструменты (VSTi/CLAPi):**
  - **SuperDuper Wave** — wavetable-синт. Пресеты (0-based): `0 Init`,`1 Saw`,`2 Square`,`3 Triangle`,`4 Pulse`,`5-8` морфы, `9 Reese Bass`,`10 FM Growl`,`11 808 Sub`,`12 Fat Saw Lead`,`13 Formant`. Params: `0 WT Pos, 1 Unison, 2 Detune, 3 Sub, 4 Cutoff, 5 Resonance, 6 Filter Mode, 7 Drive, 8-11 ADSR, 12 Output, 13 Antialias, 14 Noise, 15-19 Filter Env, 20-26 LFO, 27-32 Mod1/Mod2, 33-34 Sync, 35-36 FM`. **Форма волны = часть пресета, не параметр** → reese/808 только через GUI (см. баги).
  - **SuperDuper Drum** — 6 синтезируемых голосов. **Маппинг нот — параметр `Note Map` (id 28)**: `0 Auto` (дефолт), `1 White Keys`, `2 GM`. Auto = сначала GM (**36/35 kick, 38/40 snare, 39 clap, 42/44 hat closed, 46 hat open, 56 cowbell**), иначе старая раскладка по классу высоты (C→Kick, D→Snare, E→HatClosed, F→HatOpen, G→Clap, A→Cowbell — играть с клавиатуры в любой октаве). Единственный конфликт — **40**: в GM это Electric Snare, по белым клавишам E = закрытый хэт; в Auto побеждает GM. Что не мапится — уходит в note-out. Пиши GM. ⚠️ До 2026-08-14 плагин понимал ТОЛЬКО белые клавиши, и GM-паттерны молча теряли хэты и клэп (два трека отрендерились без верха). Реальный код — `synth-core/src/drum_voices.rs` (реэкспорт как `voices`; мёртвая копия `src/voices.rs` удалена 2026-09-24). 28 params: 4/голос + `24 Drive, 25 Master, 26 NoteOut`. Пресеты: Trap, Boom Bap, 808 Sub, Techno, Joy Division, Boards of Canada. Note-passthrough: ноты вне drum-карты форвардятся на CLAP note-out (роутить в Wave/Kubyz).
  - Прочие инструменты: **Kubyz** (башкирский кубыз/варган), **Sampler**, **Pad**, **Ambient**.
- **Эффекты:** Eq, LinEq, Compressor, Saturator, Limiter, MidSide, Reverb, Supermass, Delay, Chorus, Filter, Soothe, Vocal, NAM (amp sim), Spectrum, Looper, Vocoder, Pitch, Tune, Harmonic, Wind, **Formant**, **Granular**, **Stretch**. Все добавляются через `track_fx_add_by_name "SuperDuper <Name>"`, параметры — `track_fx_set_param` (нормализованы 0..1).
  - **SuperDuper Formant** — формантный фильтр/артикулятор: три резонанса F1/F2/F3 на любой сигнал. `Mode`: Manual (пад гласных), **Follow** (трекер снимает форманты с голоса на sidechain-порту `Voice` и накладывает их на вход — «пою, а звучит кубыз»; когда голос замолкает, последняя гласная **замерзает** и фраза передаётся инструменту), Motion (траектория рта сама, free или sync к BPM). Params: `0 F1, 1 F2, 2 F3, 3 Width, 4 Shift, 5 Mode, 6 Follow, 7 Glide, 8 Path, 9 Rate, 10 Sync, 11 Div, 12 Depth, 13 Stereo, 14 Drive, 15 Mix, 16 Output, 17 Preset`. CC 1/74/71/73/76 → F1/F2/Width/Drive/Depth (совпадает с жестовой картой live2play).
  - **SuperDuper Granular** — гранулярное облако (наш Emergence): вход пишется в 6-секундный ринг, гранулы читают из него со своим питчем/паном/реверсом. **Freeze** останавливает запись → одна спетая нота становится бесконечным пэдом (CC 64 / педаль). `Feedback` — гранулы гранулируют себя. `Sync` → статтер в такт. Params: `0 Density, 1 Size, 2 Spray, 3 Position, 4 Pitch, 5 Jitter, 6 Spread, 7 Reverse, 8 Freeze, 9 Feedback, 10 Shape, 11 Sync, 12 Div, 13 Mix, 14 Output, 15 Preset`.
  - **SuperDuper Stretch** — PaulStretch (растяжение до 50×): длинное окно FFT, магнитуды сохраняются, **фазы рандомизируются**. `Tonal` 0 = классический смаз, 1 = обычное замедление. `Window` 85 мс…1.37 с — главная ручка «насколько размыто». **Freeze** крутит последние `Length` секунд вечно. Латентность = 0 намеренно (растянутый сигнал не выровнен по сэмплам). Params: `0 Stretch, 1 Window, 2 Tonal, 3 Smooth, 4 Pitch, 5 Freeze, 6 Length, 7 Mix, 8 Output, 9 Preset`.
  - 💡 **Связка под идею «пою → звучит кубыз»:** голос → **Stretch** (Voice → Pad, Freeze педалью) → **Formant** (Follow, голос в sidechain) → Supermass. Stretch держит бесконечное полотно из голоса, Formant заставляет его произносить гласные, кубыз играет поверх в том же строе.
- ✅ **Preset-параметр через MCP (СДЕЛАНО 2026-06-30):** у Wave/Drum/Kubyz/Pad есть stepped CLAP-param `"Preset"` (последний в `PARAMS`) — агент/DAW переключает тембр/форму волны/кит (reese/808/growl/Trap/Bashkir…) **без GUI**, точечной записью параметра. Индексы: Wave 37, Pad 14, Drum 27, Kubyz 19, Sampler 21 (с 2026-09-24; пресет сэмплера — характер воспроизведения, слот Sample не трогает). Механика (общая, в `sdk::clap_helpers`): `preset_recall_target()` детектит сдвиг параметра; audio-`process()` зовёт `host.request_callback()` (НЕ применяет — аллокации запрещены); `on_main_thread()` + main-thread `flush()` зовут `apply_preset(idx)` на главном потоке. `apply_preset` метит все параметры dirty (урок 21d) → хост/LOM/агент видят recall. `value_to_text`/`text_to_value` мапят индекс↔имя (можно слать «Reese Bass»). **Точечный контроль отдельных параметров работал всегда** (clap-wrapper экспонирует все → Live в LOM → producer-pal крутит 0..1); Preset закрыл единственное, что не выражалось параметром. ⚠️ На **idle**-треке (без ноты) событие параметра может долететь до плагина только при воспроизведении — крутить под нотой. ⚠️ Грабли при добавлении: если пресеты const-строятся из `PARAMS.len()` → цикл const-eval (E0391), лечится отдельной `const PRESET_COUNT` + static-assert.

## ConjureDSP MCP (live Rust/Python DSP)
- **Что это:** AUv3 плагин Michael Jancsy для написания DSP-эффектов в Rust (→ WASM) или Python (моментально). Каждый пресет — `.cdp` bundle (`manifest.json` + `process.{rs,py}` + опционально `ui/`).
- **MCP endpoint:** `http://localhost:61933/mcp` (HTTP transport, добавлен в `.mcp.json` как `conjuredsp`). **Сервер живёт только когда плагин активен в DAW** — если `claude mcp list` показывает `Failed to connect`, открой AU: ConjureDSP в REAPER и кликни на его UI. Актуальный URL пишется в `~/Library/Application Support/ConjureDSP/mcp-url.txt`.
- **Пресеты:** `~/Library/Group Containers/group.com.MichaelJancsy.ConjureDSP/Presets/*.cdp/` (под git, есть auto-push).
- **Agent инструкции:** `~/Library/Application Support/ConjureDSP/agent-workspace/CLAUDE.md` — авторитетный источник, читать перед серьёзной работой.
- **Skill:** `~/.claude/skills/conjuredsp/SKILL.md` — компактный референс для агентов.
- **Reference preset:** `DnB Bass.cdp` — Rust с Biquad lowshelf + lowpass + LFO-модулированной DelayLine + tanh-drive, 7 параметров включая Wave choice 0-3.
- **Hard rules:** в `process()` запрещены аллокации, I/O, sleep, lock; до 16 параметров; persist state через module globals (Python) или `static mut` / `persist!` (Rust).

### Serum через MCP (важные ограничения)
- ❌ **Power on/off для B/Sub/Noise oscillators** — не экспонируются как VST-параметры в Serum 1. Только клик на лампочку в UI Serum. `B Vol > 0` без включённого power = тишина.
- ❌ **Выбор файла wavetable** ("Basic Shapes", "Lush Saws", "Analog_BD") — это файл на диске, не параметр. Только через UI (READ → выбрать).
- ❌ **Factory/user пресеты** — `track_fx_set_preset` рапортует успех, но Serum остаётся на Init (свой preset engine, не VST).
- ✅ **319 параметров крутятся**: MasterVol (0), A Vol/Pan/Oct/Semi/Fine/Unison/UniDet/UniBlend/Warp/WTPos (1-13), B те же (14-26), Noise (27-32), Sub (33-34), Env1 ADHSR (35-39), Filter Cutoff (45), Env2/Env3, LFO Rates, FX rack.
- 💡 **Workflow:** открыть UI Serum через `track_fx_show(track, fx, 3)`, пользователь руками кликает power и выбирает wavetable, потом MCP крутит параметры.

## Hardware
- **Universal Audio Arrow** (Thunderbolt 3, 1× SHARC DSP, 2 in / 4 out)
- Подключена через USB-C порт MacBook Air M1 (TB3)
- Firmware 8.1, FPGA 20.50619, DSP Bootloader 5.01.004

## Software stack
- **UAD Software 11.8.3.321** (kernel driver, не DriverKit)
- **LUNA 2.0.3** — основной DAW и микшер карты (Console-микшер встроен в LUNA)
- `UA Mixer Engine.app`, `UA CoreAudio Control Panel.app` — фоновые сервисы
- **Console.app не существует** в UAD 11.x — управление картой только через LUNA или физические кнопки

## Управление картой без софта
На корпусе Arrow физические кнопки + большой knob:
- **PREAMP** → knob = mic gain
- **+48V** → phantom для конденсаторных микро
- **PAD** → -20 dB
- **LOW CUT** → HPF
- **HI-Z** → инструментальный вход (гитара)
- **MONITOR / PHONES** → knob = громкость мониторов / наушников

Системный регулятор громкости macOS Arrow не управляет (`output volume → missing value` — это норма).

## Recording workflow
- **Sample rate: 48000 Hz** везде (LUNA session + macOS audio device)
- **Buffer:** 128 samples при записи, 1024 при mix/playback
- **Direct monitoring** через LUNA mixer (icon на дорожке) — zero latency через DSP, минуя CPU
- Не использовать Bluetooth наушники (добавляет 100-300 ms)

## Free плагины (Authorized)
**Vocal chain:** UA 610-A/B preamp → 1176 (Rev A/AE/LN/SE) или LA-2A (Gray/Silver) → Pultec EQP-1A или Pultec-Pro EQ → Auto-Tune Realtime Access → RealVerb-Pro / Pure Plate

**Прочее:** Brigade Chorus, Studio D Chorus, Galaxy Tape Echo, Marshall Plexi Classic, Ampeg SVT-VR Classic, Century Tube Channel Strip, Precision Mix Rack collection (13 утилит), PolyMAX Synth (native).

## DO NOT
- **Не апдейтить UAD Software через UA Connect** — вернёт удалённые ~800 платных плагинов, ~6 GB. Auto-update в UA Connect выключить.
- **Не трогать** `/Library/Application Support/Universal Audio/UAD-2 Powered Plug-Ins/` — DSP binaries для Free плагинов лежат там, рандомное удаление сломает.
- **Не ставить старые версии UAD** (9.x / 10.x) — на macOS 26 не пройдут system extension.
- **Не ставить UAD Console v1.2.2 / UA Connect Console** — это для Volt серии, Arrow не поддерживает.

## Troubleshooting
- **«Unable to launch UA Mixer Engine»** → файл `/Library/Application Support/Universal Audio/Apollo/UA Mixer Engine.app` отсутствует. Лечится переустановкой через UA Connect → пакет **Apollo Interface Software** (281 MB, не весь 12 GB UAD Software).
- **Дропауты / тормоза** при playback → проверить sample rate mismatch (карта vs сессия), увеличить buffer до 1024, прибить `duetexpertd` и `mdworker_shared` (Spotlight жрёт CPU после установки 800+ плагинов), исключить `/Library/Audio/Plug-Ins/` и `/Library/Application Support/Universal Audio/` из Spotlight Privacy.
- **DSP Arrow ускоряет только UAD-2 DSP плагины** (категория «Universal Audio» в DAW). Native (категория «Universal Audio Native») идут на CPU. Проверь категорию инсерта.
- **Один SHARC** → плагины UAD на DSP лимитированы, после 5-10 сложных плагинов чип переполняется. Bounce/Freeze треки.

## Workflow paths
- LUNA сессии: `~/Music/LUNA Sessions/`
- UA Connect cache: `~/Library/Application Support/Universal Audio/workspace/temp/` — большие .pkg сюда падают, можно чистить после установки

## Free WAV sample sources

For SuperDuper Sampler and Drum (`superduper-dsp/` plugins). Drop
zips into `~/Music/SuperDuper Samples/` (one subfolder per kit
keeps the GUI dropdown readable) and the recursive scan picks
them up. `~/Music/Favorite 808s/` already scanned too.

- **Goldbaby Free Stuff** — <https://www.goldbaby.co.nz/freestuff.html>
  Curated single-hit packs (kicks, snares, claps, vinyl noise).
  Pro quality from a long-running boutique sample shop.
- **Hyperreal Music Machines — Roland TR-808** —
  <http://machines.hyperreal.org/manufacturers/Roland/TR-808/>
  Classic 808 individual-drum WAVs straight from the original machine.
- **Hyperreal Music Machines — Roland TR-909** —
  <http://machines.hyperreal.org/manufacturers/Roland/TR-909/>
  909 kits — kicks, snares, hi-hats, rides, claps.
- **Hyperreal Music Machines — Roland index** —
  <http://machines.hyperreal.org/manufacturers/Roland/>
  Full Roland catalogue — TR-606, TR-707, CR-78, SH-101, Juno-60, etc.
  Worth a deep dive for vintage drum/synth one-shots.

## Video — iPhone footage profile
Чаще всего снимаю на iPhone в **HDR HLG**:
- Кодек HEVC (H.265), `yuv420p10le` (10-bit)
- Color space **BT.2020 NCL**, primaries **BT.2020**, transfer **HLG** (`arib-std-b67`, Rec.2100 HLG)
- Color range TV (limited)

### DaVinci Resolve — настройки по умолчанию
Project Settings → Color Management:
- Color science: **DaVinci YRGB Color Managed**
- Automatic color management: **ON** (правильно распознаёт HLG/BT.2020 в исходниках)
- Color processing mode: **SDR** (финал обычно для YouTube/Instagram)
- Output color space: **SDR Rec.709**

Resolve сам сделает tone-map HLG → Rec.709. Это рабочий дефолт для SDR-финала на обычном мониторе.

HDR-режим (Rec.2100 HLG/PQ) включать только при наличии HDR-монитора и явном HDR-deliverable, иначе грейдинг вслепую → пересветы.
- ⚠️ **`Main_openProject` на путь, уже открытый в другой вкладке, НЕ перечитывает файл — просто переключается на ту вкладку** (2026-10-17, vyshe-minimal: три раза подряд свежесгенерированный .rpp перезаписывался старым состоянием при `Main_SaveProject`). Перед открытием перегенерированного проекта закрыть все вкладки с этим путём (`EnumProjects` → `SelectProjectInstance` → 40860); грязную вкладку перед закрытием припарковать `Main_SaveProjectEx(proj, другое_имя, 1)` (именно опция 1 = настоящий Save As, снимает dirty; с 0 вкладка остаётся грязной и закрытие вешает модалку «Save before closing?»). Готовое: `vyshe-i-dalshe/reaper_open.py::open_fresh` (+ assert, что размер файла не изменился после открытия).
  - ⚠️ **`Main_OnCommand(40860)` (закрыть вкладку) изнутри ReaScript, запущенного мостом, убивает мост** (2026-10-17): вкладка закрылась, defer-цикл встал, запросы висели без ответа и без модалки. Закрывать вкладку только прямым `call("Main_OnCommand", 40860, 0)`. Оживить мост без рук: `/Applications/REAPER.app/Contents/MacOS/REAPER -nonewinst "<путь>/mcp_bridge_file_v2.lua"` (запускает скрипт в живом инстансе). После открытия сверять не размер файла, а содержимое (`apply_g2015.verify_loaded`): размер совпадал, а содержимое было старым.
